import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KALI LINUX BLUETOOTH TRACE" },
      { name: "description", content: "Fictional BLE radar terminal UI — TokemekiAi." },
      { property: "og:title", content: "KALI LINUX BLUETOOTH TRACE" },
      { property: "og:description", content: "Fictional BLE radar terminal UI — TokemekiAi." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <iframe
      src="/app.html"
      title="KALI LINUX BLUETOOTH TRACE"
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        border: 0,
        background: "#02070c",
      }}
      allow="bluetooth; geolocation; camera; microphone; fullscreen"
    />
  );
}
