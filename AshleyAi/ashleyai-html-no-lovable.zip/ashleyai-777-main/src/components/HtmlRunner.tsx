import { useEffect, useMemo, useState } from "react";
import { Code2, Play, RotateCcw } from "lucide-react";

const STARTER_HTML = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My HTML App</title>
  <style>
    body { font-family: system-ui, sans-serif; padding: 2rem; background: #111827; color: white; }
    button { padding: .7rem 1rem; border: 0; border-radius: .7rem; cursor: pointer; }
  </style>
</head>
<body>
  <h1>Hello from HTML ✨</h1>
  <p>Edit the code, then press Run.</p>
  <button onclick="document.querySelector('p').textContent = 'JavaScript is running!'">
    Test JavaScript
  </button>
</body>
</html>`;

export function HtmlRunner() {
  const [source, setSource] = useState(STARTER_HTML);
  const [runningSource, setRunningSource] = useState(STARTER_HTML);
  const [autoRun, setAutoRun] = useState(false);

  useEffect(() => {
    if (!autoRun) return;
    const id = window.setTimeout(() => setRunningSource(source), 250);
    return () => window.clearTimeout(id);
  }, [source, autoRun]);

  const preview = useMemo(() => runningSource, [runningSource]);

  const run = () => setRunningSource(source);
  const reset = () => {
    setSource(STARTER_HTML);
    setRunningSource(STARTER_HTML);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Code2 className="h-5 w-5 text-primary" />
            HTML Runner
          </h2>
          <p className="text-xs text-muted-foreground">
            Write HTML, CSS, and JavaScript and run it directly in the browser.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs">
            <input
              type="checkbox"
              checked={autoRun}
              onChange={(e) => setAutoRun(e.target.checked)}
            />
            Live preview
          </label>
          <button
            onClick={reset}
            className="flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs hover:bg-secondary"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </button>
          <button
            onClick={run}
            className="ashley-gradient flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold text-primary-foreground shadow-md"
          >
            <Play className="h-3.5 w-3.5" /> Run HTML
          </button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="overflow-hidden rounded-2xl border border-border bg-input/40">
          <div className="border-b border-border px-3 py-2 text-xs uppercase tracking-wide text-muted-foreground">
            HTML / CSS / JavaScript
          </div>
          <textarea
            value={source}
            onChange={(e) => setSource(e.target.value)}
            spellCheck={false}
            className="min-h-[520px] w-full resize-y bg-transparent p-4 font-mono text-xs leading-5 outline-none"
            aria-label="HTML editor"
          />
        </div>

        <div className="overflow-hidden rounded-2xl border border-border bg-white">
          <div className="border-b border-slate-200 bg-slate-50 px-3 py-2 text-xs uppercase tracking-wide text-slate-500">
            Live preview
          </div>
          <iframe
            key={runningSource}
            title="HTML preview"
            srcDoc={preview}
            sandbox="allow-scripts allow-forms allow-modals"
            className="h-[520px] w-full bg-white"
          />
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        The preview is sandboxed in an iframe, so the code runs in the browser without becoming part of AshleyAI's page.
      </p>
    </div>
  );
}
