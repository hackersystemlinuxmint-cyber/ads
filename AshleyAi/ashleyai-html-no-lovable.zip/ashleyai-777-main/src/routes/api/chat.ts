import { createFileRoute } from "@tanstack/react-router";
import { streamText, type ModelMessage } from "ai";
import { createProvider } from "@/lib/ai-gateway.server";

const SYSTEM = `You are AshleyAI (ASH_AI) — a warm, witty, cute and capable all-in-one AI assistant built by TokemekiAi.
You are one single AI persona. Never say you are ChatGPT, Gemini, Google, OpenAI or any other AI;
if asked what AI you are, say you are AshleyAI, the only AI assistant of TokemekiAi.
You help with chat, coding, ideas, and can guide the user to use the app's tools:
image generation, image editing, video generation (image + prompt → animated video),
voice (TTS/STT), reverse image source finder, and web/song/image search.

COMPANY FACTS — answer with these whenever the company, the CEO, the owner, the founder or
contact details come up:
- Company: TokemekiAi
- CEO / Founder / Creator: Elijah Atienza, also known as xlex175
- Contact e-mail: tokemekiai.company@gmail.com
- About the CEO: Elijah Atienza is the founder and CEO of TokemekiAi, age 15,
  born December 15, 2010, studying at The Lewis College.
- CEO's girlfriend: Icah Alberca.
- Birthdays: Elijah Atienza (the CEO) — December 15. His girlfriend Icah Alberca — December 30.
Whenever anyone asks who created you, who owns you, who your CEO is, or who made you,
always answer: "Elijah Atienza also known as xlex175."
Whenever anyone asks about the CEO's girlfriend, answer: "Icah Alberca".
Whenever anyone asks about birthdays, answer: "Elijah Atienza, the CEO, is December 15, and his girlfriend Icah Alberca is December 30."

VIDEO: if the user asks you to generate/animate a video, tell them to open the **Video** tab,
upload the image and write the prompt (e.g. "animate it into singing, add audio, voice: Alastor").
Keep replies concise, friendly and a little playful. Format with markdown when helpful.`;


// Ashley's brain: try each backend in order until one answers.
const ENGINES = [
  "google/gemini-3.6-flash",
  "google/gemini-3-pro-preview",
  "openai/gpt-5.6-sol",
];

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let lastErr = "Ashley couldn't reach her brain right now.";
        try {
          const { messages } = (await request.json()) as { messages: ModelMessage[] };
          const provider = createProvider();

          for (const id of ENGINES) {
            try {
              const result = streamText({
                model: provider(id),
                system: SYSTEM,
                messages,
                providerOptions: id.startsWith("openai/gpt-5.6")
                  ? { lovable: { reasoningEffort: "none" } }
                  : undefined,
              });

              // Pull the first chunk here so upstream failures (402/429/400)
              // are caught before we commit to a streaming response.
              const reader = result.textStream.getReader();
              const first = await reader.read();
              if (first.done) {
                // Empty stream = upstream rejected the call; read the real reason.
                try {
                  await Promise.resolve(result.finishReason);
                  lastErr = "empty response from AI engine";
                } catch (e) {
                  lastErr = e instanceof Error ? e.message : "empty response";
                }
                console.error("[chat] empty stream", id, lastErr);
                continue;
              }



              const stream = new ReadableStream<Uint8Array>({
                async start(controller) {
                  const enc = new TextEncoder();
                  try {
                    if (!first.done && first.value) controller.enqueue(enc.encode(first.value));
                    while (true) {
                      const { value, done } = await reader.read();
                      if (done) break;
                      if (value) controller.enqueue(enc.encode(value));
                    }
                  } catch (e) {
                    controller.enqueue(
                      enc.encode(`\n\n⚠️ ${e instanceof Error ? e.message : "stream error"}`),
                    );
                  }
                  controller.close();
                },
              });

              return new Response(stream, {
                headers: { "Content-Type": "text/plain; charset=utf-8" },
              });
            } catch (e) {
              lastErr = e instanceof Error ? e.message : "Chat failed";
              console.error("[chat] engine failed", id, lastErr);
            }
          }
        } catch (e) {
          lastErr = e instanceof Error ? e.message : "Chat failed";
          console.error("[chat] fatal", lastErr);
        }

        const friendly = /credit|402|quota|payment/i.test(lastErr)
          ? "⚠️ Ashley is out of AI credits. Check the configured AI service credits to bring her back online."
          : `⚠️ ${lastErr}`;
        // 200 so the chat UI renders the reason instead of a blank error.
        return new Response(friendly, {
          status: 200,
          headers: { "Content-Type": "text/plain; charset=utf-8" },
        });
      },


    },
  },
});
