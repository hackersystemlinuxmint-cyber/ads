import { createFileRoute, Link } from "@tanstack/react-router";
import bloxLogo from "@/assets/ashleyblox-logo.png.asset.json";

import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  MessageSquare,
  Image as ImageIcon,
  Wand2,
  Mic,
  Volume2,
  Search,
  Music,
  ImagePlus,
  Send,
  Loader2,
  Square,
  Play,
  Pause,
  Upload,
  Link as LinkIcon,
  Video as VideoIcon,
  Infinity as InfinityIcon,
  Plus,
  Volume2 as VolumeOn,
  VolumeX,
  Mail as MailIcon,
  Monitor,
  Smartphone,
  Code2,
} from "lucide-react";
import { getUiMode, setUiMode, applyUiMode, type UiMode } from "@/lib/ui-mode";
import { LockdownOverlay } from "@/components/LockdownOverlay";
import { closeServer, openServer, isLocked, registerAttempt, kickToGmail, remainingLabel } from "@/lib/lockdown";
import { accountList, accountReset } from "@/lib/accounts";
import { AuthGate } from "@/components/AuthGate";
import { MailPanel } from "@/components/MailPanel";
import { BootScreen } from "@/components/BootScreen";
import { sfx, setMuted, isMuted, startBgm, stopBgm, isBgmOn } from "@/lib/sound";
import { CreditsBar, AshleyAvatar } from "@/components/CreditsBar";
import { HtmlRunner } from "@/components/HtmlRunner";
import { speakAshley, isVoiceOn, setVoiceOn, stopAshleyVoice, getVoiceLang, setVoiceLang, VOICE_LANGS, type VoiceLang } from "@/lib/ashley-voice";
import { AshleyFace } from "@/components/AshleyFace";

export const Route = createFileRoute("/")({
  component: () => (
    <BootScreen>
      <AuthGate>
        <Home />
      </AuthGate>
    </BootScreen>
  ),
});


type Msg = { role: "user" | "assistant"; content: string };
type Tab =
  | "chat"
  | "image"
  | "edit"
  | "tts"
  | "stt"
  | "web"
  | "songs"
  | "images"
  | "find"
  | "video"
  | "mail"
  | "html";

function Home() {
  const [tab, setTab] = useState<Tab>("chat");
  const [navOpen, setNavOpen] = useState(false);
  const [muted, setMutedState] = useState<boolean>(isMuted());
  const [voiceOn, setVoiceOnState] = useState<boolean>(true);
  const startedRef = useRef(false);

  const [voiceLang, setVoiceLangState] = useState<VoiceLang>("en");
  const [mode, setMode] = useState<UiMode>("desktop");

  useEffect(() => {
    setVoiceOnState(isVoiceOn());
    setVoiceLangState(getVoiceLang());
    const m = getUiMode();
    setMode(m);
    applyUiMode(m);
  }, []);

  const switchMode = (m: UiMode) => {
    sfx.click();
    setUiMode(m);
    setMode(m);
  };

  const toggleVoice = () => {
    const next = !voiceOn;
    setVoiceOn(next);
    setVoiceOnState(next);
    if (!next) stopAshleyVoice();
  };


  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    // Wait for first user gesture to unlock audio, then play startup once
    const kick = () => {
      sfx.startup();
      window.removeEventListener("pointerdown", kick);
      window.removeEventListener("keydown", kick);
    };
    window.addEventListener("pointerdown", kick, { once: true });
    window.addEventListener("keydown", kick, { once: true });
  }, []);

  const [bgmOn, setBgmOn] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setBgmOn(isBgmOn()), 500);
    return () => clearInterval(id);
  }, []);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    setMutedState(next);
    if (!next) sfx.click();
  };

  const selectTab = (t: Tab) => {
    setTab(t);
    setNavOpen(false);
    sfx.click();
  };

  return (
    <div className="ashley-shell min-h-screen w-full overflow-x-hidden">
      <div className="ashley-aurora" />
      <div className="ashley-aurora-b" />
      <div className="ashley-grid" />
      <div className="ashley-circuit" />

      <header className="ashley-container mx-auto flex flex-wrap items-center justify-between gap-2 px-3 py-4 sm:gap-3 sm:px-5 sm:py-6">
        <div className="flex min-w-0 items-center gap-2 sm:gap-3">
          <div className="ashley-orb rounded-2xl">
            <AshleyAvatar className="h-9 w-9 sm:h-11 sm:w-11" />
          </div>
          <AshleyFace className="h-11 w-11 sm:h-14 sm:w-14" />
          <div className="min-w-0">
            <h1 className="truncate text-lg font-bold tracking-tight sm:text-xl">
              Ashley<span className="ashley-text">AI</span>
            </h1>
            <p className="truncate text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:text-[11px]">
              ASH_AI · one AI · AshleyAI by TokemekiAi
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-1.5 sm:gap-2">
          <CreditsBar />
          <div className="glass flex items-center gap-1 rounded-full p-1" role="group" aria-label="Display mode">
            <button
              onClick={() => switchMode("desktop")}
              aria-pressed={mode === "desktop"}
              title="Desktop mode — wider layout, larger text"
              className={
                "flex h-7 items-center gap-1 rounded-full px-2 text-[10px] uppercase tracking-wider transition-all " +
                (mode === "desktop" ? "ashley-gradient text-primary-foreground" : "text-muted-foreground")
              }
            >
              <Monitor className="h-3.5 w-3.5" /> PC
            </button>
            <button
              onClick={() => switchMode("phone")}
              aria-pressed={mode === "phone"}
              title="Phone mode — compact layout that fits the screen"
              className={
                "flex h-7 items-center gap-1 rounded-full px-2 text-[10px] uppercase tracking-wider transition-all " +
                (mode === "phone" ? "ashley-gradient text-primary-foreground" : "text-muted-foreground")
              }
            >
              <Smartphone className="h-3.5 w-3.5" /> Phone
            </button>
          </div>
          <span className="ashley-badge hidden items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-foreground sm:inline-flex">
            <InfinityIcon className="h-3.5 w-3.5" />
            Unlimited chat
          </span>
          <span className="glass hidden sm:inline-flex items-center rounded-full px-3 py-1 text-[10px] font-mono tracking-wider text-muted-foreground">
            v9.20.20.00.3.2
          </span>
          <button
            onClick={() => { sfx.click(); toggleVoice(); }}
            aria-label={voiceOn ? "Turn off Ashley's voice" : "Turn on Ashley's voice"}
            className={
              "glass flex h-9 w-9 items-center justify-center rounded-full " +
              (voiceOn ? "text-primary" : "text-muted-foreground hover:text-foreground")
            }
            title="Ashley reads her messages aloud"
          >
            <Mic className="h-4 w-4" />
          </button>
          <select
            value={voiceLang}
            onChange={(e) => {
              sfx.click();
              const l = e.target.value as VoiceLang;
              setVoiceLang(l);
              setVoiceLangState(l);
            }}
            aria-label="Ashley voice language"
            title="Ashley's voice language (all voices are female)"
            className="glass rounded-full bg-transparent px-3 py-1.5 text-[11px] uppercase tracking-wider text-foreground outline-none"
          >
            {VOICE_LANGS.map((l) => (
              <option key={l.id} value={l.id} className="bg-background text-foreground">
                {l.label}
              </option>
            ))}
          </select>
          <button
            onClick={() => { sfx.click(); const n = !bgmOn; setBgmOn(n); if (n) startBgm(); else stopBgm(); }}
            aria-label={bgmOn ? "Turn off background song" : "Turn on background song"}
            title='Background song (say "background on" / "background off")'
            className={
              "glass flex h-9 w-9 items-center justify-center rounded-full " +
              (bgmOn ? "text-primary" : "text-muted-foreground hover:text-foreground")
            }
          >
            <Music className="h-4 w-4" />
          </button>
          <button
            onClick={() => { sfx.click(); toggleMute(); }}
            aria-label={muted ? "Unmute" : "Mute"}
            className="glass flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
          >
            {muted ? <VolumeX className="h-4 w-4" /> : <VolumeOn className="h-4 w-4" />}
          </button>
        </div>
      </header>


      <main className="ashley-container mx-auto px-3 pb-16 sm:px-5 sm:pb-24">
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => { sfx.click(); setNavOpen((o) => !o); }}
              onMouseEnter={() => sfx.hover()}
              aria-label={navOpen ? "Hide navigation" : "Show navigation"}
              aria-expanded={navOpen}
              className={
                "ashley-gradient flex h-11 w-11 items-center justify-center rounded-2xl text-primary-foreground shadow-lg shadow-primary/30 transition-transform duration-500 ease-out " +
                (navOpen ? "rotate-180" : "rotate-0")
              }
            >
              <Plus className="h-5 w-5" />
            </button>

            <Link
              to="/ashleyblox"
              onClick={() => sfx.click()}
              onMouseEnter={() => sfx.hover()}
              aria-label="Open AshleyBlox"
              title="AshleyBlox — play Ro-shooter"
              className="glass flex h-11 w-11 items-center justify-center rounded-2xl transition-transform hover:-translate-y-0.5"
            >
              <img src={bloxLogo.url} alt="AshleyBlox" className="h-8 w-8 rounded-xl" />
            </Link>
          </div>


          <div
            className={
              "grid transition-all duration-500 ease-out " +
              (navOpen
                ? "mt-3 grid-rows-[1fr] opacity-100 translate-y-0"
                : "mt-0 grid-rows-[0fr] opacity-0 -translate-y-2 pointer-events-none")
            }
          >
            <div className="overflow-hidden">
              <nav className="glass flex flex-wrap gap-1 rounded-2xl p-1.5">
                <TabButton icon={<MessageSquare className="h-4 w-4" />} label="Chat" active={tab === "chat"} onClick={() => selectTab("chat")} />
                <TabButton icon={<ImageIcon className="h-4 w-4" />} label="Image" active={tab === "image"} onClick={() => selectTab("image")} />
                <TabButton icon={<Wand2 className="h-4 w-4" />} label="Edit Image" active={tab === "edit"} onClick={() => selectTab("edit")} />
                <TabButton icon={<Volume2 className="h-4 w-4" />} label="Voice Gen" active={tab === "tts"} onClick={() => selectTab("tts")} />
                <TabButton icon={<Mic className="h-4 w-4" />} label="Voice Msg" active={tab === "stt"} onClick={() => selectTab("stt")} />
                <TabButton icon={<Search className="h-4 w-4" />} label="Web" active={tab === "web"} onClick={() => selectTab("web")} />
                <TabButton icon={<Music className="h-4 w-4" />} label="Songs" active={tab === "songs"} onClick={() => selectTab("songs")} />
                <TabButton icon={<ImagePlus className="h-4 w-4" />} label="Image Search" active={tab === "images"} onClick={() => selectTab("images")} />
                <TabButton icon={<LinkIcon className="h-4 w-4" />} label="Find Source" active={tab === "find"} onClick={() => selectTab("find")} />
                <TabButton icon={<VideoIcon className="h-4 w-4" />} label="Video" active={tab === "video"} onClick={() => selectTab("video")} />
                <TabButton icon={<MailIcon className="h-4 w-4" />} label="Mail" active={tab === "mail"} onClick={() => selectTab("mail")} />
                <TabButton icon={<Code2 className="h-4 w-4" />} label="HTML" active={tab === "html"} onClick={() => selectTab("html")} />
              </nav>
            </div>
          </div>
        </div>


        <section className="glass ashley-scan ashley-panel rounded-3xl p-3 sm:p-6">
          <div className="hud-corners" />
          {tab === "chat" && <ChatPanel />}
          {tab === "image" && <ImageGenPanel />}
          {tab === "edit" && <ImageEditPanel />}
          {tab === "tts" && <TtsPanel />}
          {tab === "stt" && <SttPanel />}
          {tab === "web" && <WebSearchPanel />}
          {tab === "songs" && <SongsPanel />}
          {tab === "images" && <ImageSearchPanel />}
          {tab === "find" && <ReverseImagePanel />}
          {tab === "video" && <VideoPanel />}
          {tab === "mail" && <MailPanel />}
          {tab === "html" && <HtmlRunner />}
        </section>

        <p className="mt-4 text-center text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
          ∞ unlimited chat · no limits · always on ·{" "}
          <span className="font-mono normal-case tracking-wider">v9.20.20.00.3.2</span>
        </p>
      </main>
    </div>
  );
}


function TabButton({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={() => { sfx.click(); onClick(); }}
      onMouseEnter={() => sfx.hover()}
      className={
        "flex flex-1 min-w-[110px] items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition-all " +
        (active
          ? "ashley-gradient text-primary-foreground shadow-md shadow-primary/30"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground")
      }
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

/* ---------------- CHAT ---------------- */
function ChatPanel() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi, I'm **AshleyAI** ✨ — ask me anything or try one of the tools above." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [locked, setLocked] = useState(false);
  const [showLock, setShowLock] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    setLocked(isLocked());
    const id = window.setInterval(() => setLocked(isLocked()), 20_000);
    return () => window.clearInterval(id);
  }, []);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;
    const low = text.toLowerCase();

    // Admin re-opens the servers.
    if (/^\/(open|start)\s*server/.test(low)) {
      openServer();
      setLocked(false);
      setShowLock(false);
      setInput("");
      setMessages([
        ...messages,
        { role: "user", content: text },
        { role: "assistant", content: "🟢 Servers are back **online**. Thanks for undoing it, admin ✨" },
      ]);
      return;
    }

    // Servers are down — every attempt gets the warning, then a bounce to Gmail.
    if (isLocked()) {
      sfx.error();
      const tries = registerAttempt();
      setShowLock(true);
      setInput("");
      if (tries >= 3) {
        window.setTimeout(kickToGmail, 1200);
      }
      return;
    }

    sfx.send();

    // Shutdown command
    if (/^\/close\s*server/.test(low)) {
      closeServer();
      setLocked(true);
      setShowLock(true);
      setInput("");
      setMessages([
        ...messages,
        { role: "user", content: text },
        {
          role: "assistant",
          content: `🔒 **All AshleyAI servers are shutting down** for 5 hours (${remainingLabel()} left). Only the admin can undo it with \`/open server\`.`,
        },
      ]);
      return;
    }

    // Admin account tools: /pass lists every registered account, /reset issues a
    // one-time recovery code. Passwords themselves are encrypted and unreadable.
    if (/^\/(pass|accounts)\b/.test(low) || /^\/reset\b/.test(low)) {
      let me = "";
      try {
        me = (JSON.parse(localStorage.getItem("ashley.demo.session") || "{}") as { email?: string }).email || "";
      } catch {
        me = "";
      }
      setInput("");
      const push = (content: string) =>
        setMessages([...messages, { role: "user", content: text }, { role: "assistant", content }]);

      if (/^\/reset\b/.test(low)) {
        const target = text.split(/\s+/)[1] ?? "";
        const r = await accountReset(me, target);
        push(
          r.error
            ? `⚠️ ${r.error}`
            : `🔑 Recovery code for **${r.target}**: \`${r.code}\`\n\nGive it to them — it works once and expires in ${r.expiresInMinutes} minutes. They enter it on the **Recover** tab of the sign-in screen to set a new password.`,
        );
        return;
      }

      const r = await accountList(me);
      if (r.error) {
        push(`⚠️ ${r.error}`);
        return;
      }
      const rows = r.accounts ?? [];
      push(
        rows.length === 0
          ? "No accounts registered yet."
          : `📋 **Registered accounts (${rows.length})**\n\n` +
              rows
                .map(
                  (a, i) =>
                    `${i + 1}. ${a.email} — joined ${new Date(a.created_at).toLocaleDateString()}${a.reset_expires_at ? " · reset code pending" : ""}`,
                )
                .join("\n") +
              "\n\nPasswords are encrypted and cannot be shown. To recover a lost account use `/reset [email]`.",
      );
      return;
    }


    // Tsundere / yandere tease
    const tt = low.match(/\b(tsundere|tandere|yandere)\b/);
    if (tt && /\b(you'?re|your|ur|you are)\b/.test(low)) {
      const word = tt[1] === "yandere" ? "yandere" : "tsundere";
      setInput("");
      setMessages([
        ...messages,
        { role: "user", content: text },
        { role: "assistant", content: `Hmp! I am not a ${word} 😤` },
      ]);
      speakAshley(`Hmp! I am not a ${word}`);
      return;
    }



    // Background music command: "background on" / "background off"
    const bg = text.toLowerCase().match(/\b(background|backround|bgm|music)\b[^a-z]*\b(on|off|play|stop)\b/);
    if (bg) {
      const turnOn = bg[2] === "on" || bg[2] === "play";
      if (turnOn) startBgm(); else stopBgm();
      setInput("");
      setMessages([
        ...messages,
        { role: "user", content: text },
        {
          role: "assistant",
          content: turnOn
            ? "🎵 Background song is **ON** — playing a calm blocky-world style loop. Say \"background off\" to stop it."
            : "🔇 Background song is **OFF**. Say \"background on\" to bring it back.",
        },
      ]);
      return;
    }

    const next: Msg[] = [...messages, { role: "user", content: text }, { role: "assistant", content: "" }];
    setMessages(next);
    setInput("");
    setLoading(true);
    let gotFirstChunk = false;
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next
            .slice(0, -1)
            .map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      if (!res.ok || !res.body) throw new Error(await res.text());
      const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
      let acc = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (!gotFirstChunk) {
          gotFirstChunk = true;
          sfx.receive();
        }
        acc += value;
        setMessages((cur) => {
          const copy = cur.slice();
          copy[copy.length - 1] = { role: "assistant", content: acc };
          return copy;
        });
      }
      if (acc) speakAshley(acc);
    } catch (e) {
      sfx.error();
      setMessages((cur) => {
        const copy = cur.slice();
        copy[copy.length - 1] = { role: "assistant", content: "⚠️ " + (e instanceof Error ? e.message : "Failed") };
        return copy;
      });
    } finally {
      setLoading(false);
    }
  }, [input, loading, messages]);


  return (
    <div className="flex h-[68vh] flex-col">
      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto pr-1">
        {messages.map((m, i) => {
          const isLast = i === messages.length - 1;
          const showThinking = m.role === "assistant" && isLast && loading && !m.content;
          return (
            <div key={i} className={"flex " + (m.role === "user" ? "justify-end" : "justify-start")}>
              <div
                className={
                  "prose-ashley max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed " +
                  (m.role === "user"
                    ? "ashley-gradient text-primary-foreground"
                    : "bg-secondary text-foreground")
                }
              >
                {showThinking ? (
                  <ThinkingIndicator />
                ) : m.role === "assistant" ? (
                  <ReactMarkdown>{m.content || "…"}</ReactMarkdown>
                ) : (
                  <p className="whitespace-pre-wrap">{m.content}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex items-end gap-2">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder="Message Ashley…"
          rows={1}
          className="max-h-40 min-h-[44px] flex-1 resize-none rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          className="ashley-gradient flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-primary-foreground shadow-lg shadow-primary/30 disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
        </button>
      </div>
    </div>
  );
}

function ThinkingIndicator() {
  return (
    <div className="flex items-center gap-2">
      <span className="ashley-thinking-text bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent font-medium">
        Thinking
      </span>
      <span className="flex gap-1">
        <span className="ashley-dot" style={{ animationDelay: "0ms" }} />
        <span className="ashley-dot" style={{ animationDelay: "150ms" }} />
        <span className="ashley-dot" style={{ animationDelay: "300ms" }} />
      </span>
      <span className="ashley-thinking-text bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent font-medium">!</span>
    </div>
  );
}

/* ---------------- IMAGE GEN ---------------- */
function ImageGenPanel() {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [img, setImg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const generate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!r.ok) throw new Error(await r.text());
      const j = (await r.json()) as { image: string };
      setImg(j.image);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="space-y-4">
      <PanelHeader title="Image generator" desc="Describe anything — Ashley paints it." />
      <div className="flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && generate()}
          placeholder="A neon jellyfish drifting through Tokyo streets…"
          className="flex-1 rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
        />
        <PrimaryButton onClick={generate} loading={loading} icon={<Wand2 className="h-4 w-4" />}>
          Generate
        </PrimaryButton>
      </div>
      {err && <ErrorLine msg={err} />}
      <div className="flex min-h-[320px] items-center justify-center rounded-2xl border border-dashed border-border bg-input/40 p-4">
        {loading ? (
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        ) : img ? (
          <img src={img} alt="Generated" className="max-h-[520px] rounded-xl" />
        ) : (
          <p className="text-sm text-muted-foreground">Your image will appear here</p>
        )}
      </div>
      {img && (
        <a
          href={img}
          download="ashley-image.png"
          className="inline-flex items-center gap-2 text-sm text-accent hover:underline"
        >
          Download
        </a>
      )}
    </div>
  );
}

/* ---------------- IMAGE EDIT ---------------- */
function ImageEditPanel() {
  const [prompt, setPrompt] = useState("");
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [outImage, setOutImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const onFile = (f: File) => {
    const reader = new FileReader();
    reader.onload = () => setSrcImage(reader.result as string);
    reader.readAsDataURL(f);
  };

  const run = async () => {
    if (!prompt.trim() || !srcImage) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/image-edit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, image: srcImage }),
      });
      if (!r.ok) throw new Error(await r.text());
      const j = (await r.json()) as { image: string };
      setOutImage(j.image);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <PanelHeader title="Edit image by text" desc="Upload an image, describe the change." />
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-dashed border-border bg-input/40 px-4 py-6 text-sm text-muted-foreground hover:border-primary hover:text-foreground">
        <Upload className="h-4 w-4" />
        {srcImage ? "Replace image" : "Upload an image"}
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
        />
      </label>
      <div className="flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && run()}
          placeholder="Make the sky sunset orange, add fireflies…"
          className="flex-1 rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
        />
        <PrimaryButton onClick={run} loading={loading} icon={<Wand2 className="h-4 w-4" />} disabled={!srcImage}>
          Edit
        </PrimaryButton>
      </div>
      {err && <ErrorLine msg={err} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <PreviewBox label="Original">
          {srcImage ? <img src={srcImage} className="max-h-[360px] rounded-xl" alt="src" /> : <EmptyText>Upload above</EmptyText>}
        </PreviewBox>
        <PreviewBox label="Result">
          {loading ? (
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          ) : outImage ? (
            <img src={outImage} className="max-h-[360px] rounded-xl" alt="out" />
          ) : (
            <EmptyText>Result appears here</EmptyText>
          )}
        </PreviewBox>
      </div>
    </div>
  );
}

/* ---------------- TTS ---------------- */
function TtsPanel() {
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("alloy");
  const [audio, setAudio] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const speak = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice }),
      });
      if (!r.ok) throw new Error(await r.text());
      const blob = await r.blob();
      setAudio(URL.createObjectURL(blob));
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <PanelHeader title="Voice generator" desc="Turn text into a natural voice." />
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={5}
        placeholder="Hey there, this is Ashley speaking…"
        className="w-full rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
      />
      <div className="flex flex-wrap items-center gap-2">
        <select
          value={voice}
          onChange={(e) => setVoice(e.target.value)}
          className="rounded-2xl border border-border bg-input px-3 py-2 text-sm outline-none focus:border-primary"
        >
          {["alloy", "ash", "ballad", "coral", "echo", "sage", "shimmer", "verse"].map((v) => (
            <option key={v} value={v}>
              {v}
            </option>
          ))}
        </select>
        <PrimaryButton onClick={speak} loading={loading} icon={<Volume2 className="h-4 w-4" />}>
          Speak
        </PrimaryButton>
      </div>
      {err && <ErrorLine msg={err} />}
      {audio && <audio className="w-full" controls src={audio} />}
    </div>
  );
}

/* ---------------- STT (Voice message) ---------------- */
function SttPanel() {
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recRef = useRef<MediaRecorder | null>(null);

  const start = async () => {
    setErr(null);
    setTranscript("");
    setAudioUrl(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        setAudioUrl(URL.createObjectURL(blob));
        setLoading(true);
        try {
          const fd = new FormData();
          fd.append("file", blob, "recording.webm");
          const r = await fetch("/api/stt", { method: "POST", body: fd });
          if (!r.ok) throw new Error(await r.text());
          const j = (await r.json()) as { text: string };
          setTranscript(j.text);
        } catch (e) {
          setErr(e instanceof Error ? e.message : "Failed");
        } finally {
          setLoading(false);
        }
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Mic error");
    }
  };
  const stop = () => {
    recRef.current?.stop();
    setRecording(false);
  };

  return (
    <div className="space-y-4">
      <PanelHeader title="Voice message" desc="Record and Ashley transcribes it." />
      <div className="flex items-center gap-3">
        {!recording ? (
          <PrimaryButton onClick={start} icon={<Mic className="h-4 w-4" />}>
            Start recording
          </PrimaryButton>
        ) : (
          <button
            onClick={stop}
            className="flex items-center gap-2 rounded-2xl bg-destructive px-4 py-2.5 text-sm font-semibold text-destructive-foreground"
          >
            <Square className="h-4 w-4" />
            Stop
          </button>
        )}
        {recording && <span className="text-sm text-primary animate-pulse">● recording…</span>}
      </div>
      {audioUrl && <audio controls src={audioUrl} className="w-full" />}
      {loading && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Transcribing…
        </div>
      )}
      {err && <ErrorLine msg={err} />}
      {transcript && (
        <div className="rounded-2xl border border-border bg-input/50 p-4 text-sm">
          <div className="mb-1 text-xs uppercase tracking-wide text-muted-foreground">Transcript</div>
          {transcript}
        </div>
      )}
    </div>
  );
}

/* ---------------- WEB SEARCH ---------------- */
function WebSearchPanel() {
  const [q, setQ] = useState("");
  const [data, setData] = useState<{
    heading: string;
    abstract: string;
    url: string;
    image: string;
    related: { title: string; url: string }[];
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    if (!q.trim()) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/search?q=" + encodeURIComponent(q));
      if (!r.ok) throw new Error(await r.text());
      setData(await r.json());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <PanelHeader title="Online search" desc="Instant answers from the web." />
      <SearchBar q={q} setQ={setQ} onSearch={run} loading={loading} placeholder="Search anything…" />
      {err && <ErrorLine msg={err} />}
      {data && (
        <div className="space-y-4">
          {data.heading && (
            <div className="rounded-2xl border border-border bg-input/40 p-4">
              <h3 className="text-lg font-semibold">{data.heading}</h3>
              {data.abstract && <p className="mt-2 text-sm text-muted-foreground">{data.abstract}</p>}
              {data.url && (
                <a href={data.url} target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm text-accent hover:underline">
                  Read more →
                </a>
              )}
            </div>
          )}
          {data.related.length > 0 && (
            <ul className="grid gap-2 sm:grid-cols-2">
              {data.related.map((r, i) => (
                <li key={i}>
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noreferrer"
                    className="block rounded-xl border border-border bg-input/40 p-3 text-sm hover:border-primary"
                  >
                    {r.title}
                  </a>
                </li>
              ))}
            </ul>
          )}
          {!data.heading && data.related.length === 0 && (
            <p className="text-sm text-muted-foreground">No instant answer. Try a more specific query.</p>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------------- SONGS ---------------- */
function SongsPanel() {
  const [q, setQ] = useState("");
  const [songs, setSongs] = useState<
    Array<{ id: number; title: string; artist: string; album: string; artwork: string; preview?: string; link?: string }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const run = async () => {
    if (!q.trim()) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/songs?q=" + encodeURIComponent(q));
      if (!r.ok) throw new Error(await r.text());
      const j = await r.json();
      setSongs(j.results);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  const toggle = (id: number, preview?: string) => {
    if (!preview) return;
    if (playingId === id) {
      audioRef.current?.pause();
      setPlayingId(null);
      return;
    }
    if (!audioRef.current) audioRef.current = new Audio();
    audioRef.current.src = preview;
    audioRef.current.play();
    audioRef.current.onended = () => setPlayingId(null);
    setPlayingId(id);
  };

  return (
    <div className="space-y-4">
      <PanelHeader title="Songs search" desc="Find music with 30-second previews." />
      <SearchBar q={q} setQ={setQ} onSearch={run} loading={loading} placeholder="Artist, song, or album…" />
      {err && <ErrorLine msg={err} />}
      <ul className="grid gap-3 sm:grid-cols-2">
        {songs.map((s) => (
          <li key={s.id} className="flex items-center gap-3 rounded-2xl border border-border bg-input/40 p-3">
            <img src={s.artwork} alt="" className="h-14 w-14 rounded-lg" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold">{s.title}</div>
              <div className="truncate text-xs text-muted-foreground">
                {s.artist} · {s.album}
              </div>
            </div>
            {s.preview && (
              <button
                onClick={() => toggle(s.id, s.preview)}
                className="ashley-gradient flex h-9 w-9 items-center justify-center rounded-full text-primary-foreground"
              >
                {playingId === s.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ---------------- IMAGE SEARCH ---------------- */
function ImageSearchPanel() {
  const [q, setQ] = useState("");
  const [imgs, setImgs] = useState<
    Array<{ id: string; title: string; url: string; thumb: string; link?: string; creator?: string }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const run = async () => {
    if (!q.trim()) return;
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/image-search?q=" + encodeURIComponent(q));
      if (!r.ok) throw new Error(await r.text());
      const j = await r.json();
      setImgs(j.results);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="space-y-4">
      <PanelHeader title="Image search" desc="Openverse — millions of open-licensed images." />
      <SearchBar q={q} setQ={setQ} onSearch={run} loading={loading} placeholder="Sunset, cats, architecture…" />
      {err && <ErrorLine msg={err} />}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
        {imgs.map((i) => (
          <a
            key={i.id}
            href={i.link ?? i.url}
            target="_blank"
            rel="noreferrer"
            className="group relative aspect-square overflow-hidden rounded-xl border border-border"
          >
            <img src={i.thumb} alt={i.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
            {i.creator && (
              <div className="absolute inset-x-0 bottom-0 truncate bg-gradient-to-t from-black/70 to-transparent px-2 py-1 text-[10px] text-white opacity-0 group-hover:opacity-100">
                © {i.creator}
              </div>
            )}
          </a>
        ))}
      </div>
    </div>
  );
}

/* ---------------- REVERSE IMAGE (Find Source) ---------------- */
function ReverseImagePanel() {
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [data, setData] = useState<{
    query?: string;
    message?: string | null;
    results: { platform: string; label: string; hits: { title: string; url: string }[] }[];
  } | null>(null);

  const onFile = (f: File) => {
    const reader = new FileReader();
    reader.onload = () => setSrcImage(reader.result as string);
    reader.readAsDataURL(f);
  };

  const run = async () => {
    if (!srcImage) return;
    setLoading(true);
    setErr(null);
    setData(null);
    try {
      const r = await fetch("/api/reverse-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: srcImage }),
      });
      if (!r.ok) throw new Error(await r.text());
      setData(await r.json());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <PanelHeader
        title="Find source"
        desc="Upload an image — Ashley scans it and searches TikTok, YouTube, Facebook & Instagram."
      />
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-dashed border-border bg-input/40 px-4 py-6 text-sm text-muted-foreground hover:border-primary hover:text-foreground">
        <Upload className="h-4 w-4" />
        {srcImage ? "Replace image" : "Upload an image"}
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
        />
      </label>
      {srcImage && (
        <div className="flex items-start gap-3">
          <img src={srcImage} alt="src" className="max-h-40 rounded-xl" />
          <PrimaryButton onClick={run} loading={loading} icon={<Search className="h-4 w-4" />}>
            Find source
          </PrimaryButton>
        </div>
      )}
      {err && <ErrorLine msg={err} />}
      {data && (
        <div className="space-y-3">
          {data.query && (
            <p className="text-xs text-muted-foreground">
              Searched for: <span className="text-foreground">{data.query}</span>
            </p>
          )}
          {data.message && (
            <div className="rounded-2xl border border-border bg-input/40 p-4 text-sm text-muted-foreground">
              {data.message}
            </div>
          )}
          <div className="grid gap-3 sm:grid-cols-2">
            {data.results.map((r) => (
              <div key={r.platform} className="rounded-2xl border border-border bg-input/40 p-3">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-accent">
                  {r.label}
                </div>
                {r.hits.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No link found</p>
                ) : (
                  <ul className="space-y-1.5">
                    {r.hits.map((h, i) => (
                      <li key={i}>
                        <a
                          href={h.url}
                          target="_blank"
                          rel="noreferrer"
                          className="line-clamp-2 text-xs text-foreground hover:text-accent hover:underline"
                        >
                          {h.title || h.url}
                        </a>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- shared bits ---------------- */
/* ---------------- Video generation ---------------- */
function VideoPanel() {
  const [prompt, setPrompt] = useState("");
  const [srcImage, setSrcImage] = useState<string | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("");
  const [err, setErr] = useState<string | null>(null);

  const onFile = (f: File) => {
    const reader = new FileReader();
    reader.onload = () => setSrcImage(reader.result as string);
    reader.readAsDataURL(f);
  };

  const run = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setErr(null);
    setVideo(null);
    setStatus("Sending to Ashley's video engine…");
    try {
      const r = await fetch("/api/video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, image: srcImage }),
      });
      if (!r.ok) throw new Error(await r.text());
      const { id } = (await r.json()) as { id: string };

      for (let i = 0; i < 90; i++) {
        await new Promise((res) => setTimeout(res, 6000));
        const p = await fetch(`/api/video?id=${encodeURIComponent(id)}`);
        if (!p.ok) throw new Error(await p.text());
        const j = (await p.json()) as {
          status: string;
          progress?: number;
          video?: string;
          error?: string | null;
        };
        if (j.status === "completed" && j.video) {
          setVideo(j.video);
          setStatus("Done!");
          sfx.success?.();
          return;
        }
        if (j.status === "failed") throw new Error(j.error || "Video generation failed");
        setStatus(`Rendering… ${j.progress ?? 0}%`);
      }
      throw new Error("Timed out while rendering");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
      setStatus("");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <PanelHeader
        title="Video generator"
        desc="Upload an image + prompt — e.g. “animate it into singing, add audio, voice: Alastor”."
      />
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-dashed border-border bg-input/40 px-4 py-6 text-sm text-muted-foreground hover:border-primary hover:text-foreground">
        <Upload className="h-4 w-4" />
        {srcImage ? "Replace image" : "Upload an image (optional)"}
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
        />
      </label>
      <div className="flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && run()}
          placeholder="Animate it into singing and add audio, voice: Alastor"
          className="flex-1 rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
        />
        <PrimaryButton onClick={run} loading={loading} icon={<VideoIcon className="h-4 w-4" />}>
          Generate
        </PrimaryButton>
      </div>
      {loading && (
        <p className="text-xs text-muted-foreground">{status} (this takes 1–3 minutes)</p>
      )}
      {err && <ErrorLine msg={err} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <PreviewBox label="Source image">
          {srcImage ? (
            <img src={srcImage} className="max-h-[360px] rounded-xl" alt="source" />
          ) : (
            <EmptyText>Optional — text-only also works</EmptyText>
          )}
        </PreviewBox>
        <PreviewBox label="Video">
          {loading ? (
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          ) : video ? (
            <video src={video} controls className="max-h-[360px] w-full rounded-xl" />
          ) : (
            <EmptyText>Your video appears here</EmptyText>
          )}
        </PreviewBox>
      </div>
    </div>
  );
}

function PanelHeader({ title, desc }: { title: string; desc: string }) {
  return (
    <div>
      <h2 className="text-xl font-bold">{title}</h2>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}
function PrimaryButton({
  onClick,
  children,
  loading,
  icon,
  disabled,
}: {
  onClick: () => void;
  children: React.ReactNode;
  loading?: boolean;
  icon?: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={() => { if (!(loading || disabled)) sfx.click(); onClick(); }}
      onMouseEnter={() => { if (!(loading || disabled)) sfx.hover(); }}
      disabled={loading || disabled}
      className="ashley-gradient inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-md shadow-primary/20 disabled:opacity-50"
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : icon}
      {children}
    </button>
  );
}
function ErrorLine({ msg }: { msg: string }) {
  return <div className="rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive-foreground">⚠️ {msg}</div>;
}
function PreviewBox({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-input/40 p-3">
      <div className="mb-2 text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="flex min-h-[280px] items-center justify-center">{children}</div>
    </div>
  );
}
function EmptyText({ children }: { children: React.ReactNode }) {
  return <p className="text-sm text-muted-foreground">{children}</p>;
}
function SearchBar({
  q,
  setQ,
  onSearch,
  loading,
  placeholder,
}: {
  q: string;
  setQ: (v: string) => void;
  onSearch: () => void;
  loading: boolean;
  placeholder: string;
}) {
  return (
    <div className="flex gap-2">
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && onSearch()}
        placeholder={placeholder}
        className="flex-1 rounded-2xl border border-border bg-input px-4 py-3 text-sm outline-none focus:border-primary"
      />
      <PrimaryButton onClick={onSearch} loading={loading} icon={<Search className="h-4 w-4" />}>
        Search
      </PrimaryButton>
    </div>
  );
}
