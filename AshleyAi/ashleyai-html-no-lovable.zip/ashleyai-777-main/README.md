# AshleyAI

AshleyAI is a browser-based React/TanStack application with chat, media tools, and an in-browser HTML/CSS/JavaScript runner.

## HTML Runner

Open the **HTML** tab, edit the HTML/CSS/JavaScript, and press **Run HTML**. The preview runs inside a sandboxed browser iframe. **Live preview** can be enabled for automatic updates while editing.

## Development

```bash
npm install
npm run dev
```

Then open the local URL printed by Vite.

## Production

```bash
npm run build
npm run preview
```

The AI/media features still require their configured backend environment variables. The HTML runner itself works entirely in the browser and does not need an AI API.
