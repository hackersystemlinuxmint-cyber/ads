CREATE TABLE public.ashley_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  reset_code_hash text,
  reset_expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.ashley_accounts TO service_role;

ALTER TABLE public.ashley_accounts ENABLE ROW LEVEL SECURITY;

CREATE INDEX ashley_accounts_created_idx ON public.ashley_accounts (created_at);