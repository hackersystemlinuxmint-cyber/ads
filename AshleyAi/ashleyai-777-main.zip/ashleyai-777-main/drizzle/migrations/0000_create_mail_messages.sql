CREATE TABLE public.mail_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_email text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('out','in')),
  from_email text NOT NULL,
  to_email text NOT NULL,
  subject text NOT NULL DEFAULT '',
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX mail_messages_thread_idx ON public.mail_messages (thread_email, created_at);

GRANT ALL ON public.mail_messages TO service_role;

ALTER TABLE public.mail_messages ENABLE ROW LEVEL SECURITY;
