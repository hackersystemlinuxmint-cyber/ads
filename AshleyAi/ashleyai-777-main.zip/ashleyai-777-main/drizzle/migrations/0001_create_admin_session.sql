CREATE TABLE public.admin_session (
  email text PRIMARY KEY,
  token text NOT NULL,
  claimed_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.admin_session TO service_role;

ALTER TABLE public.admin_session ENABLE ROW LEVEL SECURITY;
