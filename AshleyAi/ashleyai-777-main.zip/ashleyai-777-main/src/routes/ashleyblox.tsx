import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Copy, Loader2, MoreVertical, Users, Wifi } from "lucide-react";
import logo from "@/assets/ashleyblox-logo.png.asset.json";
import cover from "@/assets/roshooter-cover.png.asset.json";
import robuxIcon from "@/assets/ashleyblox-robux.png.asset.json";
import { sfx } from "@/lib/sound";
import { useCredits } from "@/lib/credits";
import {
  DEFAULT_AVATAR,
  FIGHT_STYLES,
  MAPS,
  SKILLS,
  WEAPONS,
  ageFromBirthday,
  loadBlox,
  saveBlox,
  tierForAge,
  type BloxAvatar,
  type BloxSave,
} from "@/lib/ashleyblox";
import {
  GEM_PACKS,
  PRIVATE_SERVER_ROBUX,
  ROBUX_PACKS,
  isAndroid,
  spendRobux,
  useRobux,
} from "@/lib/robux";
import { createPrivateServer, joinPrivateServer, myPrivateServers, type PrivateServer } from "@/lib/blox-servers";
import { RoShooter } from "@/components/ashleyblox/RoShooter";
import { MapGenLoader } from "@/components/ashleyblox/MapGenLoader";
import {
  ADMIN_EMAIL,
  ADMIN_NAME,
  ADMIN_PASSWORD,
  claimName,
  fetchRanking,
  loadIdentity,
  saveIdentity,
  type BloxIdentity,
} from "@/lib/blox-auth";


export const Route = createFileRoute("/ashleyblox")({
  head: () => ({
    meta: [
      { title: "AshleyBlox — play Ro-shooter by TokemekiAi" },
      {
        name: "description",
        content:
          "AshleyBlox is TokemekiAi's game hub: build your blocky avatar, join a Ro-shooter server, vote a map and battle free-for-all.",
      },
      { property: "og:title", content: "AshleyBlox — play Ro-shooter by TokemekiAi" },
      {
        property: "og:description",
        content: "Make your avatar, join a Ro-shooter server and battle free-for-all on 6 maps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AshleyBloxPage,
});

type Step = "auth" | "signup" | "face" | "avatar" | "hub" | "connect" | "lobby" | "generate" | "play";

/** Verified check badge (AshleyBlox's own mark). */
function CheckBadge({ className = "h-3.5 w-3.5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-label="Verified" role="img">
      <rect x="1.5" y="1.5" width="21" height="21" rx="4" fill="#0066ff" transform="rotate(-4 12 12)" />
      <path d="M6.8 12.4l3.4 3.6 7-7.4" fill="none" stroke="#fff" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AvatarDoll({ a, className = "" }: { a: BloxAvatar; className?: string }) {
  return (
    <svg viewBox="0 0 100 150" className={className} aria-label={`${a.charName} avatar`} role="img">
      <rect x="34" y="6" width="32" height="12" rx="3" fill={a.hair} />
      <rect x="32" y="14" width="36" height="30" rx="4" fill={a.skin} />
      <circle cx="42" cy="28" r="3" fill="#1b1430" />
      <circle cx="58" cy="28" r="3" fill="#1b1430" />
      {a.face === "smile" && <path d="M42 36 q8 6 16 0" stroke="#1b1430" strokeWidth="2" fill="none" />}
      {a.face === "cool" && <rect x="38" y="24" width="24" height="7" rx="2" fill="#1b1430" />}
      {a.face === "wink" && <path d="M38 28 h8" stroke="#1b1430" strokeWidth="3" />}
      {a.face === "serious" && <path d="M42 37 h16" stroke="#1b1430" strokeWidth="2" />}
      <rect x="30" y="48" width="40" height="42" rx="4" fill={a.shirt} />
      <rect x="14" y="48" width="14" height="40" rx="4" fill={a.shirt} />
      <rect x="72" y="48" width="14" height="40" rx="4" fill={a.shirt} />
      <rect x="14" y="86" width="14" height="12" rx="3" fill={a.skin} />
      <rect x="72" y="86" width="14" height="12" rx="3" fill={a.skin} />
      <rect x="31" y="92" width="17" height="44" rx="4" fill={a.pants} />
      <rect x="52" y="92" width="17" height="44" rx="4" fill={a.pants} />
    </svg>
  );
}

function AshleyBloxPage() {
  const [save, setSave] = useState<BloxSave>(() => loadBlox());
  const [step, setStep] = useState<Step>("auth");
  const [identity, setIdentity] = useState<BloxIdentity | null>(null);
  const { credits } = useCredits();

  useEffect(() => {
    const s = loadBlox();
    const id = loadIdentity();
    setSave(s);
    setIdentity(id);
    setStep(id && s.loggedIn && s.account && s.avatar ? "hub" : s.account ? "avatar" : "auth");
  }, []);

  const goLobby = useCallback(() => setStep("lobby"), []);

  const setIdent = useCallback((id: BloxIdentity | null) => {
    setIdentity(id);
    saveIdentity(id);
  }, []);

  const persist = useCallback((next: BloxSave) => {
    setSave(next);
    saveBlox(next);
  }, []);

  const tier = save.account?.tier ?? "OPEN";

  if (step === "generate") {
    return <MapGenLoader mapId={playMapRef.current} onDone={() => setStep("play")} />;
  }

  if (step === "play" && identity) {
    return (
      <RoShooter
        mapId={playMapRef.current}
        avatar={save.avatar ?? DEFAULT_AVATAR}
        weaponId={equippedRef.current}
        styleId={save.style ?? "brawler"}
        ownedWeapons={save.ownedWeapons ?? ["fists"]}
        ownedSkills={save.ownedSkills ?? ["dash"]}
        identity={identity}
        serverId={serverRef.current}
        serverLabel={inviteRef.current ? `Private ${inviteRef.current}` : undefined}
        onLeave={() => {
          sfx.click();
          setStep("hub");
        }}
      />
    );
  }


  return (
    <div className="min-h-screen">
      <div className="ashley-aurora" />
      <div className="ashley-grid" />

      <header className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-5 py-5">
        <div className="flex items-center gap-3">
          <img src={logo.url} alt="AshleyBlox logo" className="h-11 w-11 rounded-2xl shadow-lg shadow-primary/30" />
          <div>
            <h1 className="text-lg font-bold tracking-tight">
              Ashley<span className="ashley-text">Blox</span>
              {tier !== "OPEN" && (
                <span className="ml-2 rounded-full bg-primary/20 px-2 py-0.5 align-middle text-[10px] font-bold tracking-widest text-primary">
                  {tier}
                </span>
              )}
            </h1>
            <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">by TokemekiAi</p>
          </div>
        </div>
        <Link
          to="/"
          onClick={() => sfx.click()}
          className="glass inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> AshleyAI
        </Link>
      </header>

      <main className="mx-auto max-w-5xl px-5 pb-24">
        {step === "auth" && (
          <AuthSlide
            save={save}
            persist={persist}
            setIdentity={setIdent}
            onSignup={() => setStep("signup")}
            onDone={(target) => setStep(target)}
          />
        )}
        {step === "signup" && <SignupSlide persist={persist} save={save} onNext={() => setStep("face")} />}
        {step === "face" && <FaceSlide save={save} persist={persist} onNext={() => setStep("avatar")} />}
        {step === "avatar" && <AvatarSlide save={save} persist={persist} onNext={() => setStep("hub")} />}
        {step === "hub" && (
          <HubSlide
            save={save}
            persist={persist}
            credits={credits}
            onPlay={() => setStep("connect")}
            onLogout={() => {
              persist({ ...save, loggedIn: false });
              setStep("auth");
            }}
          />
        )}
        {step === "connect" && <ConnectSlide onReady={goLobby} />}
        {step === "lobby" && (
          <LobbySlide
            save={save}
            persist={persist}
            onStart={(mapId, weaponId) => {
              playMapRef.current = mapId;
              equippedRef.current = weaponId;
              setStep("generate");
            }}
            onBack={() => setStep("hub")}
          />
        )}
      </main>
    </div>
  );
}

const playMapRef = { current: MAPS[0].id };
const equippedRef = { current: "fists" };
const serverRef = { current: "pub-1" };
/** Invite code of the private server you are in (empty for public matches). */
const inviteRef = { current: "" };


/* ---------------- Slides ---------------- */

function AuthSlide({
  save,
  persist,
  setIdentity,
  onSignup,
  onDone,
}: {
  save: BloxSave;
  persist: (s: BloxSave) => void;
  setIdentity: (i: BloxIdentity | null) => void;
  onSignup: () => void;
  onDone: (target: "hub" | "avatar") => void;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [player, setPlayer] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminPass, setAdminPass] = useState("");
  const [ranks, setRanks] = useState<{ name: string; kills: number; is_admin: boolean }[]>([]);

  useEffect(() => {
    void fetchRanking(5).then(setRanks);
  }, []);

  const isAdminEmail = email.trim().toLowerCase() === ADMIN_EMAIL;

  useEffect(() => {
    if (isAdminEmail && !player) setPlayer(ADMIN_NAME);
  }, [isAdminEmail, player]);

  const finish = (id: BloxIdentity) => {
    setIdentity(id);
    const next: BloxSave = {
      ...save,
      loggedIn: true,
      account:
        save.account ?? {
          first: id.name,
          last: id.isAdmin ? "Atienza" : "Player",
          birthday: "",
          age: id.isAdmin ? 15 : 20,
          tier: "OPEN",
          email: id.email,
          faceVerified: id.isAdmin,
          createdAt: new Date().toISOString(),
        },
      avatar: save.avatar ?? { ...DEFAULT_AVATAR, charName: id.name },
    };
    persist(next);
    sfx.success();
    onDone(save.avatar ? "hub" : "hub");
  };

  const signIn = async () => {
    setErr(null);
    if (!email.includes("@") || password.length < 6) {
      setErr("Enter a valid email and a password of at least 6 characters.");
      sfx.error();
      return;
    }
    const name = player.trim();
    if (name.length < 3) {
      setErr("Pick a player name (3-20 characters).");
      sfx.error();
      return;
    }
    setBusy(true);
    const res = await claimName(name, isAdminEmail ? ADMIN_PASSWORD : undefined);
    setBusy(false);
    if (!res.ok) {
      setErr(res.reason);
      sfx.error();
      return;
    }
    finish({ email: email.trim(), name, isAdmin: res.isAdmin || isAdminEmail, kills: res.kills });
  };

  const adminLogin = async () => {
    if (adminPass !== ADMIN_PASSWORD) {
      setErr("Wrong administrator password.");
      sfx.error();
      return;
    }
    setBusy(true);
    const res = await claimName(ADMIN_NAME, ADMIN_PASSWORD);
    setBusy(false);
    if (!res.ok) {
      setErr(res.reason);
      sfx.error();
      return;
    }
    finish({ email: ADMIN_EMAIL, name: ADMIN_NAME, isAdmin: true, kills: res.kills });
  };

  return (
    <section className="glass mx-auto max-w-md rounded-3xl p-6 text-center">
      <img src={logo.url} alt="AshleyBlox" className="mx-auto h-20 w-20 rounded-3xl shadow-xl shadow-primary/30" />
      <h2 className="mt-4 text-xl font-bold">Sign in to AshleyBlox</h2>
      <p className="mt-1 text-xs text-muted-foreground">Type your email, password and player name. Names are unique across all servers.</p>

      <div className="mt-5 grid gap-3 text-left">
        <Field label="Email" value={email} onChange={setEmail} type="email" />
        <Field label="Password" value={password} onChange={setPassword} type="password" />
        <Field label="Player name (unique)" value={player} onChange={setPlayer} />
      </div>

      <button
        onClick={() => { sfx.click(); void signIn(); }}
        disabled={busy}
        className="ashley-gradient mt-4 flex w-full items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-60"
      >
        {busy && <Loader2 className="h-4 w-4 animate-spin" />} Sign in / create account
      </button>

      {/* ADMINISTRATOR */}
      {!adminOpen ? (
        <button
          onClick={() => { sfx.click(); setAdminOpen(true); }}
          className="mt-3 w-full rounded-full border border-[#ff2d3f]/60 px-4 py-2.5 text-sm font-black tracking-[0.25em] text-[#ff2d3f]"
          style={{ textShadow: "0 0 10px #ff2d3f, 0 0 24px #ff2d3f", boxShadow: "0 0 18px rgba(255,45,63,.35)" }}
        >
          ADMINISTRATOR
        </button>
      ) : (
        <div className="mt-3 rounded-2xl border border-[#ff2d3f]/50 p-3 text-left" style={{ boxShadow: "0 0 22px rgba(255,45,63,.25)" }}>
          <p className="text-[11px] font-black tracking-[0.25em] text-[#ff2d3f]" style={{ textShadow: "0 0 10px #ff2d3f" }}>
            ADMINISTRATOR ACCESS
          </p>
          <input
            type="password"
            value={adminPass}
            autoFocus
            onChange={(e) => setAdminPass(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void adminLogin()}
            placeholder="Administrator password"
            className="mt-2 w-full rounded-xl border border-[#ff2d3f]/40 bg-background/60 px-3 py-2 text-sm"
          />
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => { sfx.click(); void adminLogin(); }}
              className="flex-1 rounded-full bg-[#ff2d3f] px-4 py-2 text-xs font-bold text-white"
            >
              Unlock
            </button>
            <button onClick={() => { sfx.click(); setAdminOpen(false); }} className="rounded-full border border-border/60 px-4 py-2 text-xs">
              Cancel
            </button>
          </div>
        </div>
      )}

      <button onClick={() => { sfx.click(); onSignup(); }} className="mt-3 w-full rounded-full border border-border/60 px-4 py-2.5 text-sm hover:border-primary/50">
        Full sign-up (name, age tier & face check)
      </button>

      {err && <p className="mt-3 text-xs text-destructive">{err}</p>}

      {ranks.length > 0 && (
        <div className="mt-5 rounded-2xl border border-border/50 p-3 text-left text-[11px]">
          <p className="mb-1 font-semibold uppercase tracking-widest text-muted-foreground">Top players</p>
          {ranks.map((r) => (
            <p key={r.name} className="flex justify-between">
              <span>
                {r.is_admin && <span className="font-bold text-[#ff2d3f]">[ADMIN OWNER] </span>}
                {r.name}
                {r.is_admin && " ✓"}
              </span>
              <span className="text-primary">{r.kills}</span>
            </p>
          ))}
        </div>
      )}
    </section>
  );
}

function SignupSlide({ save, persist, onNext }: { save: BloxSave; persist: (s: BloxSave) => void; onNext: () => void }) {
  const [f, setF] = useState({ first: "", middle: "", last: "", birthday: "", email: "" });
  const age = ageFromBirthday(f.birthday);
  const tier = tierForAge(age);
  const ok = f.first.trim() && f.last.trim() && age > 0;

  return (
    <section className="glass mx-auto max-w-md rounded-3xl p-6">
      <h2 className="text-lg font-bold">Create your AshleyBlox account</h2>
      <div className="mt-4 grid gap-3">
        <Field label="First name" value={f.first} onChange={(v) => setF({ ...f, first: v })} />
        <Field label="Middle name (optional)" value={f.middle} onChange={(v) => setF({ ...f, middle: v })} />
        <Field label="Last name" value={f.last} onChange={(v) => setF({ ...f, last: v })} />
        <Field label="Email" value={f.email} onChange={(v) => setF({ ...f, email: v })} type="email" />
        <label className="text-xs text-muted-foreground">
          Birthday
          <input
            type="date"
            value={f.birthday}
            onChange={(e) => setF({ ...f, birthday: e.target.value })}
            className="mt-1 w-full rounded-xl border border-border/60 bg-background/60 px-3 py-2 text-sm text-foreground"
          />
        </label>
        {age > 0 && (
          <div className="flex items-center gap-2 rounded-2xl border border-primary/30 bg-primary/10 p-3">
            <img src={logo.url} alt="" className="h-9 w-9 rounded-xl" />
            <div className="text-xs">
              <p className="font-semibold">
                AshleyBlox {tier === "OPEN" ? "" : tier}
              </p>
              <p className="text-muted-foreground">
                Age {age} · {tier === "KIDS" ? "child-safe games only" : tier === "SELECTED" ? "selected games for teens" : "full catalogue"}
              </p>
            </div>
          </div>
        )}
      </div>
      <button
        disabled={!ok}
        onClick={() => {
          sfx.success();
          persist({
            ...save,
            account: {
              first: f.first.trim(),
              middle: f.middle.trim() || undefined,
              last: f.last.trim(),
              birthday: f.birthday,
              age,
              tier,
              email: f.email.trim(),
              faceVerified: false,
              createdAt: new Date().toISOString(),
            },
          });
          onNext();
        }}
        className="ashley-gradient mt-5 w-full rounded-full px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
      >
        Continue to face check
      </button>
    </section>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="text-xs text-muted-foreground">
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-border/60 bg-background/60 px-3 py-2 text-sm text-foreground"
      />
    </label>
  );
}

function FaceSlide({ save, persist, onNext }: { save: BloxSave; persist: (s: BloxSave) => void; onNext: () => void }) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [on, setOn] = useState(false);
  const [scan, setScan] = useState(0);
  const [birthday, setBirthday] = useState(save.account?.birthday ?? "");
  const [err, setErr] = useState<string | null>(null);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setOn(true);
      let p = 0;
      const id = window.setInterval(() => {
        p += 4;
        setScan(p);
        if (p >= 100) {
          clearInterval(id);
          stream.getTracks().forEach((t) => t.stop());
        }
      }, 80);
    } catch {
      setErr("Camera unavailable — you can still confirm your birthday below.");
    }
  };

  const age = ageFromBirthday(birthday);

  return (
    <section className="glass mx-auto max-w-md rounded-3xl p-6 text-center">
      <h2 className="text-lg font-bold">Face check & age confirm</h2>
      <p className="mt-1 text-xs text-muted-foreground">Used once, on this device only. Nothing is uploaded.</p>

      <div className="relative mx-auto mt-4 aspect-square w-56 overflow-hidden rounded-3xl border border-primary/40 bg-black/40">
        <video ref={videoRef} muted playsInline className="h-full w-full object-cover" />
        {!on && <div className="absolute inset-0 grid place-items-center text-xs text-muted-foreground">camera off</div>}
        {on && scan < 100 && (
          <div className="absolute inset-x-0 h-0.5 bg-primary shadow-[0_0_16px_hsl(var(--primary))]" style={{ top: `${scan}%` }} />
        )}
      </div>

      {!on && (
        <button onClick={() => { sfx.click(); void start(); }} className="glass mt-4 rounded-full px-4 py-2 text-sm">
          Start face check
        </button>
      )}
      {err && <p className="mt-3 text-xs text-muted-foreground">{err}</p>}
      {scan >= 100 && <p className="mt-3 text-xs text-primary">Face captured ✓</p>}

      <div className="mt-4 text-left">
        <Field label="Fix your birthday if it's wrong" value={birthday} onChange={setBirthday} type="date" />
        {age > 0 && (
          <p className="mt-2 text-xs text-muted-foreground">
            Age {age} → AshleyBlox {tierForAge(age) === "OPEN" ? "(full)" : tierForAge(age)}
          </p>
        )}
      </div>

      <button
        disabled={!save.account || age <= 0}
        onClick={() => {
          if (!save.account) return;
          sfx.success();
          persist({
            ...save,
            account: { ...save.account, birthday, age, tier: tierForAge(age), faceVerified: scan >= 100 },
          });
          onNext();
        }}
        className="ashley-gradient mt-5 w-full rounded-full px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
      >
        Continue to character maker
      </button>
    </section>
  );
}

const SKINS = ["#f2c9a0", "#e0a878", "#a56a43", "#6c4326", "#ffd9e6"];
const SHIRTS = ["#ff4fa3", "#49d8ff", "#a97bff", "#5eff9a", "#ffd166"];
const PANTS = ["#2b2350", "#111827", "#7c2d5a", "#1f5f6b", "#4b3b12"];
const HAIRS = ["#1b1430", "#5b2a10", "#ffd166", "#ff4fa3", "#49d8ff"];

function AvatarSlide({ save, persist, onNext }: { save: BloxSave; persist: (s: BloxSave) => void; onNext: () => void }) {
  const [a, setA] = useState<BloxAvatar>(save.avatar ?? DEFAULT_AVATAR);
  return (
    <section className="glass mx-auto max-w-3xl rounded-3xl p-6">
      <h2 className="text-lg font-bold">Character maker</h2>
      <div className="mt-4 grid gap-6 sm:grid-cols-[220px_1fr]">
        <div className="rounded-3xl bg-gradient-to-b from-primary/15 to-transparent p-4">
          <AvatarDoll a={a} className="mx-auto h-64" />
          <p className="mt-2 text-center text-sm font-semibold">{a.charName || "Unnamed"}</p>
        </div>
        <div className="grid gap-3">
          <Field label="Character name" value={a.charName} onChange={(v) => setA({ ...a, charName: v.slice(0, 20) })} />
          <Swatches label="Skin" colors={SKINS} value={a.skin} onPick={(c) => setA({ ...a, skin: c })} />
          <Swatches label="Shirt" colors={SHIRTS} value={a.shirt} onPick={(c) => setA({ ...a, shirt: c })} />
          <Swatches label="Pants" colors={PANTS} value={a.pants} onPick={(c) => setA({ ...a, pants: c })} />
          <Swatches label="Hair" colors={HAIRS} value={a.hair} onPick={(c) => setA({ ...a, hair: c })} />
          <div>
            <p className="text-xs text-muted-foreground">Face</p>
            <div className="mt-1 flex gap-2">
              {(["smile", "cool", "wink", "serious"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => { sfx.hover(); setA({ ...a, face: f }); }}
                  className={"rounded-full px-3 py-1 text-xs " + (a.face === f ? "ashley-gradient text-primary-foreground" : "glass")}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      <button
        disabled={!a.charName.trim()}
        onClick={() => { sfx.success(); persist({ ...save, avatar: a, loggedIn: true }); onNext(); }}
        className="ashley-gradient mt-5 w-full rounded-full px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
      >
        Save character & enter AshleyBlox
      </button>
    </section>
  );
}

function Swatches({ label, colors, value, onPick }: { label: string; colors: string[]; value: string; onPick: (c: string) => void }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <div className="mt-1 flex gap-2">
        {colors.map((c) => (
          <button
            key={c}
            aria-label={`${label} ${c}`}
            onClick={() => { sfx.hover(); onPick(c); }}
            style={{ background: c }}
            className={"h-7 w-7 rounded-full ring-2 " + (value === c ? "ring-primary" : "ring-transparent")}
          />
        ))}
      </div>
    </div>
  );
}

function RobuxBar({ robux, gems, onOpen }: { robux: number; gems: number; onOpen: () => void }) {
  return (
    <button
      onClick={() => { sfx.click(); onOpen(); }}
      className="glass inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold"
    >
      <img src={robuxIcon.url} alt="Robux" width={20} height={20} loading="lazy" className="h-5 w-5" />
      {robux.toLocaleString()} R$
      {gems > 0 && <span className="text-[#49d8ff]">· {gems} 💎</span>}
      <span className="text-muted-foreground">Buy</span>
    </button>
  );
}

function RobuxShop({ onClose }: { onClose: () => void }) {
  const { robux, gems, buy } = useRobux();
  const { credits } = useCredits();
  const [note, setNote] = useState<string | null>(null);
  const android = isAndroid();

  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-background/80 p-5">
      <section className="glass w-full max-w-lg rounded-3xl p-5">
        <div className="flex items-center gap-3">
          <img src={robuxIcon.url} alt="Robux" width={44} height={44} loading="lazy" className="h-11 w-11" />
          <div>
            <h3 className="text-lg font-bold">Robux</h3>
            <p className="text-[11px] text-muted-foreground">
              Bought with AshleyAI points · you have {credits.toLocaleString()} points and {robux.toLocaleString()} R$
            </p>
          </div>
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {ROBUX_PACKS.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                if (!buy(p.robux, p.points)) {
                  sfx.error();
                  setNote(`Not enough AshleyAI points — you need ${p.points.toLocaleString()}.`);
                  return;
                }
                sfx.success();
                setNote(`+${p.robux} R$ added.`);
              }}
              className="glass flex items-center justify-between rounded-2xl px-3 py-3 text-left text-xs"
            >
              <span>
                <span className="font-semibold">{p.label}</span>
                <span className="block text-muted-foreground">{p.points.toLocaleString()} AshleyAI points</span>
              </span>
              <span className="inline-flex items-center gap-1 font-bold text-primary">
                <img src={robuxIcon.url} alt="" width={16} height={16} loading="lazy" className="h-4 w-4" />
                {p.robux}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-5 rounded-2xl border border-[#49d8ff]/40 p-3">
          <p className="text-xs font-semibold text-[#49d8ff]">Gems 💎 · Android only</p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {android
              ? `Gem packs are unlocked on this Android device. You have ${gems} gems.`
              : "Gems are exclusive to the AshleyBlox Android app — open this page on an Android phone to buy them."}
          </p>
          <div className="mt-2 grid gap-2 sm:grid-cols-3">
            {GEM_PACKS.map((g) => (
              <button
                key={g.id}
                disabled={!android}
                onClick={() => {
                  if (!spendRobux(g.robux)) {
                    sfx.error();
                    setNote("Not enough Robux for that gem pack.");
                    return;
                  }
                  sfx.success();
                  setNote(`+${g.gems} gems.`);
                }}
                className="glass rounded-2xl px-3 py-2 text-xs disabled:opacity-40"
              >
                <span className="block font-semibold">{g.gems} 💎</span>
                <span className="text-muted-foreground">{g.robux} R$</span>
              </button>
            ))}
          </div>
        </div>

        {note && <p className="mt-3 text-xs text-primary">{note}</p>}

        <button onClick={() => { sfx.click(); onClose(); }} className="ashley-gradient mt-4 w-full rounded-full px-4 py-2.5 text-sm font-semibold text-primary-foreground">
          Done
        </button>
      </section>
    </div>
  );
}

function HubSlide({
  save,
  persist,
  credits,
  onPlay,
  onLogout,
}: {
  save: BloxSave;
  persist: (s: BloxSave) => void;
  credits: number;
  onPlay: () => void;
  onLogout: () => void;
}) {
  const [menu, setMenu] = useState(false);
  const [shop, setShop] = useState(false);
  const [servers, setServers] = useState<{ id: string; name: string; players: number; max: number; region: string; ping: number }[]>([]);
  const [online, setOnline] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const [mine, setMine] = useState<PrivateServer[]>([]);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);
  const { robux, gems } = useRobux();
  void credits;

  useEffect(() => {
    fetch("/api/blox/servers")
      .then((r) => r.json())
      .then((d) => {
        setOnline(!!d.online);
        setServers(d.servers ?? []);
      })
      .catch(() => setOnline(false));
    void myPrivateServers().then(setMine);
  }, []);

  const makePrivate = async () => {
    setMenu(false);
    if (robux < PRIVATE_SERVER_ROBUX) {
      sfx.error();
      setNote(`A private server costs ${PRIVATE_SERVER_ROBUX} R$ — you have ${robux}. Buy Robux with AshleyAI points.`);
      return;
    }
    setBusy(true);
    const res = await createPrivateServer(`${save.avatar?.charName ?? "Player"}'s Server`, save.avatar?.charName ?? "Player");
    if (!res.ok) {
      setBusy(false);
      sfx.error();
      setNote(res.reason);
      return;
    }
    // charge only after the server really exists
    spendRobux(PRIVATE_SERVER_ROBUX);
    setBusy(false);
    sfx.success();
    setMine((m) => [res.server, ...m]);
    persist({
      ...save,
      privateServers: [
        ...save.privateServers,
        { id: res.server.code, name: res.server.name, createdAt: new Date().toISOString() },
      ],
    });
    setNote(`Private server created — invite code ${res.server.code}. Share it with friends so they can join.`);
  };

  const join = async () => {
    setBusy(true);
    const res = await joinPrivateServer(joinCode);
    setBusy(false);
    if (!res.ok) {
      sfx.error();
      setNote(res.reason);
      return;
    }
    sfx.success();
    serverRef.current = `priv-${res.server.code}`;
    inviteRef.current = res.server.code;
    onPlay();
  };

  const enterPrivate = (code: string) => {
    sfx.click();
    serverRef.current = `priv-${code}`;
    inviteRef.current = code;
    onPlay();
  };

  return (
    <div className="grid gap-5">
      {shop && <RobuxShop onClose={() => setShop(false)} />}

      <section className="glass overflow-hidden rounded-3xl">
        <img src={cover.url} alt="Ro-shooter cover art" className="h-56 w-full object-cover sm:h-72" />
        <div className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-1.5 text-xl font-bold">
                Ro-shooter <CheckBadge />
              </h2>
              <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                [TokemekiAi <CheckBadge className="inline h-3 w-3" />]
              </p>
              <p className="mt-2 flex items-center gap-3 text-[11px] text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Wifi className={"h-3.5 w-3.5 " + (online ? "text-primary" : "text-destructive")} />
                  {online ? "Servers online" : "Offline"}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Users className="h-3.5 w-3.5" />
                  {servers.reduce((n, s) => n + s.players, 0)} playing
                </span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <RobuxBar robux={robux} gems={gems} onOpen={() => setShop(true)} />
              <div className="relative">
                <button
                  onClick={() => { sfx.click(); setMenu((m) => !m); }}
                  aria-label="Game options"
                  className="glass flex h-9 w-9 items-center justify-center rounded-full"
                >
                  <MoreVertical className="h-4 w-4" />
                </button>
                {menu && (
                  <div className="glass absolute right-0 z-10 mt-2 w-60 rounded-2xl p-2 text-sm">
                    <button onClick={() => void makePrivate()} className="w-full rounded-xl px-3 py-2 text-left hover:bg-primary/10">
                      Create private server
                      <span className="block text-[11px] text-muted-foreground">{PRIVATE_SERVER_ROBUX} R$ · invite-only</span>
                    </button>
                    <button onClick={() => { sfx.click(); setMenu(false); setShop(true); }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-primary/10">
                      Buy Robux
                    </button>
                    <button onClick={() => { sfx.click(); onLogout(); }} className="w-full rounded-xl px-3 py-2 text-left hover:bg-primary/10">
                      Log out of AshleyBlox
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {note && <p className="mt-3 text-xs text-primary">{note}</p>}

          <button
            onClick={() => { sfx.success(); serverRef.current = "pub-1"; inviteRef.current = ""; onPlay(); }}
            className="ashley-gradient mt-4 w-full rounded-full px-5 py-3 text-sm font-bold text-primary-foreground"
          >
            ▶ Play
          </button>
        </div>
      </section>

      <section className="glass rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold">Private servers</h3>
          <span className="text-[11px] text-muted-foreground">Only players with the invite code can join</span>
        </div>

        <div className="mt-3 grid gap-2">
          {mine.map((s) => (
            <div key={s.code} className="glass flex items-center justify-between gap-2 rounded-2xl px-3 py-2 text-xs">
              <span>
                <span className="font-semibold">{s.name}</span>
                <span className="block text-muted-foreground">Invite code · <span className="font-mono tracking-[0.3em] text-primary">{s.code}</span></span>
              </span>
              <span className="flex items-center gap-2">
                <button
                  aria-label="Copy invite code"
                  onClick={() => { sfx.click(); void navigator.clipboard?.writeText(s.code); setNote(`Invite code ${s.code} copied.`); }}
                  className="glass rounded-full p-2"
                >
                  <Copy className="h-3.5 w-3.5" />
                </button>
                <button onClick={() => enterPrivate(s.code)} className="ashley-gradient rounded-full px-3 py-1.5 font-semibold text-primary-foreground">
                  Enter
                </button>
              </span>
            </div>
          ))}
          {mine.length === 0 && (
            <p className="text-[11px] text-muted-foreground">
              You don't own a private server yet — create one for {PRIVATE_SERVER_ROBUX} R$ from the ⋮ menu.
            </p>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-end gap-2">
          <label className="text-xs text-muted-foreground">
            Join with an invite code
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase().slice(0, 6))}
              placeholder="ABC123"
              className="mt-1 w-40 rounded-xl border border-border/60 bg-background/60 px-3 py-2 font-mono text-sm tracking-[0.3em] text-foreground"
            />
          </label>
          <button
            disabled={busy || joinCode.length !== 6}
            onClick={() => { sfx.click(); void join(); }}
            className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold disabled:opacity-50"
          >
            {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Join private server
          </button>
        </div>
      </section>

      <section className="glass rounded-3xl p-5">
        <h3 className="text-sm font-semibold">Public servers</h3>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {servers.map((s) => (
            <button
              key={s.id}
              onClick={() => { sfx.click(); serverRef.current = s.id; inviteRef.current = ""; onPlay(); }}
              className="glass flex items-center justify-between rounded-2xl px-3 py-2 text-left text-xs"
            >
              <span>
                <span className="font-semibold">{s.name}</span>
                <span className="block text-muted-foreground">{s.region} · {s.ping}ms</span>
              </span>
              <span className="text-primary">{s.players}/{s.max}</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}


function ConnectSlide({ onReady }: { onReady: () => void }) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    let p = 0;
    const id = window.setInterval(() => {
      p += 4;
      setPct(Math.min(100, p));
      if (p >= 100) {
        clearInterval(id);
        window.setTimeout(onReady, 0);
      }
    }, 90);
    return () => clearInterval(id);
  }, [onReady]);

  return (
    <section className="glass overflow-hidden rounded-3xl">
      <div className="relative h-64 overflow-hidden sm:h-80">
        <img src={cover.url} alt="Ro-shooter" className="blox-pan absolute inset-0 h-full w-[130%] max-w-none object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent" />
      </div>
      <div className="p-5 text-center">
        <p className="text-sm font-semibold">Creating your Ro-shooter server…</p>
        <div className="mx-auto mt-3 h-2 w-full max-w-sm overflow-hidden rounded-full bg-muted/40">
          <div className="ashley-gradient h-full transition-[width] duration-150" style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">{pct}% · reserving slots for 8 players</p>
      </div>
    </section>
  );
}

function LobbySlide({
  save,
  persist,
  onStart,
  onBack,
}: {
  save: BloxSave;
  persist: (s: BloxSave) => void;
  onStart: (mapId: string, weaponId: string) => void;
  onBack: () => void;
}) {
  const choices = useMemo(() => [...MAPS].sort(() => Math.random() - 0.5).slice(0, 3), []);
  const [votes, setVotes] = useState<Record<string, number>>(() =>
    Object.fromEntries(choices.map((c) => [c.id, Math.floor(Math.random() * 3)])),
  );
  const [myVote, setMyVote] = useState<string | null>(null);
  const [left, setLeft] = useState(60);
  const [equipped, setEquipped] = useState<string>(save.ownedWeapons[save.ownedWeapons.length - 1] ?? "fists");
  const { credits } = useCredits();

  const winner = useMemo(
    () => Object.entries(votes).sort((a, b) => b[1] - a[1])[0][0],
    [votes],
  );
  const winnerRef = useRef(winner);
  winnerRef.current = winner;
  const equippedLocal = useRef(equipped);
  equippedLocal.current = equipped;

  useEffect(() => {
    let t = 60;
    const id = window.setInterval(() => {
      t -= 1;
      setLeft(Math.max(0, t));
      if (t <= 0) {
        clearInterval(id);
        onStart(winnerRef.current, equippedLocal.current);
        return;
      }
      if (Math.random() < 0.35) {
        setVotes((v) => {
          const keys = Object.keys(v);
          const k = keys[Math.floor(Math.random() * keys.length)];
          return { ...v, [k]: v[k] + 1 };
        });
      }
    }, 1000);
    return () => clearInterval(id);
  }, [onStart]);

  const buy = (id: string, price: number) => {
    if (save.ownedWeapons.includes(id)) {
      sfx.click();
      setEquipped(id);
      return;
    }
    if (!spendRobux(price)) {
      sfx.error();
      return;
    }

    sfx.success();
    persist({ ...save, ownedWeapons: [...save.ownedWeapons, id] });
    setEquipped(id);
  };

  return (
    <div className="grid gap-5">
      <section className="glass rounded-3xl p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">Waiting room</h2>
          <span className="ashley-badge rounded-full px-3 py-1 text-xs font-semibold">
            {String(Math.floor(left / 60)).padStart(2, "0")}:{String(left % 60).padStart(2, "0")}
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Vote a map — the top pick loads for everyone. Free-for-all, no teams.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {choices.map((m) => (
            <button
              key={m.id}
              onClick={() => {
                sfx.click();
                setVotes((v) => {
                  const next = { ...v };
                  if (myVote) next[myVote] = Math.max(0, next[myVote] - 1);
                  next[m.id] += 1;
                  return next;
                });
                setMyVote(m.id);
              }}
              className={
                "overflow-hidden rounded-2xl border text-left transition-transform hover:-translate-y-0.5 " +
                (myVote === m.id ? "border-primary" : "border-border/50")
              }
            >
              <div className="h-20" style={{ background: `linear-gradient(135deg, ${m.a}, ${m.b})` }} />
              <div className="p-3">
                <p className="text-sm font-semibold">{m.name}</p>
                <p className="text-[11px] text-muted-foreground">{m.desc}</p>
                <p className="mt-1 text-[11px] text-primary">{votes[m.id]} votes{winner === m.id ? " · leading" : ""}</p>
              </div>
            </button>
          ))}
        </div>
        <div className="mt-4 flex gap-2">
          <button onClick={() => { sfx.click(); onStart(winner, equipped); }} className="ashley-gradient rounded-full px-5 py-2 text-sm font-semibold text-primary-foreground">
            Start now
          </button>
          <button onClick={() => { sfx.click(); onBack(); }} className="glass rounded-full px-5 py-2 text-sm">
            Leave
          </button>
        </div>
      </section>

      <section className="glass rounded-3xl p-5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Lobby shop</h3>
          <span className="text-xs text-muted-foreground">{credits.toLocaleString()} points</span>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {WEAPONS.map((w) => {
            const owned = save.ownedWeapons.includes(w.id);
            return (
              <button
                key={w.id}
                onClick={() => buy(w.id, w.price)}
                className={
                  "glass rounded-2xl p-3 text-left text-xs " + (equipped === w.id ? "ring-1 ring-primary" : "")
                }
              >
                <p className="font-semibold">{w.name}</p>
                <p className="text-muted-foreground">{w.kind} · {w.dmg} dmg</p>
                <p className="mt-1 text-primary">{owned ? (equipped === w.id ? "Equipped" : "Equip") : `${w.price} pts`}</p>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
