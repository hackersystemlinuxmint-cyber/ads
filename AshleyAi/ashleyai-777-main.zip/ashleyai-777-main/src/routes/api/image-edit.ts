import { createFileRoute } from "@tanstack/react-router";
import { gatewayFetch } from "@/lib/ai-gateway.server";

export const Route = createFileRoute("/api/image-edit")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { prompt, image } = (await request.json()) as {
            prompt: string;
            image: string; // data URL or https URL
          };
          if (!prompt || !image) return new Response("prompt+image required", { status: 400 });
          const res = await gatewayFetch("/images/generations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "google/gemini-3.1-flash-image",
              messages: [
                {
                  role: "user",
                  content: [
                    { type: "text", text: prompt },
                    { type: "image_url", image_url: { url: image } },
                  ],
                },
              ],
              modalities: ["image", "text"],
            }),
          });
          if (!res.ok) return new Response(await res.text(), { status: res.status });
          const data = (await res.json()) as { data?: { b64_json?: string }[] };
          const b64 = data.data?.[0]?.b64_json;
          if (!b64) return new Response("no image returned", { status: 500 });
          return Response.json({ image: `data:image/png;base64,${b64}` });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
