import { createFileRoute } from "@tanstack/react-router";
import { gatewayFetch } from "@/lib/ai-gateway.server";

type Lang = "en" | "tl" | "ja";

// Every preset is female — no male voices.
const PRESETS: Record<Lang, { voice: string; speed: number; instructions: string }> = {
  en: {
    voice: "nova",
    speed: 1.02,
    instructions:
      "Speak as Ashley: a young woman with a fluent, natural English accent. Clear, warm, " +
      "confident and friendly, smooth pacing, expressive but never robotic. Female voice only.",
  },
  tl: {
    voice: "coral",
    speed: 1,
    instructions:
      "Magsalita bilang si Ashley: a real Filipina woman speaking Tagalog / Taglish naturally. " +
      "Authentic Philippine pronunciation and intonation, warm, friendly and conversational, " +
      "soft Manila accent, natural code-switching between Tagalog and English. Female voice only.",
  },
  ja: {
    voice: "shimmer",
    speed: 1.1,
    instructions:
      "Speak as Ashley: a cute Japanese teenage anime girl (kawaii seiyuu style). Bright, " +
      "high-pitched, youthful and breathy, with a Japanese accent applied to every language — " +
      "she can read English and Tagalog but always with Japanese pronunciation and rhythm. " +
      "Playful, energetic, cheerful rising intonation, gentle giggly softness. Female voice only.",
  },
};

const EMOTION: Record<string, string> = {
  happy: " Sound happy and smiling.",
  excited: " Sound very excited and energetic.",
  sad: " Sound gentle, soft and a little sad.",
  angry: " Sound firm and a little annoyed, but still cute.",
  shy: " Sound shy and bashful, slightly quieter.",
  surprised: " Sound surprised and curious.",
  neutral: "",
};

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const {
            text,
            lang = "en",
            voice,
            emotion = "neutral",
            instructions,
          } = (await request.json()) as {
            text: string;
            lang?: Lang;
            voice?: string;
            emotion?: string;
            instructions?: string;
          };
          if (!text) return new Response("text required", { status: 400 });
          const preset = PRESETS[lang] ?? PRESETS.en;
          const res = await gatewayFetch("/audio/speech", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "openai/gpt-4o-mini-tts",
              input: text,
              voice: voice ?? preset.voice,
              response_format: "mp3",
              speed: preset.speed,
              instructions:
                instructions ?? preset.instructions + (EMOTION[emotion] ?? ""),
            }),
          });
          if (!res.ok) return new Response(await res.text(), { status: res.status });
          return new Response(res.body, {
            headers: { "Content-Type": "audio/mpeg" },
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
