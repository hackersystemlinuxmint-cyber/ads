import { createFileRoute } from "@tanstack/react-router";

// Openverse — free, no key. Millions of CC-licensed images.
export const Route = createFileRoute("/api/image-search")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const q = url.searchParams.get("q");
        if (!q) return new Response("q required", { status: 400 });
        try {
          const r = await fetch(
            `https://api.openverse.org/v1/images/?q=${encodeURIComponent(q)}&page_size=24`,
            { headers: { "User-Agent": "AshleyAI/1.0" } },
          );
          if (!r.ok) return new Response(await r.text(), { status: r.status });
          const j = (await r.json()) as {
            results: Array<{
              id: string;
              title?: string;
              url: string;
              thumbnail: string;
              foreign_landing_url?: string;
              creator?: string;
            }>;
          };
          return Response.json({
            results: j.results.map((r) => ({
              id: r.id,
              title: r.title ?? "",
              url: r.url,
              thumb: r.thumbnail,
              link: r.foreign_landing_url,
              creator: r.creator ?? "",
            })),
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
