import { createFileRoute } from "@tanstack/react-router";

// Inbound replies from tokemekiai.company@gmail.com are posted here (email
// forwarding / Resend inbound webhook) and appear in the user's mail thread.
export const Route = createFileRoute("/api/public/mail-inbound")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env["MAIL_INBOUND_SECRET"];
        if (secret && request.headers.get("x-mail-secret") !== secret) {
          return new Response("Unauthorized", { status: 401 });
        }

        let p: Record<string, unknown>;
        try {
          p = (await request.json()) as Record<string, unknown>;
        } catch {
          return new Response("Bad request", { status: 400 });
        }

        const str = (v: unknown) => (typeof v === "string" ? v : "");
        const subject = str(p["subject"]);
        const text = str(p["text"] ?? p["body"]).slice(0, 4000);
        const from = str(p["from"]).toLowerCase();
        // thread key: the user address carried in the subject line
        const match = /([^\s<@]+@[^\s>]+\.[^\s>]+)/.exec(subject) ?? /([^\s<@]+@[^\s>]+\.[^\s>]+)/.exec(str(p["to"]));
        const thread = (str(p["thread_email"]) || match?.[1] || "").toLowerCase().trim();
        if (!thread || !text) return new Response("Missing thread or body", { status: 400 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin.from("mail_messages").insert({
          thread_email: thread,
          direction: "in",
          from_email: from || "tokemekiai.company@gmail.com",
          to_email: thread,
          subject,
          body: text,
        });
        return new Response("ok");
      },
    },
  },
});
