import { createFileRoute } from "@tanstack/react-router";
import { hashPassword, verifyPassword, hashCode, verifyCode } from "@/lib/auth.server";

const ADMIN_EMAILS = ["tokemekiai.company@gmail.com", "tokemekiai@gmail.com"];
const isAdmin = (e?: string) => !!e && ADMIN_EMAILS.includes(e.trim().toLowerCase());
const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

function makeResetCode(): string {
  const bytes = new Uint8Array(4);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => (b % 10).toString()).join("") + Math.floor(Math.random() * 10);
}

// Central account server for AshleyAI.
// Passwords are stored only as bcrypt hashes and are never readable — not even
// by the admin. Recovery works through one-time reset codes instead.
export const Route = createFileRoute("/api/accounts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let p: {
          action?: string;
          email?: string;
          password?: string;
          adminEmail?: string;
          target?: string;
          code?: string;
        };
        try {
          p = (await request.json()) as typeof p;
        } catch {
          return Response.json({ error: "Bad request" }, { status: 400 });
        }

        const email = (p.email ?? "").trim().toLowerCase();
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // ---- signup ----
        if (p.action === "signup") {
          if (!isEmail(email)) return Response.json({ error: "Invalid email." }, { status: 400 });
          if (!p.password || p.password.length < 4)
            return Response.json({ error: "Password must be at least 4 characters." }, { status: 400 });
          const { data: existing } = await supabaseAdmin
            .from("ashley_accounts")
            .select("id")
            .eq("email", email)
            .maybeSingle();
          if (existing) return Response.json({ error: "That email already has an account." }, { status: 409 });
          const password_hash = await hashPassword(p.password);
          const { error } = await supabaseAdmin.from("ashley_accounts").insert({ email, password_hash });
          if (error) return Response.json({ error: "Could not create the account." }, { status: 500 });
          return Response.json({ ok: true });
        }

        // ---- login ----
        if (p.action === "login") {
          if (!isEmail(email) || !p.password)
            return Response.json({ error: "Enter your email and password." }, { status: 400 });
          const { data } = await supabaseAdmin
            .from("ashley_accounts")
            .select("id, password_hash")
            .eq("email", email)
            .maybeSingle();
          if (!data || !(await verifyPassword(p.password, data.password_hash)))
            return Response.json({ error: "Wrong email or password." }, { status: 401 });
          return Response.json({ ok: true });
        }

        // ---- redeem a reset code (no admin needed) ----
        if (p.action === "redeem") {
          const code = (p.code ?? "").replace(/\D/g, "");
          if (!isEmail(email) || !code || !p.password || p.password.length < 4)
            return Response.json({ error: "Enter the email, the reset code and a new password." }, { status: 400 });
          const { data } = await supabaseAdmin
            .from("ashley_accounts")
            .select("id, reset_code_hash, reset_expires_at")
            .eq("email", email)
            .maybeSingle();
          if (!data?.reset_code_hash || !data.reset_expires_at || new Date(data.reset_expires_at) < new Date())
            return Response.json({ error: "That reset code is no longer valid." }, { status: 400 });
          if (!(await verifyCode(code, data.reset_code_hash)))
            return Response.json({ error: "That reset code is not correct." }, { status: 400 });
          await supabaseAdmin
            .from("ashley_accounts")
            .update({
              password_hash: await hashPassword(p.password),
              reset_code_hash: null,
              reset_expires_at: null,
              updated_at: new Date().toISOString(),
            })
            .eq("id", data.id);
          return Response.json({ ok: true });
        }

        // ---- admin only below ----
        if (!isAdmin(p.adminEmail)) return Response.json({ error: "Admins only." }, { status: 403 });

        if (p.action === "list") {
          const { data } = await supabaseAdmin
            .from("ashley_accounts")
            .select("email, created_at, reset_expires_at")
            .order("created_at", { ascending: true });
          return Response.json({ ok: true, accounts: data ?? [] });
        }

        if (p.action === "reset") {
          const target = (p.target ?? "").trim().toLowerCase();
          if (!isEmail(target)) return Response.json({ error: "Give a valid email." }, { status: 400 });
          const { data } = await supabaseAdmin
            .from("ashley_accounts")
            .select("id")
            .eq("email", target)
            .maybeSingle();
          if (!data) return Response.json({ error: "No account with that email." }, { status: 404 });
          const code = makeResetCode();
          await supabaseAdmin
            .from("ashley_accounts")
            .update({
              reset_code_hash: await hashCode(code),
              reset_expires_at: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq("id", data.id);
          return Response.json({ ok: true, target, code, expiresInMinutes: 60 });
        }

        return Response.json({ error: "Unknown action." }, { status: 400 });
      },
    },
  },
});
