import { createFileRoute } from "@tanstack/react-router";
import { gatewayFetch } from "@/lib/ai-gateway.server";

const PLATFORMS = [
  { key: "tiktok", label: "TikTok", site: "tiktok.com" },
  { key: "youtube", label: "YouTube", site: "youtube.com" },
  { key: "facebook", label: "Facebook", site: "facebook.com" },
  { key: "instagram", label: "Instagram", site: "instagram.com" },
] as const;

type Hit = { title: string; url: string };

async function ddgSearch(query: string): Promise<Hit[]> {
  try {
    const r = await fetch(
      `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
      { headers: { "User-Agent": "Mozilla/5.0 AshleyAI/1.0" } },
    );
    if (!r.ok) return [];
    const html = await r.text();
    const hits: Hit[] = [];
    const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) && hits.length < 10) {
      let url = m[1];
      // DDG wraps links: //duckduckgo.com/l/?uddg=<encoded>
      const wrap = url.match(/uddg=([^&]+)/);
      if (wrap) url = decodeURIComponent(wrap[1]);
      const title = m[2].replace(/<[^>]+>/g, "").trim();
      if (url.startsWith("http")) hits.push({ title, url });
    }
    return hits;
  } catch {
    return [];
  }
}

export const Route = createFileRoute("/api/reverse-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { image } = (await request.json()) as { image: string };
          if (!image) return new Response("image required", { status: 400 });

          // 1) Ask Ashley's vision to extract clues from the image
          const visionRes = await gatewayFetch("/chat/completions", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "google/gemini-3.6-flash",
              messages: [
                {
                  role: "system",
                  content:
                    "Extract source-finding clues from the image. Reply as compact JSON with keys: query (a short web search query, 4-10 words, describing distinctive subject/scene), handles (array of visible @usernames or channel names), text (array of visible on-image text/captions/watermarks), platformHint (one of tiktok|youtube|facebook|instagram|unknown based on UI/watermark cues). No commentary, JSON only.",
                },
                {
                  role: "user",
                  content: [
                    { type: "text", text: "Analyze this image." },
                    { type: "image_url", image_url: { url: image } },
                  ],
                },
              ],
            }),
          });
          if (!visionRes.ok) {
            return new Response(await visionRes.text(), { status: visionRes.status });
          }
          const vj = (await visionRes.json()) as {
            choices?: { message?: { content?: string } }[];
          };
          const raw = vj.choices?.[0]?.message?.content ?? "";
          const jsonMatch = raw.match(/\{[\s\S]*\}/);
          let clues: {
            query?: string;
            handles?: string[];
            text?: string[];
            platformHint?: string;
          } = {};
          try {
            clues = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
          } catch {
            clues = { query: raw.slice(0, 120) };
          }

          const baseTerms = [
            ...(clues.handles ?? []),
            ...(clues.text ?? []).slice(0, 2),
            clues.query ?? "",
          ]
            .filter(Boolean)
            .join(" ")
            .trim();

          if (!baseTerms) {
            return Response.json({ clues, results: [], message: "No link found" });
          }

          // 2) Search each platform in parallel
          const results = await Promise.all(
            PLATFORMS.map(async (p) => {
              const hits = await ddgSearch(`site:${p.site} ${baseTerms}`);
              const filtered = hits.filter((h) => h.url.includes(p.site)).slice(0, 5);
              return { platform: p.key, label: p.label, hits: filtered };
            }),
          );

          const anyHits = results.some((r) => r.hits.length > 0);
          return Response.json({
            clues,
            query: baseTerms,
            results,
            message: anyHits ? null : "No link found",
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
