import { createFileRoute } from "@tanstack/react-router";
import { getApiKey } from "@/lib/ai-gateway.server";

const BASE = "https://ai.gateway.lovable.dev/v1/videos";

function authHeaders() {
  return { Authorization: `Bearer ${getApiKey()}` };
}

export const Route = createFileRoute("/api/video")({
  server: {
    handlers: {
      // Start a generation job (text-to-video, or image-to-video when an image is given)
      POST: async ({ request }) => {
        try {
          const { prompt, image, seconds = "8" } = (await request.json()) as {
            prompt: string;
            image?: string | null;
            seconds?: string;
          };
          if (!prompt?.trim()) return new Response("prompt required", { status: 400 });

          const res = await fetch(BASE, {
            method: "POST",
            headers: { ...authHeaders(), "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "google/veo-3.1-lite",
              prompt,
              seconds,
              size: "1280x720",
              ...(image ? { input_reference: image } : {}),
            }),
          });
          if (!res.ok) {
            const body = await res.text();
            console.error("[video] create failed", res.status, body);
            return new Response(body || "Video generation failed", { status: res.status });
          }
          const job = (await res.json()) as { id: string; status: string };
          return Response.json({ id: job.id, status: job.status });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },

      // Poll a job; when done, return the MP4 inline as a data URL
      GET: async ({ request }) => {
        try {
          const id = new URL(request.url).searchParams.get("id");
          if (!id) return new Response("id required", { status: 400 });

          const res = await fetch(`${BASE}/${id}`, { headers: authHeaders() });
          if (!res.ok) return new Response(await res.text(), { status: res.status });
          const job = (await res.json()) as {
            status: string;
            progress?: number;
            error?: { message?: string };
          };
          if (job.status !== "completed") {
            return Response.json({
              status: job.status,
              progress: job.progress ?? 0,
              error: job.error?.message ?? null,
            });
          }

          const media = await fetch(`${BASE}/${id}/content`, { headers: authHeaders() });
          if (!media.ok) return new Response(await media.text(), { status: media.status });
          const bytes = new Uint8Array(await media.arrayBuffer());
          let bin = "";
          for (let i = 0; i < bytes.length; i += 0x8000) {
            bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
          }
          return Response.json({
            status: "completed",
            video: `data:video/mp4;base64,${btoa(bin)}`,
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
