import { createFileRoute } from "@tanstack/react-router";
import { gatewayFetch } from "@/lib/ai-gateway.server";

export const Route = createFileRoute("/api/stt")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const form = await request.formData();
          const file = form.get("file");
          if (!(file instanceof File)) return new Response("file required", { status: 400 });
          const upstream = new FormData();
          upstream.append("model", "openai/gpt-4o-mini-transcribe");
          const ext =
            ({ "audio/webm": "webm", "audio/mp4": "m4a", "audio/mpeg": "mp3", "audio/wav": "wav" } as Record<string, string>)[
              file.type.split(";")[0]
            ] ?? "webm";
          upstream.append("file", file, `recording.${ext}`);
          const res = await gatewayFetch("/audio/transcriptions", {
            method: "POST",
            body: upstream,
          });
          if (!res.ok) return new Response(await res.text(), { status: res.status });
          const data = (await res.json()) as { text?: string };
          return Response.json({ text: data.text ?? "" });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
