import { createFileRoute } from "@tanstack/react-router";

// Free web search via DuckDuckGo Instant Answer API (no key).
export const Route = createFileRoute("/api/search")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const q = url.searchParams.get("q");
        if (!q) return new Response("q required", { status: 400 });
        try {
          const r = await fetch(
            `https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`,
          );
          const j = (await r.json()) as {
            Heading?: string;
            AbstractText?: string;
            AbstractURL?: string;
            Image?: string;
            RelatedTopics?: Array<{ Text?: string; FirstURL?: string; Icon?: { URL?: string } }>;
          };
          const related = (j.RelatedTopics ?? [])
            .filter((t) => t.Text && t.FirstURL)
            .slice(0, 10)
            .map((t) => ({ title: t.Text!, url: t.FirstURL! }));
          return Response.json({
            heading: j.Heading ?? "",
            abstract: j.AbstractText ?? "",
            url: j.AbstractURL ?? "",
            image: j.Image ? `https://duckduckgo.com${j.Image}` : "",
            related,
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
