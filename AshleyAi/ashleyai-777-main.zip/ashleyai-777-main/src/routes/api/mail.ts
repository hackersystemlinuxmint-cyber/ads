import { createFileRoute } from "@tanstack/react-router";

const RESEND_URL = "https://connector-gateway.lovable.dev/resend/emails";
export const SUPPORT_EMAIL = "tokemekiai.company@gmail.com";

const isEmail = (v: unknown): v is string =>
  typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length < 200;

// naive in-memory throttle (per worker instance)
const lastSend = new Map<string, number>();

export const Route = createFileRoute("/api/mail")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const email = new URL(request.url).searchParams.get("email")?.toLowerCase().trim();
        if (!isEmail(email)) return Response.json({ messages: [] });
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data } = await supabaseAdmin
          .from("mail_messages")
          .select("id, direction, from_email, body, created_at")
          .eq("thread_email", email)
          .order("created_at", { ascending: true })
          .limit(200);
        return Response.json({ messages: data ?? [] });
      },

      POST: async ({ request }) => {
        let payload: { email?: string; body?: string };
        try {
          payload = (await request.json()) as { email?: string; body?: string };
        } catch {
          return Response.json({ error: "Bad request" }, { status: 400 });
        }
        const email = payload.email?.toLowerCase().trim();
        const body = (payload.body ?? "").trim().slice(0, 4000);
        if (!isEmail(email)) return Response.json({ error: "Enter a valid email first." }, { status: 400 });
        if (!body) return Response.json({ error: "Write a message first." }, { status: 400 });

        const now = Date.now();
        const prev = lastSend.get(email) ?? 0;
        if (now - prev < 5000) return Response.json({ error: "Slow down a moment." }, { status: 429 });
        lastSend.set(email, now);

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin.from("mail_messages").insert({
          thread_email: email,
          direction: "out",
          from_email: email,
          to_email: SUPPORT_EMAIL,
          subject: `AshleyAI Mail · ${email}`,
          body,
        });

        const lovableKey = process.env["LOVABLE_API_KEY"];
        const resendKey = process.env["RESEND_API_KEY"];
        if (!lovableKey || !resendKey) {
          return Response.json({ ok: true, delivered: false, note: "Saved — mail delivery is not configured yet." });
        }

        const html = `<div style="font-family:Inter,system-ui,sans-serif;background:#0b0f1a;padding:28px;color:#e6f2ff">
  <div style="max-width:560px;margin:0 auto;background:#0f1a2e;border:1px solid #1f3a5f;border-radius:18px;padding:24px">
    <div style="font-size:18px;font-weight:700;color:#ff5db1">AshleyAI Mail</div>
    <p style="color:#8aa4c7;font-size:12px;margin:6px 0 16px">From ${email}</p>
    <div style="white-space:pre-wrap;font-size:14px;line-height:1.6">${body
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")}</div>
  </div>
</div>`;

        const res = await fetch(RESEND_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${lovableKey}`,
            "X-Connection-Api-Key": resendKey,
          },
          body: JSON.stringify({
            from: "AshleyAI Mail <onboarding@resend.dev>",
            to: [SUPPORT_EMAIL],
            reply_to: email,
            subject: `AshleyAI Mail · ${email}`,
            html,
          }),
        });
        if (!res.ok) {
          return Response.json({ ok: true, delivered: false, note: "Saved, but delivery failed. Try again later." });
        }
        return Response.json({ ok: true, delivered: true });
      },
    },
  },
});
