import { createFileRoute } from "@tanstack/react-router";

// iTunes Search API — no key required. Returns metadata + preview URL.
export const Route = createFileRoute("/api/songs")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const q = url.searchParams.get("q");
        if (!q) return new Response("q required", { status: 400 });
        try {
          const r = await fetch(
            `https://itunes.apple.com/search?media=music&limit=20&term=${encodeURIComponent(q)}`,
          );
          const j = (await r.json()) as {
            results: Array<{
              trackId: number;
              trackName: string;
              artistName: string;
              collectionName: string;
              artworkUrl100: string;
              previewUrl?: string;
              trackViewUrl?: string;
              releaseDate?: string;
            }>;
          };
          return Response.json({
            results: j.results.map((r) => ({
              id: r.trackId,
              title: r.trackName,
              artist: r.artistName,
              album: r.collectionName,
              artwork: r.artworkUrl100?.replace("100x100", "300x300"),
              preview: r.previewUrl,
              link: r.trackViewUrl,
              released: r.releaseDate,
            })),
          });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
