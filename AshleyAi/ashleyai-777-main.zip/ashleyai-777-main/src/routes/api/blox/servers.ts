import { createFileRoute } from "@tanstack/react-router";

type Srv = { id: string; name: string; players: number; max: number; region: string; ping: number };

function seedList(): Srv[] {
  const regions = ["Asia-PH", "Asia-SG", "US-East", "EU-West"];
  return Array.from({ length: 6 }, (_, i) => ({
    id: `pub-${i + 1}`,
    name: `Ro-shooter #${i + 1}`,
    players: 2 + Math.floor(Math.random() * 7),
    max: 8,
    region: regions[i % regions.length],
    ping: 18 + Math.floor(Math.random() * 90),
  }));
}

export const Route = createFileRoute("/api/blox/servers")({
  server: {
    handlers: {
      GET: async () => Response.json({ online: true, game: "Ro-shooter", servers: seedList() }),
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => ({}))) as { name?: string };
        const name = (body.name ?? "Private Server").toString().slice(0, 40);
        return Response.json({
          ok: true,
          server: {
            id: `priv-${Math.random().toString(36).slice(2, 10)}`,
            name,
            players: 1,
            max: 8,
            region: "Private",
            ping: 12,
          },
        });
      },
    },
  },
});
