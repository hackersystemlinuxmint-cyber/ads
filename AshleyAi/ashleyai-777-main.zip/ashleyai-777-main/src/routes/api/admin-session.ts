import { createFileRoute } from "@tanstack/react-router";

export const ADMIN_EMAIL = "tokemekiai.company@gmail.com";

// Single-session guard for the main admin account: the newest claim wins and
// every other device is signed out on its next check.
export const Route = createFileRoute("/api/admin-session")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let p: { email?: string; token?: string; action?: string };
        try {
          p = (await request.json()) as typeof p;
        } catch {
          return Response.json({ error: "Bad request" }, { status: 400 });
        }
        const email = p.email?.toLowerCase().trim();
        const token = (p.token ?? "").slice(0, 100);
        if (email !== ADMIN_EMAIL) return Response.json({ ok: true, admin: false, valid: true });
        if (!token) return Response.json({ error: "Missing token" }, { status: 400 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        if (p.action === "check") {
          const { data } = await supabaseAdmin
            .from("admin_session")
            .select("token")
            .eq("email", email)
            .maybeSingle();
          return Response.json({ ok: true, admin: true, valid: !data || data.token === token });
        }

        await supabaseAdmin
          .from("admin_session")
          .upsert({ email, token, claimed_at: new Date().toISOString() }, { onConflict: "email" });
        return Response.json({ ok: true, admin: true, valid: true });
      },
    },
  },
});
