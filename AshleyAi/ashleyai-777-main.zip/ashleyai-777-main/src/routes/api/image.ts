import { createFileRoute } from "@tanstack/react-router";
import { gatewayFetch } from "@/lib/ai-gateway.server";

export const Route = createFileRoute("/api/image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { prompt, size = "1024x1024" } = (await request.json()) as {
            prompt: string;
            size?: string;
          };
          if (!prompt) return new Response("prompt required", { status: 400 });
          const res = await gatewayFetch("/images/generations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "openai/gpt-image-2",
              prompt,
              size,
              quality: "low",
              n: 1,
            }),
          });
          if (!res.ok) return new Response(await res.text(), { status: res.status });
          const data = (await res.json()) as { data: { b64_json: string }[] };
          const b64 = data.data?.[0]?.b64_json;
          if (!b64) return new Response("no image", { status: 500 });
          return Response.json({ image: `data:image/png;base64,${b64}` });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});
