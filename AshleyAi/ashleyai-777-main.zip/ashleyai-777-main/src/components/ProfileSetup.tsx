import { useEffect, useRef, useState } from "react";
import { Camera, ScanFace, Check, Loader2, User as UserIcon, LogOut } from "lucide-react";
import verified from "@/assets/verified-check.png.asset.json";
import { sfx } from "@/lib/sound";
import {
  ageFromBirthday,
  buildBirthday,
  isVerified,
  profileName,
  saveProfile,
  type AshleyProfile,
} from "@/lib/profile";

export function VerifiedBadge({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <img
      src={verified.url}
      alt="Verified 18+ · face scanned"
      title="Verified · 18+ face scan passed"
      className={"drop-shadow-[0_0_8px_rgba(60,140,255,0.9)] " + className}
    />
  );
}

/** Small circular avatar + name (never the email) shown top-right. */
export function ProfileChip({
  profile,
  admin,
  onLogout,
}: {
  profile: AshleyProfile;
  admin?: boolean;
  onLogout: () => void;
}) {
  return (
    <div className="fixed right-3 top-3 z-40 flex items-center gap-2 rounded-full border border-primary/30 bg-card/70 px-2 py-1.5 text-xs backdrop-blur-xl shadow-[0_0_24px_-6px_var(--ashley)]">
      <span className="ashley-ringlet relative flex h-8 w-8 items-center justify-center overflow-hidden rounded-full">
        {profile.photo ? (
          <img src={profile.photo} alt="" className="h-full w-full object-cover" />
        ) : (
          <UserIcon className="h-4 w-4 text-primary" />
        )}
      </span>
      <span className="max-w-[140px] truncate font-medium">{profileName(profile)}</span>
      {isVerified(profile) && <VerifiedBadge className="h-4 w-4" />}
      {admin && (
        <span className="rounded-full border border-red-500/60 bg-red-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-red-300 shadow-[0_0_12px_rgba(255,60,90,0.6)]">
          [ admin ]
        </span>
      )}
      <button
        onClick={() => {
          sfx.click();
          onLogout();
        }}
        aria-label="Log out"
        className="ml-0.5 text-muted-foreground hover:text-foreground"
      >
        <LogOut className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

export function ProfileSetup({ onDone }: { onDone: (p: AshleyProfile) => void }) {
  const [first, setFirst] = useState("");
  const [middle, setMiddle] = useState("");
  const [last, setLast] = useState("");
  const [mm, setMm] = useState("");
  const [dd, setDd] = useState("");
  const [yy, setYy] = useState("");
  const [photo, setPhoto] = useState<string | undefined>();
  const [scanned, setScanned] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const mmRef = useRef<HTMLInputElement>(null);
  const ddRef = useRef<HTMLInputElement>(null);
  const yyRef = useRef<HTMLInputElement>(null);

  const birthday = mm && dd && yy ? buildBirthday(mm, dd, yy) : "";
  const age = birthday ? ageFromBirthday(birthday) : 0;
  const verifiedNow = scanned && age >= 18;

  const pickPhoto = (f: File | undefined) => {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => setPhoto(String(r.result));
    r.readAsDataURL(f);
  };

  const submit = () => {
    setErr(null);
    if (first.trim().length < 2 || last.trim().length < 2) {
      setErr("Please enter your first and last name.");
      return;
    }
    if (!birthday || age <= 0) {
      setErr("Please enter a valid birthday.");
      return;
    }
    sfx.click();
    const p: AshleyProfile = {
      first: first.trim(),
      middle: middle.trim() || undefined,
      last: last.trim(),
      photo,
      birthday,
      age,
      faceVerified: verifiedNow,
    };
    saveProfile(p);
    onDone(p);
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-10">
      <div className="ashley-aurora" />
      <div className="ashley-aurora-b" />
      <div className="ashley-grid" />
      <div className="glass ashley-scan relative z-10 w-full max-w-md rounded-3xl p-6">
        <div className="hud-corners" />
        <h2 className="font-display text-lg font-bold uppercase tracking-[0.3em] text-primary">
          Create profile
        </h2>
        <p className="mt-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          AshleyAI · v9.4.5.2
        </p>

        <div className="mt-5 flex items-center gap-4">
          <button
            onClick={() => {
              sfx.click();
              fileRef.current?.click();
            }}
            className="ashley-ringlet relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-full"
            aria-label="Choose profile picture"
          >
            {photo ? (
              <img src={photo} alt="" className="h-full w-full object-cover" />
            ) : (
              <Camera className="h-6 w-6 text-primary" />
            )}
          </button>
          <div className="text-xs text-muted-foreground">
            Profile picture
            <div className="text-[10px] opacity-70">Tap the circle to upload</div>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => pickPhoto(e.target.files?.[0])}
          />
        </div>

        <div className="mt-5 grid gap-3">
          <Field label="First name" value={first} onChange={setFirst} />
          <Field label="Middle name (optional)" value={middle} onChange={setMiddle} />
          <Field label="Last name" value={last} onChange={setLast} />
          <div className="block">
            <div className="mb-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              Birthday
            </div>
            <div className="flex items-center gap-2">
              <NumBox
                label="MM"
                value={mm}
                max={2}
                inputRef={mmRef}
                onChange={(v) => {
                  setMm(v);
                  if (v.length === 2) ddRef.current?.focus();
                }}
              />
              <span className="text-muted-foreground">/</span>
              <NumBox
                label="DD"
                value={dd}
                max={2}
                inputRef={ddRef}
                onChange={(v) => {
                  setDd(v);
                  if (v.length === 2) yyRef.current?.focus();
                }}
                onEmptyBack={() => mmRef.current?.focus()}
              />
              <span className="text-muted-foreground">/</span>
              <NumBox
                label="YYYY"
                value={yy}
                max={4}
                inputRef={yyRef}
                onChange={setYy}
                onEmptyBack={() => ddRef.current?.focus()}
              />
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Age: <span className="font-semibold text-foreground">{age || "—"}</span>
            {birthday && age <= 0 && (
              <span className="ml-2 text-destructive">Invalid date</span>
            )}
          </div>
        </div>

        <FaceScanner
          photo={photo}
          scanned={scanned}
          scanning={scanning}
          age={age}
          onScan={() => {
            sfx.click();
            setScanning(true);
            window.setTimeout(() => {
              setScanning(false);
              setScanned(true);
            }, 2600);
          }}
        />

        {err && (
          <div className="mt-3 rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2 text-xs text-destructive-foreground">
            {err}
          </div>
        )}

        <button
          onClick={submit}
          className="ashley-gradient ashley-cta mt-5 w-full rounded-xl py-3 text-sm font-semibold uppercase tracking-[0.25em] text-primary-foreground"
        >
          Enter AshleyAI
        </button>
      </div>
    </div>
  );
}

function FaceScanner({
  photo,
  scanned,
  scanning,
  age,
  onScan,
}: {
  photo?: string;
  scanned: boolean;
  scanning: boolean;
  age: number;
  onScan: () => void;
}) {
  const [dots, setDots] = useState(0);
  useEffect(() => {
    if (!scanning) return;
    const id = window.setInterval(() => setDots((d) => (d + 1) % 4), 300);
    return () => window.clearInterval(id);
  }, [scanning]);

  return (
    <div className="mt-5 rounded-2xl border border-accent/30 bg-black/30 p-4">
      <div className="flex items-center gap-3">
        <div className="face-scan relative h-16 w-16 overflow-hidden rounded-xl bg-black/50">
          {photo ? (
            <img src={photo} alt="" className="h-full w-full object-cover opacity-80" />
          ) : (
            <ScanFace className="absolute inset-0 m-auto h-6 w-6 text-accent" />
          )}
          {scanning && <span className="face-scan-line" />}
        </div>
        <div className="flex-1">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
            Face scanner
          </div>
          <div className="text-[11px] text-muted-foreground">
            {scanning
              ? "Scanning" + ".".repeat(dots)
              : scanned
                ? age >= 18
                  ? "Passed · 18+ verified"
                  : "Scan complete · under 18, no verified badge"
                : "Scan your face to verify you are 18+"}
          </div>
        </div>
        <button
          onClick={onScan}
          disabled={scanning}
          className="glass flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] uppercase tracking-widest text-accent disabled:opacity-50"
        >
          {scanning ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : scanned ? (
            <Check className="h-3.5 w-3.5" />
          ) : (
            <ScanFace className="h-3.5 w-3.5" />
          )}
          {scanned && !scanning ? "Rescan" : "Scan"}
        </button>
      </div>
      {scanned && age >= 18 && (
        <div className="mt-3 flex items-center gap-2 rounded-lg border border-[#1877ff]/40 bg-[#1877ff]/10 px-3 py-2 text-[11px]">
          <VerifiedBadge className="h-4 w-4" />
          <span>Verified · your name will show the check mark.</span>
        </div>
      )}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <div className="mb-1 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
        {label}
      </div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="ashley-input w-full rounded-xl px-3 py-2.5 text-sm"
      />
    </label>
  );
}

function NumBox({
  label,
  value,
  max,
  inputRef,
  onChange,
  onEmptyBack,
}: {
  label: string;
  value: string;
  max: number;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onChange: (v: string) => void;
  onEmptyBack?: () => void;
}) {
  return (
    <label className="flex-1">
      <input
        ref={inputRef}
        value={value}
        inputMode="numeric"
        placeholder={label}
        maxLength={max}
        aria-label={label}
        onKeyDown={(e) => {
          if (e.key === "Backspace" && !value) onEmptyBack?.();
        }}
        onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, max))}
        className="ashley-input w-full rounded-xl px-3 py-2.5 text-center text-sm tracking-[0.2em]"
      />
    </label>
  );
}
