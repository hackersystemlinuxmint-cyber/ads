import { useEffect, useState } from "react";
import { MAPS } from "@/lib/ashleyblox";

const STAGES = [
  "Allocating arena memory…",
  "Generating terrain blocks…",
  "Baking collision meshes…",
  "Placing cover & towers…",
  "Compiling shaders (1080p)…",
  "Warming physics solver…",
  "Syncing players online…",
  "Ready.",
];

/** ~10 second 3D map generation screen. */
export function MapGenLoader({ mapId, onDone }: { mapId: string; onDone: () => void }) {
  const map = MAPS.find((m) => m.id === mapId) ?? MAPS[0];
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const started = performance.now();
    let raf = 0;
    const step = () => {
      const p = Math.min(100, ((performance.now() - started) / 10000) * 100);
      setPct(p);
      if (p >= 100) {
        onDone();
        return;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  const stage = STAGES[Math.min(STAGES.length - 1, Math.floor((pct / 100) * STAGES.length))];

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-5 bg-background px-8">
      <div
        className="relative h-40 w-40 animate-spin rounded-2xl"
        style={{ background: `linear-gradient(135deg, ${map.a}, ${map.b})`, animationDuration: "6s" }}
      >
        <div className="absolute inset-3 rounded-xl border border-white/25" />
        <div className="absolute inset-8 rounded-lg border border-white/20" />
      </div>
      <div className="text-center">
        <p className="text-lg font-bold">Generating {map.name}</p>
        <p className="mt-1 text-xs text-muted-foreground">{stage}</p>
      </div>
      <div className="h-2 w-full max-w-sm overflow-hidden rounded-full bg-muted/40">
        <div className="ashley-gradient h-full" style={{ width: `${pct}%` }} />
      </div>
      <p className="text-[11px] text-muted-foreground">{Math.round(pct)}% · 3D physics build · up to 1920×1080</p>
    </div>
  );
}
