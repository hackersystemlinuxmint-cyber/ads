import { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import logo from "@/assets/ashleyblox-logo.png.asset.json";
import { WEAPONS, MAPS, FIGHT_STYLES, SKILLS, type BloxAvatar } from "@/lib/ashleyblox";
import { sfx } from "@/lib/sound";
import { gsfx, setGameVolume, setHaptics, buzz } from "@/lib/blox-sfx";
import { loadSettings, saveSettings, DEFAULT_SETTINGS, type BloxSettings } from "@/lib/blox-settings";
import { BloxNet, type ChatMsg, type NetPlayerState } from "@/lib/blox-net";
import { fetchMyRank, reportKills, type BloxIdentity } from "@/lib/blox-auth";

type Box = { min: THREE.Vector3; max: THREE.Vector3 };
type Limbs = { armL: THREE.Mesh; armR: THREE.Mesh; legL: THREE.Mesh; legR: THREE.Mesh };

type Actor = {
  id: string;
  name: string;
  admin: boolean;
  bot: boolean;
  hp: number;
  kills: number;
  pos: THREE.Vector3;
  target: THREE.Vector3;
  ry: number;
  cd: number;
  group: THREE.Group;
  limbs: Limbs;
  phase: number;
  last: number;
  flash: number;
};

const GRAVITY = 22;
const JUMP = 8.2;
const WALK = 6.4;
const RUN = 10.6;
const DASH = 28;
const EYE = 1.6;
const CROUCH_EYE = 1.02;
const ARENA = 60;

type SkillId = "dash" | "heal" | "shock" | "rage" | "shield" | "smoke";
type SkillState = Record<SkillId, number>;
const EMPTY_CD: SkillState = { dash: 0, heal: 0, shock: 0, rage: 0, shield: 0, smoke: 0 };

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

function nameSprite(name: string, admin: boolean) {
  const c = document.createElement("canvas");
  c.width = 1024;
  c.height = 128;
  const g = c.getContext("2d")!;
  g.font = "bold 56px system-ui, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  if (admin) {
    const tag = "[ADMIN OWNER] ";
    const rest = `${name} ✓`;
    const wTag = g.measureText(tag).width;
    const wRest = g.measureText(rest).width;
    const start = 512 - (wTag + wRest) / 2;
    g.fillStyle = "#ff2d3f";
    g.shadowColor = "#ff2d3f";
    g.shadowBlur = 18;
    g.textAlign = "left";
    g.fillText(tag, start, 64);
    g.shadowBlur = 0;
    g.fillStyle = "#ffffff";
    g.fillText(rest, start + wTag, 64);
  } else {
    g.fillStyle = "#ffffff";
    g.shadowColor = "#000";
    g.shadowBlur = 8;
    g.fillText(name, 512, 64);
  }
  const tex = new THREE.CanvasTexture(c);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
  spr.scale.set(6, 0.75, 1);
  spr.position.y = 2.6;
  return spr;
}

function makeBody(shirt: string, skin: string, pants: string): { group: THREE.Group; limbs: Limbs } {
  const g = new THREE.Group();
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.0, 0.5), new THREE.MeshLambertMaterial({ color: shirt }));
  torso.position.y = 1.15;
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.62, 0.62), new THREE.MeshLambertMaterial({ color: skin }));
  head.position.y = 2.0;

  const legGeo = new THREE.BoxGeometry(0.36, 1.0, 0.4);
  legGeo.translate(0, -0.5, 0);
  const legL = new THREE.Mesh(legGeo, new THREE.MeshLambertMaterial({ color: pants }));
  legL.position.set(-0.24, 1.0, 0);
  const legR = new THREE.Mesh(legGeo, new THREE.MeshLambertMaterial({ color: pants }));
  legR.position.set(0.24, 1.0, 0);

  const armGeo = new THREE.BoxGeometry(0.28, 0.95, 0.34);
  armGeo.translate(0, -0.475, 0);
  const armL = new THREE.Mesh(armGeo, new THREE.MeshLambertMaterial({ color: shirt }));
  armL.position.set(-0.62, 1.6, 0);
  const armR = new THREE.Mesh(armGeo, new THREE.MeshLambertMaterial({ color: shirt }));
  armR.position.set(0.62, 1.6, 0);

  [torso, head, legL, legR, armL, armR].forEach((m) => {
    m.castShadow = true;
    g.add(m);
  });
  return { group: g, limbs: { armL, armR, legL, legR } };
}

function makeViewModel(skin: string, shirt: string) {
  const root = new THREE.Group();
  const handGeo = new THREE.BoxGeometry(0.16, 0.16, 0.44);
  const skinMat = new THREE.MeshLambertMaterial({ color: skin });
  const sleeveMat = new THREE.MeshLambertMaterial({ color: shirt });

  const right = new THREE.Group();
  const rHand = new THREE.Mesh(handGeo, skinMat);
  const rSleeve = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.19, 0.34), sleeveMat);
  rSleeve.position.z = 0.34;
  right.add(rHand, rSleeve);
  right.position.set(0.3, -0.3, -0.62);

  const left = new THREE.Group();
  const lHand = new THREE.Mesh(handGeo, skinMat);
  const lSleeve = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.19, 0.34), sleeveMat);
  lSleeve.position.z = 0.34;
  left.add(lHand, lSleeve);
  left.position.set(-0.3, -0.34, -0.55);

  const item = new THREE.Group();
  right.add(item);
  root.add(right, left);
  root.renderOrder = 10;
  return { root, right, left, item };
}

function buildItem(kind: "gun" | "melee" | "throwable" | "none", tint: string) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color: tint });
  const dark = new THREE.MeshLambertMaterial({ color: "#22203a" });
  if (kind === "gun") {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, 0.5), dark);
    body.position.set(0, 0.06, -0.28);
    const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.34), mat);
    barrel.position.set(0, 0.08, -0.6);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.2, 0.12), dark);
    grip.position.set(0, -0.06, -0.1);
    g.add(body, barrel, grip);
  } else if (kind === "melee") {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.85), mat);
    blade.position.set(0, 0.05, -0.55);
    const hilt = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 0.16), dark);
    hilt.position.set(0, 0.02, -0.1);
    g.add(blade, hilt);
  } else if (kind === "throwable") {
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 12), mat);
    ball.position.set(0, 0.05, -0.18);
    g.add(ball);
  }
  return g;
}

/* ---------------- GPU particle pool ---------------- */
class Particles {
  readonly points: THREE.Points;
  private N: number;
  private pos: Float32Array;
  private col: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private max: Float32Array;
  private grav: Float32Array;
  private base: Float32Array;
  private head = 0;

  constructor(n = 1400, size = 0.16) {
    this.N = n;
    this.pos = new Float32Array(n * 3).fill(-9999);
    this.col = new Float32Array(n * 3);
    this.vel = new Float32Array(n * 3);
    this.base = new Float32Array(n * 3);
    this.life = new Float32Array(n);
    this.max = new Float32Array(n).fill(1);
    this.grav = new Float32Array(n);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    const mat = new THREE.PointsMaterial({
      size,
      vertexColors: true,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true,
    });
    this.points = new THREE.Points(geo, mat);
    this.points.frustumCulled = false;
  }

  spawn(p: THREE.Vector3, count: number, opts: { color: THREE.Color; speed: number; life: number; gravity?: number; dir?: THREE.Vector3; spread?: number }) {
    const { color, speed, life, gravity = 0, dir, spread = 1 } = opts;
    for (let k = 0; k < count; k++) {
      const i = this.head;
      this.head = (this.head + 1) % this.N;
      const i3 = i * 3;
      this.pos[i3] = p.x;
      this.pos[i3 + 1] = p.y;
      this.pos[i3 + 2] = p.z;
      let vx = (Math.random() - 0.5) * 2;
      let vy = (Math.random() - 0.5) * 2;
      let vz = (Math.random() - 0.5) * 2;
      const l = Math.hypot(vx, vy, vz) || 1;
      vx /= l; vy /= l; vz /= l;
      if (dir) {
        vx = dir.x + vx * spread;
        vy = dir.y + vy * spread;
        vz = dir.z + vz * spread;
      }
      const s = speed * (0.5 + Math.random() * 0.8);
      this.vel[i3] = vx * s;
      this.vel[i3 + 1] = vy * s;
      this.vel[i3 + 2] = vz * s;
      this.base[i3] = color.r;
      this.base[i3 + 1] = color.g;
      this.base[i3 + 2] = color.b;
      this.col[i3] = color.r;
      this.col[i3 + 1] = color.g;
      this.col[i3 + 2] = color.b;
      const lf = life * (0.6 + Math.random() * 0.8);
      this.life[i] = lf;
      this.max[i] = lf;
      this.grav[i] = gravity;
    }
  }

  update(dt: number) {
    for (let i = 0; i < this.N; i++) {
      if (this.life[i] <= 0) continue;
      const i3 = i * 3;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.pos[i3 + 1] = -9999;
        this.col[i3] = this.col[i3 + 1] = this.col[i3 + 2] = 0;
        continue;
      }
      this.vel[i3 + 1] -= this.grav[i] * dt;
      this.pos[i3] += this.vel[i3] * dt;
      this.pos[i3 + 1] += this.vel[i3 + 1] * dt;
      this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      if (this.pos[i3 + 1] < 0.03 && this.grav[i] > 0) {
        this.pos[i3 + 1] = 0.03;
        this.vel[i3 + 1] *= -0.32;
        this.vel[i3] *= 0.7;
        this.vel[i3 + 2] *= 0.7;
      }
      const t = this.life[i] / this.max[i];
      this.col[i3] = this.base[i3] * t;
      this.col[i3 + 1] = this.base[i3 + 1] * t;
      this.col[i3 + 2] = this.base[i3 + 2] * t;
    }
    (this.points.geometry.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.getAttribute("color") as THREE.BufferAttribute).needsUpdate = true;
  }
}

type Pop = { id: number; dmg: number; crit: boolean; x: number; y: number };
type Grenade = { mesh: THREE.Mesh; vel: THREE.Vector3; fuse: number };
type Bullet = { mesh: THREE.Mesh; from: THREE.Vector3; to: THREE.Vector3; t: number; speed: number };

export function RoShooter({
  mapId,
  avatar,
  weaponId,
  styleId,
  ownedWeapons,
  ownedSkills,
  identity,
  serverId,
  serverLabel,
  onLeave,
}: {
  mapId: string;
  avatar: BloxAvatar;
  weaponId: string;
  styleId: string;
  ownedWeapons: string[];
  ownedSkills: string[];
  identity: BloxIdentity;
  serverId: string;
  serverLabel?: string;
  onLeave: () => void;
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [menu, setMenu] = useState(false);
  const [tab, setTab] = useState<"main" | "controls" | "layout">("main");
  const [hud, setHud] = useState({
    hp: 100, kills: 0, players: 1, fps: 0, ammo: 0, clip: 0,
    reloading: false, rage: false, shield: false, ads: false, crouch: false,
    state: "idle", bounty: 0, nades: 3, combo: 0,
  });
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatText, setChatText] = useState("");
  const [board, setBoard] = useState<{ name: string; kills: number; admin: boolean }[]>([]);
  const [rank, setRank] = useState<{ rank: number; total: number } | null>(null);
  const [portrait, setPortrait] = useState(false);
  const [cool, setCool] = useState<SkillState>({ ...EMPTY_CD });
  const [pops, setPops] = useState<Pop[]>([]);
  const [hitAt, setHitAt] = useState(0);
  const [dmgFlash, setDmgFlash] = useState(0);
  const [killAt, setKillAt] = useState(0);
  const [styleIdLive, setStyleIdLive] = useState(styleId);
  const [settings, setSettings] = useState<BloxSettings>(DEFAULT_SETTINGS);
  const [editing, setEditing] = useState(false);
  const [nadeAim, setNadeAim] = useState(false);

  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const styleRef = useRef(styleId);
  const menuRef = useRef(false);
  menuRef.current = menu || chatOpen;
  const netRef = useRef<BloxNet | null>(null);
  const pendingKills = useRef(0);
  const popId = useRef(1);

  type Api = {
    touch: { mx: number; mz: number; firing: boolean; run: boolean; ads: boolean; crouch: boolean };
    look: (dx: number, dy: number) => void;
    jump: () => void;
    slide: () => void;
    respawn: () => void;
    skill: (id: SkillId) => void;
    reload: () => void;
    slot: (i: number) => void;
    melee: () => void;
    nadeStart: () => void;
    nadeAim: (dx: number, dy: number) => void;
    nadeThrow: () => void;
    cmd: (c: string, v: string) => string | null;
  };
  const apiRef = useRef<Api | null>(null);

  const map = MAPS.find((m) => m.id === mapId) ?? MAPS[0];

  const slots = [WEAPONS[0], ...WEAPONS.filter((w) => w.id !== "fists" && ownedWeapons.includes(w.id))];
  const startIndex = Math.max(0, slots.findIndex((w) => w.id === weaponId));
  const [slot, setSlot] = useState(startIndex);
  const slotRef = useRef(startIndex);

  const selectSlot = useCallback((i: number) => {
    if (i < 0 || i >= slots.length) return;
    slotRef.current = i;
    setSlot(i);
    gsfx.swap();
  }, [slots.length]);

  useEffect(() => setSettings(loadSettings()), []);
  useEffect(() => {
    setGameVolume(settings.volume / 100);
    setHaptics(settings.haptics);
  }, [settings.volume, settings.haptics]);
  const patch = useCallback((p: Partial<BloxSettings>) => {
    setSettings((s) => {
      const next = { ...s, ...p };
      saveSettings(next);
      return next;
    });
  }, []);

  useEffect(() => {
    const check = () => setPortrait(window.innerHeight > window.innerWidth);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  useEffect(() => {
    const load = () => void fetchMyRank(identity.name).then((r) => r && setRank({ rank: r.rank, total: r.total }));
    load();
    const id = window.setInterval(load, 20000);
    return () => window.clearInterval(id);
  }, [identity.name]);

  useEffect(() => {
    const id = window.setInterval(() => {
      const n = pendingKills.current;
      if (n > 0) {
        pendingKills.current = 0;
        void reportKills(identity.name, n);
      }
    }, 5000);
    return () => {
      const n = pendingKills.current;
      pendingKills.current = 0;
      if (n > 0) void reportKills(identity.name, n);
      window.clearInterval(id);
    };
  }, [identity.name]);

  const addPop = useCallback((dmg: number, crit: boolean) => {
    const id = popId.current++;
    setPops((p) => [...p.slice(-8), { id, dmg: Math.round(dmg), crit, x: (Math.random() - 0.5) * 120, y: (Math.random() - 0.5) * 60 }]);
    window.setTimeout(() => setPops((p) => p.filter((q) => q.id !== id)), 800);
  }, []);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    /* ---------- renderer / scene ---------- */
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(map.a);
    scene.fog = new THREE.Fog(new THREE.Color(map.a), 40, 140);
    const BASE_FOV = 80;
    const ADS_FOV = 50;
    const camera = new THREE.PerspectiveCamera(BASE_FOV, 16 / 9, 0.1, 400);
    const rig = new THREE.Group();
    rig.add(camera);
    scene.add(rig);

    const resize = () => {
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || window.innerHeight;
      const cap = Math.min(1920 / w, 1080 / h, window.devicePixelRatio, 2);
      renderer.setPixelRatio(Math.max(0.75, cap));
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    window.addEventListener("resize", resize);

    scene.add(new THREE.HemisphereLight(0xffffff, new THREE.Color(map.b), 1.35));
    scene.add(new THREE.AmbientLight(0xffffff, 0.55));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(30, 50, 20);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -70;
    sun.shadow.camera.right = 70;
    sun.shadow.camera.top = 70;
    sun.shadow.camera.bottom = -70;
    scene.add(sun);

    /* ---------- particles / fx ---------- */
    const sparks = new Particles(1600, 0.14);
    scene.add(sparks.points);
    const smoke = new Particles(700, 0.9);
    (smoke.points.material as THREE.PointsMaterial).blending = THREE.NormalBlending;
    (smoke.points.material as THREE.PointsMaterial).opacity = 0.55;
    scene.add(smoke.points);

    const muzzleLight = new THREE.PointLight(0xffd27a, 0, 14, 2);
    camera.add(muzzleLight);
    muzzleLight.position.set(0.3, -0.2, -1.0);
    const flash = new THREE.Mesh(
      new THREE.PlaneGeometry(0.42, 0.42),
      new THREE.MeshBasicMaterial({ color: 0xffe6a3, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthTest: false }),
    );
    flash.position.set(0.3, -0.18, -1.05);
    flash.renderOrder = 20;
    camera.add(flash);

    /* ---------- view model ---------- */
    const vm = makeViewModel(avatar.skin, avatar.shirt);
    camera.add(vm.root);
    let itemMesh: THREE.Group | null = null;
    const setItem = (kind: "gun" | "melee" | "throwable" | "none") => {
      if (itemMesh) vm.item.remove(itemMesh);
      itemMesh = kind === "none" ? null : buildItem(kind, avatar.shirt);
      if (itemMesh) vm.item.add(itemMesh);
    };

    /* ---------- map ---------- */
    const colliders: Box[] = [];
    const addBox = (x: number, y: number, z: number, w: number, h: number, d: number, color: string) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
      m.position.set(x, y + h / 2, z);
      m.castShadow = true;
      m.receiveShadow = true;
      scene.add(m);
      colliders.push({ min: new THREE.Vector3(x - w / 2, y, z - d / 2), max: new THREE.Vector3(x + w / 2, y + h, z + d / 2) });
      return m;
    };

    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(ARENA * 2, 1, ARENA * 2),
      new THREE.MeshLambertMaterial({ color: new THREE.Color(map.a).lerp(new THREE.Color("#ffffff"), 0.45) }),
    );
    floor.position.y = -0.5;
    floor.receiveShadow = true;
    scene.add(floor);

    const grid = new THREE.GridHelper(ARENA * 2, 48, new THREE.Color(map.b), new THREE.Color(map.b));
    (grid.material as THREE.Material).opacity = 0.18;
    (grid.material as THREE.Material).transparent = true;
    grid.position.y = 0.02;
    scene.add(grid);

    addBox(0, 0, -ARENA, ARENA * 2, 8, 2, map.b);
    addBox(0, 0, ARENA, ARENA * 2, 8, 2, map.b);
    addBox(-ARENA, 0, 0, 2, 8, ARENA * 2, map.b);
    addBox(ARENA, 0, 0, 2, 8, ARENA * 2, map.b);

    const seed = Array.from(map.id).reduce((a, c) => a + c.charCodeAt(0), 7);
    const rnd = rng(seed * 977);
    for (let i = 0; i < 46; i++) {
      const w = 3 + rnd() * 8;
      const d = 3 + rnd() * 8;
      const h = 1.4 + rnd() * 7;
      const x = (rnd() - 0.5) * (ARENA * 1.7);
      const z = (rnd() - 0.5) * (ARENA * 1.7);
      if (Math.hypot(x, z) < 8) continue;
      const c = new THREE.Color(map.b).lerp(new THREE.Color(map.a), rnd() * 0.7);
      const base = addBox(x, 0, z, w, h, d, `#${c.getHexString()}`);
      if (rnd() > 0.6) addBox(x + (rnd() - 0.5) * w, h, z + (rnd() - 0.5) * d, w * 0.55, 1.2 + rnd() * 2.5, d * 0.55, `#${c.getHexString()}`);
      base.receiveShadow = true;
    }

    /* ---------- actors ---------- */
    const actors = new Map<string, Actor>();
    const spawn = () => new THREE.Vector3((Math.random() - 0.5) * ARENA * 1.6, 0, (Math.random() - 0.5) * ARENA * 1.6);

    const addActor = (id: string, name: string, admin: boolean, bot: boolean, shirt: string, skin: string) => {
      const { group, limbs } = makeBody(shirt, skin, "#241b46");
      group.add(nameSprite(name, admin));
      scene.add(group);
      const p = spawn();
      const a: Actor = {
        id, name, admin, bot, hp: 100, kills: 0, pos: p, target: p.clone(),
        ry: 0, cd: 0, group, limbs, phase: Math.random() * 6, last: performance.now(), flash: 0,
      };
      group.position.copy(p);
      actors.set(id, a);
      return a;
    };

    const removeActor = (id: string) => {
      const a = actors.get(id);
      if (!a) return;
      scene.remove(a.group);
      actors.delete(id);
    };

    const BOTS = ["Kai_x", "Nova99", "Blox_Ren", "Pixel", "Yuki", "Zero", "Mika"];
    BOTS.slice(0, 5).forEach((n, i) => addActor(`bot-${i}`, n, false, true, `hsl(${i * 61} 80% 60%)`, "#f2c9a0"));

    /* ---------- local player ---------- */
    const me = {
      pos: new THREE.Vector3(0, 0, 0),
      vel: new THREE.Vector3(),
      yaw: 0, pitch: 0,
      tyaw: 0, tpitch: 0,
      grounded: false, wasGrounded: true,
      hp: 100, kills: 0, bounty: 0, cd: 0,
      ammo: slots[startIndex]?.clip ?? 0,
      reloading: 0, dashing: 0, rage: 0, shield: 0,
      recoil: 0, swing: 0, bob: 0, running: false,
      crouch: false, sliding: 0, ads: 0,
      nades: 3, combo: 0, comboAt: 0,
      stepT: 0, shake: 0, roll: 0,
    };
    const cds: SkillState = { ...EMPTY_CD };

    const keys = new Set<string>();
    const touch = { mx: 0, mz: 0, firing: false, run: false, ads: false, crouch: false };

    const shakeIt = (amount: number) => {
      me.shake = Math.min(1.6, me.shake + amount * (settingsRef.current.shake / 100));
    };

    const collide = (pos: THREE.Vector3, vel: THREE.Vector3, dt: number) => {
      const R = 0.45;
      const HEIGHT = me.crouch ? 1.2 : 1.8;
      const move = (axis: "x" | "y" | "z") => {
        pos[axis] += vel[axis] * dt;
        const minP = new THREE.Vector3(pos.x - R, pos.y, pos.z - R);
        const maxP = new THREE.Vector3(pos.x + R, pos.y + HEIGHT, pos.z + R);
        for (const b of colliders) {
          if (maxP.x <= b.min.x || minP.x >= b.max.x) continue;
          if (maxP.y <= b.min.y || minP.y >= b.max.y) continue;
          if (maxP.z <= b.min.z || minP.z >= b.max.z) continue;
          if (axis === "y") {
            if (vel.y <= 0) {
              pos.y = b.max.y;
              me.grounded = true;
            } else pos.y = b.min.y - HEIGHT;
            vel.y = 0;
          } else if (axis === "x") {
            pos.x = vel.x > 0 ? b.min.x - R : b.max.x + R;
            vel.x = 0;
          } else {
            pos.z = vel.z > 0 ? b.min.z - R : b.max.z + R;
            vel.z = 0;
          }
          minP.set(pos.x - R, pos.y, pos.z - R);
          maxP.set(pos.x + R, pos.y + HEIGHT, pos.z + R);
        }
      };
      move("x");
      move("z");
      move("y");
      if (pos.y <= 0) {
        pos.y = 0;
        vel.y = 0;
        me.grounded = true;
      }
      pos.x = THREE.MathUtils.clamp(pos.x, -ARENA + 2, ARENA - 2);
      pos.z = THREE.MathUtils.clamp(pos.z, -ARENA + 2, ARENA - 2);
    };

    /* ---------- networking ---------- */
    const net = new BloxNet(serverId);
    netRef.current = net;
    const myName = identity.isAdmin ? `[ADMIN OWNER] ${identity.name} ✓` : identity.name;
    const pushChat = (m: ChatMsg) => setChat((c) => [...c.slice(-40), m]);

    const netMe = (): NetPlayerState => ({
      id: net.id, name: identity.name, admin: identity.isAdmin,
      x: me.pos.x, y: me.pos.y, z: me.pos.z, ry: me.yaw,
      hp: me.hp, kills: me.kills, shirt: avatar.shirt, skin: avatar.skin,
    });

    const takeDamage = (dmg: number, byName: string) => {
      const d = me.shield > 0 ? dmg * 0.35 : dmg;
      me.hp -= d;
      gsfx.hurt();
      shakeIt(0.28 + d / 260);
      setDmgFlash(Date.now());
      if (me.hp <= 0) {
        me.hp = 0;
        gsfx.explode();
        shakeIt(0.9);
        pushChat({ id: crypto.randomUUID(), from: "server", admin: false, system: true, text: `${byName} took down ${myName}`, at: Date.now() });
      }
    };

    void net
      .join(netMe(), {
        onState: (s) => {
          if (s.id === net.id || s.name === identity.name) return;
          let a = actors.get(s.id);
          if (!a) a = addActor(s.id, s.name, s.admin, false, s.shirt, s.skin);
          a.target.set(s.x, s.y, s.z);
          a.ry = s.ry;
          a.hp = s.hp;
          a.kills = s.kills;
          a.last = performance.now();
        },
        onLeave: (id) => removeActor(id),
        onChat: (m) => pushChat(m),
        onHit: (p) => {
          if (p.target !== net.id) return;
          takeDamage(p.dmg, p.byName);
        },
        onCount: (n) => setHud((h) => ({ ...h, players: n })),
      })
      .then(() => {
        const msg = identity.isAdmin ? "⚠ Admin has arrived — [ADMIN OWNER] TokemekiAi ✓" : `${identity.name} joined the server`;
        pushChat(net.sendChat({ from: "server", admin: identity.isAdmin, text: msg, system: true }));
      });

    /* ---------- combat ---------- */
    const currentWeapon = () => slots[Math.min(slotRef.current, slots.length - 1)] ?? WEAPONS[0];
    const currentStyle = () => FIGHT_STYLES.find((s) => s.id === styleRef.current) ?? FIGHT_STYLES[0];

    const reload = () => {
      const w = currentWeapon();
      if (w.clip <= 0 || me.reloading > 0 || me.ammo === w.clip) return;
      me.reloading = w.reload;
      gsfx.reloadOut();
      window.setTimeout(() => gsfx.reloadIn(), Math.max(120, w.reload * 0.45));
    };

    const ray = new THREE.Raycaster();
    const bullets: Bullet[] = [];
    const grenades: Grenade[] = [];

    const damage = (base: number) => base * (me.rage > 0 ? 2 : 1);

    const killFx = (p: THREE.Vector3) => {
      sparks.spawn(p, 46, { color: new THREE.Color("#ff4fa3"), speed: 9, life: 0.7, gravity: 9 });
      gsfx.kill();
      setKillAt(Date.now());
      me.kills += 1;
      me.bounty += 25;
      pendingKills.current += 1;
      shakeIt(0.2);
    };

    const hitActor = (a: Actor, dmg: number, crit = false) => {
      a.hp -= dmg;
      a.flash = 180;
      const hp = new THREE.Vector3(a.pos.x, a.pos.y + 1.3, a.pos.z);
      sparks.spawn(hp, 14, { color: new THREE.Color(crit ? "#ffd166" : "#ff6b9a"), speed: 5.5, life: 0.4, gravity: 12 });
      gsfx.hitmark();
      gsfx.impact();
      setHitAt(Date.now());
      addPop(dmg, crit);
      if (a.bot) {
        if (a.hp <= 0) {
          a.hp = 100;
          killFx(hp);
          a.pos.copy(spawn());
          a.target.copy(a.pos);
          pushChat({ id: crypto.randomUUID(), from: "server", admin: false, system: true, text: `${myName} took down ${a.name}`, at: Date.now() });
        }
      } else {
        net.sendHit(a.id, myName, dmg);
        if (a.hp <= 0) {
          a.hp = 100;
          killFx(hp);
        }
      }
    };

    const pickTarget = (from: THREE.Vector3, dir: THREE.Vector3, far: number, radius: number) => {
      let best: Actor | null = null;
      let bestD = Infinity;
      actors.forEach((a) => {
        if (a.hp <= 0) return;
        const c = new THREE.Vector3(a.pos.x, a.pos.y + 1.2, a.pos.z);
        const toC = c.clone().sub(from);
        const along = toC.dot(dir);
        if (along <= 0 || along > far) return;
        const perp = toC.clone().sub(dir.clone().multiplyScalar(along)).length();
        if (perp < radius && along < bestD) {
          bestD = along;
          best = a;
        }
      });
      return { best: best as Actor | null, dist: bestD };
    };

    const muzzleFx = (dir: THREE.Vector3, from: THREE.Vector3, to: THREE.Vector3) => {
      muzzleLight.intensity = 4.5;
      (flash.material as THREE.MeshBasicMaterial).opacity = 0.95;
      flash.rotation.z = Math.random() * Math.PI;
      const bMat = new THREE.MeshBasicMaterial({ color: 0xfff0b0, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false });
      const bGeo = new THREE.CylinderGeometry(0.035, 0.01, 1.3, 6);
      bGeo.rotateX(Math.PI / 2);
      const mesh = new THREE.Mesh(bGeo, bMat);
      mesh.position.copy(from);
      mesh.lookAt(to);
      scene.add(mesh);
      bullets.push({ mesh, from: from.clone(), to: to.clone(), t: 0, speed: 190 });
      const muzzle = from.clone().add(dir.clone().multiplyScalar(0.9));
      sparks.spawn(muzzle, 10, { color: new THREE.Color("#ffd27a"), speed: 6, life: 0.16, dir, spread: 0.55 });
      smoke.spawn(muzzle, 3, { color: new THREE.Color("#6b6480"), speed: 1.2, life: 0.7, dir, spread: 1 });
    };

    const explode = (at: THREE.Vector3, dmg: number, radius: number) => {
      sparks.spawn(at, 130, { color: new THREE.Color("#ffb347"), speed: 16, life: 0.75, gravity: 12 });
      sparks.spawn(at, 60, { color: new THREE.Color("#ff4d3d"), speed: 9, life: 1.0, gravity: 6 });
      smoke.spawn(at, 40, { color: new THREE.Color("#4a4358"), speed: 4.2, life: 1.8 });
      const light = new THREE.PointLight(0xffa15a, 22, 30, 2);
      light.position.copy(at);
      scene.add(light);
      window.setTimeout(() => scene.remove(light), 160);
      gsfx.explode();
      const d = me.pos.distanceTo(at);
      shakeIt(Math.max(0, 1.4 - d / radius));
      actors.forEach((a) => {
        const dist = a.pos.distanceTo(at);
        if (dist < radius) hitActor(a, damage(dmg * (1 - dist / radius)), true);
      });
    };

    const throwNade = (power = 1) => {
      if (me.nades <= 0) return;
      me.nades -= 1;
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(me.pitch, me.yaw, 0, "YXZ"));
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 10), new THREE.MeshLambertMaterial({ color: "#ff4fa3", emissive: new THREE.Color("#5a0f30") }));
      mesh.position.set(me.pos.x, me.pos.y + EYE, me.pos.z).add(dir.clone().multiplyScalar(0.8));
      scene.add(mesh);
      grenades.push({ mesh, vel: dir.multiplyScalar(20 * power).add(new THREE.Vector3(0, 4.2 * power, 0)), fuse: 1500 });
      gsfx.throwGrenade();
      me.swing = 1;
    };

    const melee = () => {
      const st = currentStyle();
      const w = currentWeapon();
      const isWeaponMelee = w.kind === "melee" && w.id !== "fists";
      const now = performance.now();
      if (now - me.comboAt > 1000) me.combo = 0;
      me.comboAt = now;
      me.combo = (me.combo + 1) % 3;
      const kick = me.combo === 0;
      const dmg = damage((isWeaponMelee ? w.dmg : st.dmg) * (kick ? 1.6 : 1));
      const reach = isWeaponMelee ? 3.4 : st.reach + 0.6;
      me.swing = kick ? 1.35 : 1;
      if (isWeaponMelee) gsfx.swing();
      else if (kick) gsfx.kick();
      else gsfx.punch();
      shakeIt(kick ? 0.18 : 0.08);
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(me.pitch, me.yaw, 0, "YXZ"));
      const from = new THREE.Vector3(me.pos.x, me.pos.y + EYE, me.pos.z);
      const { best } = pickTarget(from, dir, reach, 1.45);
      if (best) hitActor(best, dmg, kick);
      setHud((h) => ({ ...h, combo: me.combo }));
    };

    const fire = () => {
      const w = currentWeapon();
      if (w.kind === "melee") {
        melee();
        return;
      }
      if (w.kind === "throwable") {
        throwNade(1);
        return;
      }
      if (w.clip > 0) {
        if (me.reloading > 0) return;
        if (me.ammo <= 0) {
          gsfx.dryFire();
          reload();
          return;
        }
        me.ammo -= 1;
      }
      const spread = (me.ads > 0.6 ? 0.0012 : 0.006) * (me.running ? 2.2 : 1);
      const dir = new THREE.Vector3(0, 0, -1)
        .applyEuler(new THREE.Euler(me.pitch + (Math.random() - 0.5) * spread * 6, me.yaw + (Math.random() - 0.5) * spread * 6, 0, "YXZ"));
      const from = new THREE.Vector3(me.pos.x, me.pos.y + (me.crouch ? CROUCH_EYE : EYE), me.pos.z).add(dir.clone().multiplyScalar(0.6));
      ray.set(from, dir);
      ray.far = 140;
      const { best, dist } = pickTarget(from, dir, ray.far, me.ads > 0.6 ? 0.75 : 0.95);
      const end = from.clone().add(dir.clone().multiplyScalar(dist === Infinity ? ray.far : dist));

      me.recoil = 1;
      me.pitch += 0.012 + Math.random() * 0.008;
      me.tpitch += 0.01;
      muzzleFx(dir, from, end);
      gsfx.shoot(w.id === "rifle" ? "rifle" : w.id === "smg" ? "smg" : "pistol");
      shakeIt(w.id === "rifle" ? 0.24 : w.id === "smg" ? 0.09 : 0.14);

      if (best) hitActor(best, damage(w.dmg), me.ads > 0.6);
      else {
        sparks.spawn(end, 10, { color: new THREE.Color("#cfd6ff"), speed: 4.5, life: 0.3, gravity: 10 });
        smoke.spawn(end, 3, { color: new THREE.Color("#5b556e"), speed: 1.4, life: 0.6 });
      }
    };

    const useSkill = (id: SkillId) => {
      if (cds[id] > 0) return;
      const def = SKILLS.find((s) => s.id === id);
      if (id !== "dash" && !ownedSkills.includes(id) && !identity.isAdmin) return;
      cds[id] = def?.cooldown ?? 12000;
      const at = new THREE.Vector3(me.pos.x, me.pos.y + 1, me.pos.z);
      if (id === "dash") {
        const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, me.yaw, 0, "YXZ"));
        me.vel.x = dir.x * DASH;
        me.vel.z = dir.z * DASH;
        me.dashing = 240;
        gsfx.dash();
        shakeIt(0.35);
        sparks.spawn(at, 40, { color: new THREE.Color("#49d8ff"), speed: 7, life: 0.45, dir: dir.clone().negate(), spread: 0.8 });
      } else if (id === "heal") {
        me.hp = Math.min(100, me.hp + 45);
        gsfx.heal();
        sparks.spawn(at, 40, { color: new THREE.Color("#7cffb2"), speed: 3, life: 0.9, gravity: -3 });
      } else if (id === "shock") {
        gsfx.shock();
        shakeIt(0.7);
        sparks.spawn(at, 110, { color: new THREE.Color("#a97bff"), speed: 14, life: 0.6, gravity: 4 });
        actors.forEach((a) => {
          if (a.pos.distanceTo(me.pos) < 9) hitActor(a, damage(40), true);
        });
      } else if (id === "rage") {
        me.rage = 8000;
        gsfx.rage();
        shakeIt(0.5);
        sparks.spawn(at, 70, { color: new THREE.Color("#ff2d3f"), speed: 6, life: 0.9, gravity: -1 });
      } else if (id === "shield") {
        me.shield = 9000;
        gsfx.shield();
        sparks.spawn(at, 60, { color: new THREE.Color("#8ef0ff"), speed: 4, life: 0.8, gravity: -2 });
      } else if (id === "smoke") {
        gsfx.throwGrenade();
        smoke.spawn(at, 120, { color: new THREE.Color("#8d879c"), speed: 3.4, life: 3.2 });
      }
      setCool({ ...cds });
    };

    /* ---------- input ---------- */
    const canvas = renderer.domElement;
    const look = (dx: number, dy: number) => {
      const s = settingsRef.current;
      const sens = (me.ads > 0.6 ? s.aimSens : s.camSens) / 100;
      me.tyaw -= dx * 0.0025 * sens;
      me.tpitch = THREE.MathUtils.clamp(me.tpitch - dy * 0.0025 * sens, -1.35, 1.35);
    };

    const jump = () => {
      if (me.grounded) {
        me.vel.y = JUMP;
        me.grounded = false;
        gsfx.jump();
      }
    };
    const slide = () => {
      if (!me.grounded || me.sliding > 0) return;
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, me.yaw, 0, "YXZ"));
      me.vel.x = dir.x * RUN * 1.7;
      me.vel.z = dir.z * RUN * 1.7;
      me.sliding = 750;
      me.crouch = true;
      gsfx.slide();
      shakeIt(0.25);
      sparks.spawn(new THREE.Vector3(me.pos.x, 0.1, me.pos.z), 26, { color: new THREE.Color("#ffffff"), speed: 4, life: 0.5, gravity: 6 });
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        setChatOpen((v) => !v);
        return;
      }
      if (e.key === "Escape") setMenu((m) => !m);
      const k = e.key.toLowerCase();
      if (k === "r") reload();
      if (k === "shift") useSkill("dash");
      if (k === "c") {
        me.crouch = !me.crouch;
        gsfx.crouch();
      }
      if (k === "v") melee();
      if (k === "g") throwNade(1);
      if (k === "x") slide();
      if (k === "3") useSkill("heal");
      if (k === "4") useSkill("shock");
      if (k === "5") useSkill("rage");
      if (k === "6") useSkill("shield");
      if (k === "1" || k === "2") selectSlot(Number(k) - 1);
      keys.add(k);
    };
    const onKeyUp = (e: KeyboardEvent) => keys.delete(e.key.toLowerCase());
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    const onWheel = (e: WheelEvent) => {
      const n = (slotRef.current + (e.deltaY > 0 ? 1 : -1) + slots.length) % slots.length;
      selectSlot(n);
    };
    canvas.addEventListener("wheel", onWheel, { passive: true });

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      look(e.movementX, e.movementY);
    };
    document.addEventListener("mousemove", onMouseMove);
    const requestLock = () => {
      if (!menuRef.current) canvas.requestPointerLock?.();
    };
    canvas.addEventListener("click", requestLock);
    const onMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      if (e.button === 2) {
        touch.ads = true;
        gsfx.ads(true);
      } else touch.firing = true;
    };
    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 2) {
        touch.ads = false;
        gsfx.ads(false);
      } else touch.firing = false;
    };
    const onCtx = (e: Event) => e.preventDefault();
    canvas.addEventListener("mousedown", onMouseDown);
    canvas.addEventListener("contextmenu", onCtx);
    window.addEventListener("mouseup", onMouseUp);

    // right-half swipe camera (works while firing / moving)
    const lookIds = new Map<number, { x: number; y: number }>();
    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType !== "touch") return;
      if (e.clientX > window.innerWidth * 0.4) lookIds.set(e.pointerId, { x: e.clientX, y: e.clientY });
    };
    const onPointerMove = (e: PointerEvent) => {
      const p = lookIds.get(e.pointerId);
      if (!p) return;
      look(e.clientX - p.x, e.clientY - p.y);
      p.x = e.clientX;
      p.y = e.clientY;
    };
    const onPointerUp = (e: PointerEvent) => lookIds.delete(e.pointerId);
    canvas.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);

    // gyro
    const onOrient = (e: DeviceOrientationEvent) => {
      if (!settingsRef.current.gyro) return;
      const g = e.gamma ?? 0;
      const b = e.beta ?? 0;
      me.tyaw -= g * 0.0006 * (settingsRef.current.camSens / 100);
      me.tpitch = THREE.MathUtils.clamp(me.tpitch - (b - 45) * 0.0002, -1.35, 1.35);
    };
    window.addEventListener("deviceorientation", onOrient);

    /* ---------- trajectory preview ---------- */
    const traj = new THREE.Line(
      new THREE.BufferGeometry(),
      new THREE.LineDashedMaterial({ color: 0xff4fa3, dashSize: 0.4, gapSize: 0.3 }),
    );
    traj.visible = false;
    scene.add(traj);
    const landing = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.55, 20),
      new THREE.MeshBasicMaterial({ color: 0xff4fa3, side: THREE.DoubleSide, transparent: true, opacity: 0.8 }),
    );
    landing.rotation.x = -Math.PI / 2;
    landing.visible = false;
    scene.add(landing);
    let aimingNade = false;
    let nadePower = 1;

    const updateTraj = () => {
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(me.pitch, me.yaw, 0, "YXZ"));
      const p = new THREE.Vector3(me.pos.x, me.pos.y + EYE, me.pos.z);
      const v = dir.multiplyScalar(20 * nadePower).add(new THREE.Vector3(0, 4.2 * nadePower, 0));
      const pts: THREE.Vector3[] = [];
      const step = 0.04;
      for (let i = 0; i < 70; i++) {
        pts.push(p.clone());
        v.y -= GRAVITY * step;
        p.addScaledVector(v, step);
        if (p.y <= 0.1) break;
      }
      traj.geometry.dispose();
      traj.geometry = new THREE.BufferGeometry().setFromPoints(pts);
      traj.computeLineDistances();
      landing.position.set(p.x, 0.06, p.z);
    };

    apiRef.current = {
      touch,
      look,
      jump,
      slide,
      respawn: () => {
        me.hp = 100;
        const p = spawn();
        me.pos.set(p.x, 4, p.z);
        me.vel.set(0, 0, 0);
        me.nades = 3;
      },
      skill: (id) => useSkill(id),
      reload,
      slot: (i) => selectSlot(i),
      melee,
      nadeStart: () => {
        aimingNade = true;
        nadePower = 1;
        traj.visible = true;
        landing.visible = true;
        gsfx.ui();
      },
      nadeAim: (dx, dy) => {
        look(dx * 0.6, dy * 0.6);
        nadePower = THREE.MathUtils.clamp(nadePower - dy * 0.004, 0.45, 1.6);
      },
      nadeThrow: () => {
        aimingNade = false;
        traj.visible = false;
        landing.visible = false;
        throwNade(nadePower);
      },
      cmd: (c, v) => {
        const n = Number(v);
        if (c === "h") {
          me.hp = THREE.MathUtils.clamp(Number.isFinite(n) ? n : 100, 0, 999);
          gsfx.heal();
          return `Health set to ${Math.round(me.hp)}`;
        }
        if (c === "b") {
          me.ammo = Math.max(0, Number.isFinite(n) ? Math.floor(n) : 30);
          me.reloading = 0;
          gsfx.reloadIn();
          return `Bullets set to ${me.ammo}`;
        }
        if (c === "bo" || c === "bounty") {
          me.bounty = Math.max(0, Number.isFinite(n) ? Math.floor(n) : 0);
          return `Bounty set to ${me.bounty}`;
        }
        if (c === "k") {
          me.kills = Math.max(0, Number.isFinite(n) ? Math.floor(n) : 0);
          return `Eliminations set to ${me.kills}`;
        }
        if (c === "f") {
          const key = v.trim().toLowerCase();
          const found = FIGHT_STYLES.find((s) => s.id === key || s.name.toLowerCase().includes(key));
          if (!found) return `Unknown fighting style "${v}"`;
          styleRef.current = found.id;
          setStyleIdLive(found.id);
          gsfx.swap();
          return `Fighting style → ${found.name}`;
        }
        return null;
      },
    };

    /* ---------- loop ---------- */
    let raf = 0;
    let last = performance.now();
    let frames = 0;
    let fpsT = 0;
    let netT = 0;
    let curKind = "";

    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      frames++;
      fpsT += dt;
      const S = settingsRef.current;

      const w = currentWeapon();
      const st = currentStyle();
      if (curKind !== w.id) {
        curKind = w.id;
        setItem(w.id === "fists" ? "none" : w.kind);
        me.ammo = w.clip;
        me.reloading = 0;
      }

      /* smoothed camera follow */
      const k = 1 - Math.exp(-dt * (26 - S.smoothing * 0.2));
      me.yaw += (me.tyaw - me.yaw) * k;
      me.pitch += (me.tpitch - me.pitch) * k;

      let speedNow = 0;
      if (!menuRef.current && me.hp > 0) {
        let fx = 0;
        let fz = 0;
        if (keys.has("w") || keys.has("arrowup")) fz -= 1;
        if (keys.has("s") || keys.has("arrowdown")) fz += 1;
        if (keys.has("a") || keys.has("arrowleft")) fx -= 1;
        if (keys.has("d") || keys.has("arrowright")) fx += 1;
        const joy = S.joySens / 100;
        fx += touch.mx * joy;
        fz += touch.mz * joy;
        if (keys.has(" ")) jump();

        const push = Math.hypot(fx, fz);
        const moving = push > 0.15;
        me.crouch = touch.crouch || me.crouch;
        if (!touch.crouch && me.sliding <= 0 && !keys.has("c")) {
          // crouch stays toggled by button/key only
        }
        me.running = moving && !me.crouch && (keys.has("control") || keys.has("q") || touch.run || S.autoSprint || push > 0.92);
        const adsSlow = touch.ads ? 0.55 : 1;
        const crouchSlow = me.crouch ? 0.5 : 1;
        const spd = (me.running ? RUN : WALK) * adsSlow * crouchSlow;

        if (me.dashing > 0) me.dashing -= dt * 1000;
        else if (me.sliding > 0) {
          me.sliding -= dt * 1000;
          me.vel.x *= 0.965;
          me.vel.z *= 0.965;
          if (me.sliding <= 0) me.crouch = false;
        } else {
          const len = push || 1;
          const nx = (fx / len) * (moving ? spd : 0);
          const nz = (fz / len) * (moving ? spd : 0);
          const cos = Math.cos(me.yaw);
          const sin = Math.sin(me.yaw);
          me.vel.x = nx * cos - nz * sin;
          me.vel.z = nx * sin + nz * cos;
        }
        me.vel.y -= GRAVITY * dt;
        me.wasGrounded = me.grounded;
        me.grounded = false;
        collide(me.pos, me.vel, dt);
        speedNow = Math.hypot(me.vel.x, me.vel.z);
        if (me.grounded && !me.wasGrounded) {
          gsfx.land();
          shakeIt(0.16);
          sparks.spawn(new THREE.Vector3(me.pos.x, 0.06, me.pos.z), 14, { color: new THREE.Color("#ffffff"), speed: 3, life: 0.35, gravity: 8 });
        }

        // footsteps
        if (me.grounded && speedNow > 1.2) {
          me.stepT -= dt * speedNow;
          if (me.stepT <= 0) {
            me.stepT = me.running ? 3.4 : 4.4;
            gsfx.step(me.running);
          }
        }

        me.cd -= dt * 1000;
        if (me.reloading > 0) {
          me.reloading -= dt * 1000;
          if (me.reloading <= 0) {
            me.reloading = 0;
            me.ammo = w.clip;
          }
        }
        const rate = w.id === "fists" ? st.rate : w.rate;
        const wantFire = touch.firing || (S.autoFire && !!pickTarget(
          new THREE.Vector3(me.pos.x, me.pos.y + EYE, me.pos.z),
          new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(me.pitch, me.yaw, 0, "YXZ")),
          60, 1.1,
        ).best);
        if (wantFire && me.cd <= 0 && me.reloading <= 0) {
          me.cd = rate;
          fire();
        }
      }

      if (me.rage > 0) me.rage -= dt * 1000;
      if (me.shield > 0) me.shield -= dt * 1000;
      (Object.keys(cds) as SkillId[]).forEach((s) => {
        if (cds[s] > 0) cds[s] = Math.max(0, cds[s] - dt * 1000);
      });

      /* ADS + fov */
      const adsTarget = touch.ads ? 1 : 0;
      me.ads += (adsTarget - me.ads) * Math.min(1, dt * 12);
      const targetFov = THREE.MathUtils.lerp(BASE_FOV, ADS_FOV, me.ads);
      if (Math.abs(camera.fov - targetFov) > 0.05) {
        camera.fov = THREE.MathUtils.lerp(camera.fov, targetFov, Math.min(1, dt * 12));
        camera.updateProjectionMatrix();
      }

      /* view-model animation */
      me.bob += dt * (speedNow > 0.4 ? (me.running ? 13 : 8.5) : 1.2);
      const bobAmp = (speedNow > 0.4 ? (me.running ? 0.05 : 0.028) : 0.006) * (1 - me.ads * 0.75);
      const airDip = me.grounded ? 0 : -0.06;
      me.recoil = Math.max(0, me.recoil - dt * 6);
      me.swing = Math.max(0, me.swing - dt * 4);
      const reloadT = me.reloading > 0 ? Math.sin((1 - me.reloading / Math.max(1, w.reload)) * Math.PI) : 0;
      const adsX = -0.3 * me.ads;
      const adsY = 0.12 * me.ads;

      vm.right.position.set(
        0.3 + adsX + Math.cos(me.bob) * bobAmp * 0.6,
        -0.3 + adsY + Math.sin(me.bob * 2) * bobAmp + airDip - reloadT * 0.35 - me.sliding * 0.0002,
        -0.62 + me.recoil * 0.12 + me.swing * 0.25 - me.ads * 0.08,
      );
      vm.right.rotation.set(
        -me.recoil * 0.45 - me.swing * 1.15 + reloadT * 1.1,
        me.swing * 0.5 + reloadT * 0.5,
        -me.swing * 0.4,
      );
      vm.left.position.set(
        -0.3 + adsX * 0.4 - Math.cos(me.bob) * bobAmp * 0.6,
        -0.34 + adsY - Math.sin(me.bob * 2) * bobAmp + airDip,
        -0.55 + (w.kind === "gun" ? 0.06 : 0) - reloadT * 0.2,
      );
      vm.left.rotation.set(-me.swing * 0.3 + reloadT * 0.4, 0, 0);

      /* muzzle flash decay */
      muzzleLight.intensity = Math.max(0, muzzleLight.intensity - dt * 40);
      const fm = flash.material as THREE.MeshBasicMaterial;
      fm.opacity = Math.max(0, fm.opacity - dt * 14);

      /* bullets */
      for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i];
        const total = b.from.distanceTo(b.to) || 0.01;
        b.t += (b.speed * dt) / total;
        const p = b.from.clone().lerp(b.to, Math.min(1, b.t));
        b.mesh.position.copy(p);
        (b.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.95 - b.t * 0.8);
        if (b.t >= 1) {
          scene.remove(b.mesh);
          b.mesh.geometry.dispose();
          bullets.splice(i, 1);
        }
      }

      /* grenades */
      for (let i = grenades.length - 1; i >= 0; i--) {
        const g = grenades[i];
        g.vel.y -= GRAVITY * dt;
        g.mesh.position.addScaledVector(g.vel, dt);
        if (g.mesh.position.y < 0.16) {
          g.mesh.position.y = 0.16;
          g.vel.y *= -0.42;
          g.vel.x *= 0.72;
          g.vel.z *= 0.72;
        }
        g.mesh.rotation.x += dt * 8;
        g.fuse -= dt * 1000;
        smoke.spawn(g.mesh.position, 1, { color: new THREE.Color("#7a7290"), speed: 0.6, life: 0.5 });
        if (g.fuse <= 0) {
          explode(g.mesh.position.clone(), 90, 9);
          scene.remove(g.mesh);
          grenades.splice(i, 1);
        }
      }

      if (aimingNade) updateTraj();

      /* actors */
      actors.forEach((a) => {
        const before = a.pos.clone();
        if (a.bot) {
          const to = new THREE.Vector3(me.pos.x - a.pos.x, 0, me.pos.z - a.pos.z);
          const d = to.length() || 1;
          const dir = d > 14 ? 1 : d < 8 ? -1 : 0;
          a.pos.x += (to.x / d) * dir * 3.6 * dt;
          a.pos.z += (to.z / d) * dir * 3.6 * dt;
          a.pos.x = THREE.MathUtils.clamp(a.pos.x, -ARENA + 2, ARENA - 2);
          a.pos.z = THREE.MathUtils.clamp(a.pos.z, -ARENA + 2, ARENA - 2);
          a.ry = Math.atan2(to.x, to.z);
          a.cd -= dt * 1000;
          if (a.cd <= 0 && d < 40 && me.hp > 0 && !menuRef.current) {
            a.cd = 900 + Math.random() * 900;
            if (Math.random() < 0.45) takeDamage(8, a.name);
          }
        } else {
          a.pos.lerp(a.target, Math.min(1, dt * 12));
          if (performance.now() - a.last > 15000) {
            removeActor(a.id);
            return;
          }
        }
        if (a.flash > 0) {
          a.flash -= dt * 1000;
          a.group.scale.setScalar(1 + Math.max(0, a.flash) / 900);
        } else a.group.scale.setScalar(1);
        const moved = a.pos.distanceTo(before) / Math.max(dt, 0.0001);
        a.phase += dt * (2.2 + moved * 1.3);
        const amp = Math.min(0.9, moved * 0.13);
        a.limbs.legL.rotation.x = Math.sin(a.phase) * amp;
        a.limbs.legR.rotation.x = -Math.sin(a.phase) * amp;
        a.limbs.armL.rotation.x = -Math.sin(a.phase) * amp * 0.8;
        a.limbs.armR.rotation.x = Math.sin(a.phase) * amp * 0.8;
        a.group.position.copy(a.pos);
        a.group.rotation.y = a.ry;
      });

      sparks.update(dt);
      smoke.update(dt);

      /* camera + shake */
      const eye = THREE.MathUtils.lerp(me.crouch ? CROUCH_EYE : EYE, me.crouch ? CROUCH_EYE : EYE, 1);
      rig.position.set(me.pos.x, me.pos.y + eye + Math.sin(me.bob * 2) * bobAmp * 0.35, me.pos.z);
      rig.rotation.set(me.pitch, me.yaw, 0, "YXZ");
      me.shake = Math.max(0, me.shake - dt * 3.4);
      const sh = me.shake * me.shake;
      camera.position.set((Math.random() - 0.5) * sh * 0.32, (Math.random() - 0.5) * sh * 0.32, 0);
      camera.rotation.set((Math.random() - 0.5) * sh * 0.06, (Math.random() - 0.5) * sh * 0.06, (Math.random() - 0.5) * sh * 0.1 + me.sliding * 0.00016);

      renderer.render(scene, camera);

      netT += dt;
      if (netT > 0.07) {
        netT = 0;
        net.sendState(netMe());
      }

      if (fpsT > 0.35) {
        setHud((h) => ({
          ...h,
          hp: Math.max(0, Math.round(me.hp)),
          kills: me.kills,
          fps: Math.round(frames / fpsT),
          ammo: me.ammo,
          clip: w.clip,
          reloading: me.reloading > 0,
          rage: me.rage > 0,
          shield: me.shield > 0,
          ads: me.ads > 0.5,
          crouch: me.crouch,
          bounty: me.bounty,
          nades: me.nades,
          state: me.hp <= 0 ? "down" : me.sliding > 0 ? "sliding" : !me.grounded ? "airborne" : me.dashing > 0 ? "dashing" : me.crouch ? "crouching" : speedNow > 7 ? "running" : speedNow > 0.4 ? "walking" : "idle",
        }));
        setCool({ ...cds });
        setBoard(
          [
            { name: myName, kills: me.kills, admin: identity.isAdmin },
            ...Array.from(actors.values()).map((a) => ({ name: a.name, kills: a.kills, admin: a.admin })),
          ].sort((x, y) => y.kills - x.kills),
        );
        frames = 0;
        fpsT = 0;
      }
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      canvas.removeEventListener("wheel", onWheel);
      document.removeEventListener("mousemove", onMouseMove);
      canvas.removeEventListener("click", requestLock);
      canvas.removeEventListener("mousedown", onMouseDown);
      canvas.removeEventListener("contextmenu", onCtx);
      window.removeEventListener("mouseup", onMouseUp);
      canvas.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
      window.removeEventListener("deviceorientation", onOrient);
      document.exitPointerLock?.();
      net.leave();
      renderer.dispose();
      mount.removeChild(renderer.domElement);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [avatar.shirt, avatar.skin, identity.isAdmin, identity.name, map, serverId]);

  /* ---------------- UI helpers ---------------- */
  const api = () => apiRef.current;
  const btnStyle = (id: string): React.CSSProperties => {
    const off = settings.layout[id] ?? { x: 0, y: 0 };
    return {
      transform: `translate(${off.x}px, ${off.y}px) scale(${settings.btnScale / 100})`,
      opacity: settings.btnOpacity / 100,
      touchAction: "none",
    };
  };
  const dragProps = (id: string) =>
    editing
      ? {
          onPointerDown: (e: React.PointerEvent) => {
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            e.stopPropagation();
          },
          onPointerMove: (e: React.PointerEvent) => {
            if (e.buttons === 0 && e.pointerType === "mouse") return;
            const cur = settings.layout[id] ?? { x: 0, y: 0 };
            patch({ layout: { ...settings.layout, [id]: { x: cur.x + e.movementX, y: cur.y + e.movementY } } });
          },
        }
      : {};

  const send = () => {
    const t = chatText.trim();
    if (!t) return;
    const myName = identity.isAdmin ? `[ADMIN OWNER] ${identity.name} ✓` : identity.name;
    if (t.startsWith("/")) {
      const [rawCmd, ...rest] = t.slice(1).split(/\s+/);
      const out = api()?.cmd(rawCmd.toLowerCase(), rest.join(" "));
      setChat((c) => [
        ...c.slice(-40),
        {
          id: crypto.randomUUID(),
          from: "console",
          admin: true,
          system: true,
          at: Date.now(),
          text: out ?? `Unknown command "/${rawCmd}" — try /h /b /bo /f /k`,
        },
      ]);
      gsfx.ui();
      setChatText("");
      setChatOpen(false);
      return;
    }
    const net = netRef.current;
    if (net) {
      const m = net.sendChat({ from: myName, admin: identity.isAdmin, text: t.slice(0, 200) });
      setChat((c) => [...c.slice(-40), m]);
    }
    setChatText("");
    setChatOpen(false);
    sfx.click();
  };

  const skillDefs = SKILLS.filter((s) => s.id === "dash" || ownedSkills.includes(s.id) || identity.isAdmin);
  const hitRecent = Date.now() - hitAt < 220;
  const killRecent = Date.now() - killAt < 900;
  const hurtRecent = Date.now() - dmgFlash < 320;
  const crossSize = hud.ads ? 8 : 18;

  const Slider = ({ label, value, min, max, onChange, suffix = "%" }: { label: string; value: number; min: number; max: number; onChange: (v: number) => void; suffix?: string }) => (
    <label className="block text-left text-[11px] text-white/80">
      <span className="flex justify-between">
        <span>{label}</span>
        <span className="text-primary">{value}{suffix}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full accent-[var(--ashley)]"
      />
    </label>
  );

  const Toggle = ({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) => (
    <button
      onClick={() => { gsfx.ui(); onChange(!on); }}
      className={"flex w-full items-center justify-between rounded-xl px-3 py-2 text-[11px] " + (on ? "bg-primary/25 text-white" : "bg-white/10 text-white/70")}
    >
      <span>{label}</span>
      <span className={"h-4 w-8 rounded-full p-0.5 " + (on ? "bg-primary" : "bg-white/25")}>
        <span className={"block h-3 w-3 rounded-full bg-white transition-transform " + (on ? "translate-x-4" : "")} />
      </span>
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 select-none bg-black">
      <div ref={mountRef} className="absolute inset-0 [&>canvas]:h-full [&>canvas]:w-full" />

      {/* damage vignette */}
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-200"
        style={{
          opacity: hurtRecent ? 1 : 0,
          background: "radial-gradient(ellipse at center, transparent 45%, rgba(255,45,63,0.55) 100%)",
        }}
      />
      {/* rage / shield tint */}
      {hud.rage && <div className="pointer-events-none absolute inset-0 animate-pulse" style={{ background: "radial-gradient(ellipse at center, transparent 55%, rgba(255,45,63,0.35) 100%)" }} />}
      {hud.shield && <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at center, transparent 60%, rgba(73,216,255,0.3) 100%)" }} />}

      {/* crosshair + hitmarker */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="relative" style={{ width: crossSize, height: crossSize, transition: "all 120ms" }}>
          <div className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-white/80" />
          <div className="absolute top-1/2 left-0 h-px w-full -translate-y-1/2 bg-white/80" />
        </div>
        {hitRecent && (
          <div className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 animate-[scale-in_0.12s_ease-out]">
            <div className="absolute inset-0 rotate-45 border-l-2 border-t-2 border-[#ff4fa3]" />
            <div className="absolute inset-0 rotate-45 border-b-2 border-r-2 border-[#ff4fa3]" />
          </div>
        )}
      </div>

      {/* damage popups */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        {pops.map((p) => (
          <span
            key={p.id}
            className={"absolute animate-[fade-out_0.8s_ease-out_forwards] text-sm font-black drop-shadow " + (p.crit ? "text-[#ffd166]" : "text-white")}
            style={{ left: p.x, top: p.y }}
          >
            {p.crit ? "★" : ""}{p.dmg}
          </span>
        ))}
      </div>

      {killRecent && (
        <p className="pointer-events-none absolute left-1/2 top-[22%] -translate-x-1/2 animate-[scale-in_0.2s_ease-out] text-2xl font-black tracking-widest text-[#ff4fa3] drop-shadow">
          ELIMINATED
        </p>
      )}

      {/* HUD */}
      <div className="pointer-events-none absolute left-4 top-4 flex flex-col gap-1">
        <div className="flex flex-wrap items-center gap-3 rounded-2xl bg-black/50 px-3 py-2 text-xs text-white backdrop-blur">
          <span className="font-bold">HP {hud.hp}</span>
          <span>⚔ {hud.kills}</span>
          <span className="text-[#ffd166]">💰 {hud.bounty}</span>
          {rank && <span className="text-primary">#{rank.rank}/{rank.total}</span>}
          <span>{hud.players} online</span>
          <span className="capitalize text-white/60">{hud.state}</span>
          {hud.rage && <span className="font-bold text-[#ff2d3f]">RAGE ×2</span>}
          {hud.shield && <span className="font-bold text-[#49d8ff]">SHIELD</span>}
          <span className="text-white/50">{hud.fps} fps</span>
          {serverLabel && <span className="text-white/50">· {serverLabel}</span>}
        </div>
        <div className="h-1.5 w-56 overflow-hidden rounded-full bg-white/15">
          <div className="h-full rounded-full transition-all duration-200" style={{ width: `${Math.min(100, hud.hp)}%`, background: hud.hp > 40 ? "linear-gradient(90deg,#ff4fa3,#49d8ff)" : "#ff2d3f" }} />
        </div>
      </div>

      {/* ranking */}
      <div className="pointer-events-none absolute right-4 top-4 w-44 rounded-2xl bg-black/50 p-3 text-[11px] text-white backdrop-blur">
        <p className="mb-1 font-bold uppercase tracking-widest text-white/60">Ranking</p>
        {board.slice(0, 8).map((r, i) => (
          <p key={r.name + i} className="flex justify-between gap-2 truncate">
            <span className="truncate">
              {r.admin && <span className="font-bold text-[#ff2d3f]">[ADMIN] </span>}
              {r.name.replace("[ADMIN OWNER] ", "")}
            </span>
            <span className="text-primary">{r.kills}</span>
          </p>
        ))}
      </div>

      {/* chat */}
      <div className="absolute bottom-40 left-4 w-[min(22rem,55vw)] text-[11px] text-white sm:bottom-28">
        <div className="max-h-40 space-y-0.5 overflow-hidden">
          {chat.slice(-6).map((m) => (
            <p key={m.id} className="animate-fade-in rounded bg-black/40 px-2 py-0.5 backdrop-blur">
              {m.system ? (
                <span className={m.admin ? "font-bold text-[#ff2d3f]" : "text-primary"}>{m.text}</span>
              ) : (
                <>
                  <span className={m.admin ? "font-bold text-[#ff2d3f]" : "text-primary"}>{m.from}</span>: {m.text}
                </>
              )}
            </p>
          ))}
        </div>
        {chatOpen ? (
          <div className="mt-1 flex gap-1">
            <input
              autoFocus
              value={chatText}
              onChange={(e) => setChatText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
                if (e.key === "Escape") setChatOpen(false);
              }}
              placeholder="Message or /h 100 · /b 30 · /f kawaii · /k 5 · /bo 500"
              className="flex-1 rounded-full bg-black/60 px-3 py-1.5 text-xs text-white outline-none ring-1 ring-white/20"
            />
            <button onClick={send} className="ashley-gradient rounded-full px-3 py-1.5 text-xs font-semibold text-primary-foreground">
              Send
            </button>
          </div>
        ) : (
          <button onClick={() => setChatOpen(true)} className="mt-1 rounded-full bg-black/50 px-3 py-1 text-[11px] backdrop-blur">
            💬 Chat / commands (Enter)
          </button>
        )}
      </div>

      {/* weapon wheel (right edge) */}
      <div className="absolute right-3 top-1/3 flex flex-col gap-1.5" style={btnStyle("weapons")} {...dragProps("weapons")}>
        {slots.map((w, i) => (
          <button
            key={w.id}
            onClick={() => api()?.slot(i)}
            className={
              "w-20 rounded-xl border px-1.5 py-1 text-center text-[10px] text-white backdrop-blur transition-all " +
              (slot === i ? "scale-105 border-primary bg-primary/30 shadow-[0_0_18px_rgba(255,79,163,0.5)]" : "border-white/20 bg-black/50")
            }
          >
            <span className="block text-[9px] text-white/50">{w.kind === "gun" ? "🔫" : w.kind === "melee" ? "⚔️" : "💣"} {i + 1}</span>
            <span className="block truncate font-semibold">
              {w.id === "fists" ? FIGHT_STYLES.find((s) => s.id === styleIdLive)?.name ?? "Fists" : w.name}
            </span>
          </button>
        ))}
      </div>

      {/* ammo */}
      <div className="pointer-events-none absolute bottom-4 left-1/2 -translate-x-1/2 rounded-2xl bg-black/55 px-4 py-1.5 text-center text-white backdrop-blur">
        {hud.clip > 0 ? (
          <span className={"text-lg font-black " + (hud.reloading ? "animate-pulse text-white/60" : hud.ammo === 0 ? "text-[#ff2d3f]" : "")}>
            {hud.reloading ? "RELOADING" : `${hud.ammo} / ${hud.clip}`}
          </span>
        ) : (
          <span className="text-sm font-bold text-white/70">MELEE {hud.combo > 0 ? `· COMBO ×${hud.combo + 1}` : ""}</span>
        )}
        <span className="ml-3 text-xs text-white/60">💣 {hud.nades}</span>
      </div>

      {/* skills row */}
      <div className="absolute bottom-[13.5rem] right-6 flex gap-2" style={btnStyle("skills")} {...dragProps("skills")}>
        {skillDefs.map((s) => {
          const c = cool[s.id as SkillId] ?? 0;
          const ready = c <= 0;
          const icon = { dash: "⚡", heal: "❤️", shock: "💥", rage: "🔥", shield: "🛡️", smoke: "💨" }[s.id as SkillId] ?? "✨";
          return (
            <button
              key={s.id}
              onPointerDown={() => api()?.skill(s.id as SkillId)}
              className={
                "relative h-14 w-14 rounded-full border text-[10px] font-bold text-white backdrop-blur transition-all active:scale-90 " +
                (ready ? "border-primary bg-primary/25 shadow-[0_0_16px_rgba(255,79,163,0.45)]" : "border-white/15 bg-black/60 opacity-60")
              }
            >
              <span className="block text-lg leading-none">{icon}</span>
              <span className="block text-[9px] font-normal text-white/70">{ready ? "READY" : `${Math.ceil(c / 1000)}s`}</span>
            </button>
          );
        })}
      </div>

      {/* right combat cluster */}
      <div className="absolute bottom-6 right-6 h-52 w-52" style={btnStyle("combat")} {...dragProps("combat")}>
        {/* AIM */}
        <button
          onPointerDown={() => { const t = api()?.touch; if (t) { t.ads = true; gsfx.ads(true); } }}
          onPointerUp={() => { const t = api()?.touch; if (t) { t.ads = false; gsfx.ads(false); } }}
          onPointerLeave={() => { const t = api()?.touch; if (t) t.ads = false; }}
          className={"absolute left-1/2 top-0 h-14 w-14 -translate-x-1/2 rounded-full border text-[10px] font-bold text-white backdrop-blur active:scale-90 " + (hud.ads ? "border-primary bg-primary/40" : "border-white/25 bg-black/50")}
        >
          🎯<span className="block">AIM</span>
        </button>
        {/* MELEE */}
        <button
          onPointerDown={() => api()?.melee()}
          className="absolute left-0 top-16 h-16 w-16 rounded-full border border-white/25 bg-black/55 text-[10px] font-bold text-white backdrop-blur active:scale-90"
        >
          🔪<span className="block">MELEE</span>
        </button>
        {/* FIRE */}
        <button
          onPointerDown={() => { const t = api()?.touch; if (t) t.firing = true; buzz(10); }}
          onPointerUp={() => { const t = api()?.touch; if (t) t.firing = false; }}
          onPointerLeave={() => { const t = api()?.touch; if (t) t.firing = false; }}
          className="absolute right-0 top-14 h-20 w-20 rounded-full border-2 border-[#ff2d3f]/60 bg-[#ff2d3f]/60 text-xs font-black text-white shadow-[0_0_28px_rgba(255,45,63,0.6)] backdrop-blur active:scale-90"
        >
          🔫<span className="block">FIRE</span>
        </button>
        {/* BOMB */}
        <button
          onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); setNadeAim(true); api()?.nadeStart(); }}
          onPointerMove={(e) => { if (nadeAim) api()?.nadeAim(e.movementX, e.movementY); }}
          onPointerUp={() => { if (nadeAim) { setNadeAim(false); api()?.nadeThrow(); } }}
          className={"absolute bottom-2 left-1/2 h-14 w-14 -translate-x-1/2 rounded-full border text-[10px] font-bold text-white backdrop-blur active:scale-90 " + (nadeAim ? "border-[#ffd166] bg-[#ffd166]/30" : "border-white/25 bg-black/55")}
          style={{ touchAction: "none" }}
        >
          💣<span className="block">{hud.nades}</span>
        </button>
      </div>

      {/* movement cluster */}
      <div className="absolute bottom-8 right-[15.5rem] flex flex-col gap-2" style={btnStyle("move")} {...dragProps("move")}>
        <button
          onPointerDown={() => { const t = api()?.touch; if (t) t.run = !t.run; gsfx.ui(); }}
          className="h-12 w-12 rounded-full bg-white/15 text-[10px] font-bold text-white backdrop-blur active:scale-90"
        >
          🏃
        </button>
        <button
          onPointerDown={() => { const t = api()?.touch; if (t) t.crouch = !t.crouch; gsfx.crouch(); }}
          className={"h-12 w-12 rounded-full text-[10px] font-bold text-white backdrop-blur active:scale-90 " + (hud.crouch ? "bg-primary/40" : "bg-white/15")}
        >
          🧎
        </button>
        <button onPointerDown={() => api()?.slide()} className="h-12 w-12 rounded-full bg-white/15 text-[10px] font-bold text-white backdrop-blur active:scale-90">
          🛝
        </button>
        <button onPointerDown={() => api()?.jump()} className="h-14 w-14 rounded-full bg-white/20 text-[10px] font-bold text-white backdrop-blur active:scale-90">
          ⬆<span className="block">JUMP</span>
        </button>
        <button onPointerDown={() => api()?.reload()} className="h-12 w-12 rounded-full bg-white/15 text-[10px] font-bold text-white backdrop-blur active:scale-90">
          🔄
        </button>
      </div>

      {/* joystick */}
      <div
        className="absolute bottom-8 left-6 h-32 w-32 rounded-full border border-white/20 bg-white/10 backdrop-blur"
        style={btnStyle("joystick")}
        {...dragProps("joystick")}
        onPointerDown={(e) => (e.target as HTMLElement).setPointerCapture(e.pointerId)}
        onPointerMove={(e) => {
          if (editing) return;
          const r = e.currentTarget.getBoundingClientRect();
          const t = api()?.touch;
          if (!t) return;
          const nx = THREE.MathUtils.clamp(((e.clientX - r.left) / r.width - 0.5) * 2, -1, 1);
          const nz = THREE.MathUtils.clamp(((e.clientY - r.top) / r.height - 0.5) * 2, -1, 1);
          t.mx = nx;
          t.mz = nz;
          const knob = e.currentTarget.firstElementChild as HTMLElement | null;
          if (knob) knob.style.transform = `translate(calc(-50% + ${nx * 34}px), calc(-50% + ${nz * 34}px))`;
        }}
        onPointerUp={(e) => {
          const t = api()?.touch;
          if (t) { t.mx = 0; t.mz = 0; }
          const knob = e.currentTarget.firstElementChild as HTMLElement | null;
          if (knob) knob.style.transform = "translate(-50%, -50%)";
        }}
        onPointerLeave={(e) => {
          const t = api()?.touch;
          if (t) { t.mx = 0; t.mz = 0; }
          const knob = e.currentTarget.firstElementChild as HTMLElement | null;
          if (knob) knob.style.transform = "translate(-50%, -50%)";
        }}
      >
        <div className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/30 shadow-[0_0_18px_rgba(255,255,255,0.25)] transition-transform duration-75" />
      </div>

      {/* eliminated */}
      {hud.hp <= 0 && !menu && (
        <div className="absolute inset-0 flex animate-fade-in flex-col items-center justify-center gap-3 bg-black/70 text-white">
          <p className="text-2xl font-bold">You were taken down</p>
          <button
            onClick={() => { gsfx.heal(); api()?.respawn(); }}
            className="ashley-gradient rounded-full px-6 py-2 text-sm font-semibold text-primary-foreground"
          >
            Respawn
          </button>
        </div>
      )}

      {/* menu button */}
      <button
        onClick={() => { sfx.click(); document.exitPointerLock?.(); setMenu(true); }}
        aria-label="AshleyBlox menu"
        className="absolute right-4 top-1/2 -translate-y-1/2 rounded-2xl bg-black/50 p-2 backdrop-blur"
      >
        <img src={logo.url} alt="AshleyBlox" className="h-9 w-9 rounded-xl" />
      </button>

      {menu && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-4">
          <div className="glass max-h-[92vh] w-full max-w-sm overflow-y-auto rounded-3xl p-5 text-center">
            <img src={logo.url} alt="" className="mx-auto h-11 w-11 rounded-xl" />
            <p className="mt-2 text-sm font-semibold">AshleyBlox · Settings</p>

            <div className="mt-3 flex gap-1 rounded-full bg-white/10 p-1 text-[11px]">
              {(["main", "controls", "layout"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => { gsfx.ui(); setTab(t); }}
                  className={"flex-1 rounded-full px-2 py-1 capitalize " + (tab === t ? "ashley-gradient font-semibold text-primary-foreground" : "text-white/70")}
                >
                  {t}
                </button>
              ))}
            </div>

            {tab === "main" && (
              <div className="mt-4 flex flex-col gap-2">
                <p className="text-[11px] text-muted-foreground">
                  WASD move · Ctrl run · Shift dash · Space jump · C crouch · X slide · V melee · G grenade · R reload · RMB aim · 1-2 weapons · 3-6 skills
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Commands: <span className="text-primary">/h 100</span> health · <span className="text-primary">/b 30</span> bullets ·{" "}
                  <span className="text-primary">/f kawaii</span> style · <span className="text-primary">/k 5</span> kills ·{" "}
                  <span className="text-primary">/bo 500</span> bounty
                </p>
                <Slider label="Camera sensitivity" value={settings.camSens} min={1} max={1000} onChange={(v) => patch({ camSens: v })} />
                <Slider label="Aim (ADS) sensitivity" value={settings.aimSens} min={1} max={1000} onChange={(v) => patch({ aimSens: v })} />
                <Slider label="Camera smoothing" value={settings.smoothing} min={0} max={100} onChange={(v) => patch({ smoothing: v })} />
                <Slider label="SFX volume" value={settings.volume} min={0} max={100} onChange={(v) => patch({ volume: v })} />
                <button onClick={() => { sfx.click(); setMenu(false); }} className="ashley-gradient mt-1 rounded-full px-4 py-2 text-sm font-semibold text-primary-foreground">
                  Resume
                </button>
                <button onClick={() => { gsfx.hurt(); api()?.respawn(); setMenu(false); }} className="glass rounded-full px-4 py-2 text-sm">
                  Respawn
                </button>
                <button onClick={() => { sfx.click(); onLeave(); }} className="rounded-full border border-destructive/50 px-4 py-2 text-sm text-destructive">
                  Leave game
                </button>
              </div>
            )}

            {tab === "controls" && (
              <div className="mt-4 flex flex-col gap-2">
                <Slider label="Joystick sensitivity" value={settings.joySens} min={1} max={1000} onChange={(v) => patch({ joySens: v })} />
                <Slider label="Camera shake" value={settings.shake} min={0} max={200} onChange={(v) => patch({ shake: v })} />
                <Toggle label="Gyroscope aim" on={settings.gyro} onChange={(v) => patch({ gyro: v })} />
                <Toggle label="Auto-fire" on={settings.autoFire} onChange={(v) => patch({ autoFire: v })} />
                <Toggle label="Auto-sprint" on={settings.autoSprint} onChange={(v) => patch({ autoSprint: v })} />
                <Toggle label="Haptics (vibration)" on={settings.haptics} onChange={(v) => patch({ haptics: v })} />
              </div>
            )}

            {tab === "layout" && (
              <div className="mt-4 flex flex-col gap-2">
                <Slider label="Button size" value={settings.btnScale} min={60} max={160} onChange={(v) => patch({ btnScale: v })} />
                <Slider label="Button opacity" value={settings.btnOpacity} min={20} max={100} onChange={(v) => patch({ btnOpacity: v })} />
                <Toggle label="Edit layout (drag buttons)" on={editing} onChange={setEditing} />
                <p className="text-[11px] text-muted-foreground">Close this menu with Edit layout on, then drag the joystick, combat, skills, movement or weapon cluster anywhere.</p>
                <button onClick={() => { gsfx.ui(); patch({ layout: {} }); }} className="glass rounded-full px-4 py-2 text-sm">
                  Reset positions
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {editing && !menu && (
        <div className="pointer-events-none absolute left-1/2 top-16 -translate-x-1/2 rounded-full bg-[#ffd166]/90 px-4 py-1 text-[11px] font-bold text-black">
          LAYOUT EDIT — drag the controls
        </div>
      )}

      {portrait && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-background/95 px-8 text-center">
          <img src={logo.url} alt="" className="h-14 w-14 rounded-2xl" />
          <p className="text-sm font-semibold">Rotate your device</p>
          <p className="text-xs text-muted-foreground">Ro-shooter runs in landscape only.</p>
        </div>
      )}
    </div>
  );
}
