import { useEffect, useRef, useState, type ReactNode } from "react";
import logoAsset from "@/assets/ashley-logo.png.asset.json";

const BOOT_MS = 60_000; // ~1 minute boot sequence
const SESSION_KEY = "ashley_booted_v1";

const STAGES = [
  "Waking AshleyAI core…",
  "Loading TokemekiAi neural modules…",
  "Calibrating kawaii voice engine…",
  "Linking image & video synthesis…",
  "Syncing search + music index…",
  "Warming credits & wallet vault…",
  "Finalizing secure handshake…",
  "AshleyAI is ready 💗",
];

export function BootScreen({ children }: { children: ReactNode }) {
  const [booting, setBooting] = useState(true);
  const [progress, setProgress] = useState(0);
  const start = useRef(0);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(SESSION_KEY)) {
      setBooting(false);
      return;
    }
    start.current = performance.now();
    let raf = 0;
    const tick = () => {
      const p = Math.min(1, (performance.now() - start.current) / BOOT_MS);
      setProgress(p);
      if (p >= 1) {
        sessionStorage.setItem(SESSION_KEY, "1");
        setBooting(false);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  if (!booting) return <>{children}</>;

  const pct = Math.round(progress * 100);
  const stage = STAGES[Math.min(STAGES.length - 1, Math.floor(progress * STAGES.length))];

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-background px-6">
      <div className="pointer-events-none absolute inset-0 opacity-70 [background:radial-gradient(60%_50%_at_50%_30%,hsl(var(--primary)/0.25),transparent_70%),radial-gradient(50%_40%_at_20%_80%,hsl(var(--accent)/0.2),transparent_70%)]" />

      <div className="relative flex flex-col items-center gap-8">
        <div className="relative">
          <div className="absolute -inset-8 animate-[spin_9s_linear_infinite] rounded-full border border-primary/30 border-t-primary/80" />
          <div className="absolute -inset-14 animate-[spin_16s_linear_infinite_reverse] rounded-full border border-accent/20 border-b-accent/70" />
          <img
            src={logoAsset.url}
            alt="AshleyAI logo"
            className="h-28 w-28 animate-pulse rounded-3xl shadow-[0_0_60px_hsl(var(--primary)/0.55)]"
          />
        </div>

        <div className="text-center">
          <h1 className="font-[Space_Grotesk] text-2xl font-bold tracking-[0.3em] text-foreground">
            ASHLEYAI
          </h1>
          <p className="mt-1 text-xs tracking-[0.25em] text-muted-foreground">
            TOKEMEKIAI · v.6.0.12.5
          </p>
        </div>

        <div className="w-[min(88vw,420px)]">
          <div className="h-2 overflow-hidden rounded-full bg-muted/40 ring-1 ring-primary/20">
            <div
              className="h-full rounded-full bg-gradient-to-r from-primary via-accent to-primary transition-[width] duration-200"
              style={{ width: `${pct}%` }}
            />
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
            <span className="animate-pulse">{stage}</span>
            <span className="tabular-nums text-primary">{pct}%</span>
          </div>
        </div>

        <button
          onClick={() => {
            sessionStorage.setItem(SESSION_KEY, "1");
            setBooting(false);
          }}
          className="rounded-full border border-border/60 px-4 py-1.5 text-[11px] text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
        >
          Skip intro
        </button>
      </div>
    </div>
  );
}
