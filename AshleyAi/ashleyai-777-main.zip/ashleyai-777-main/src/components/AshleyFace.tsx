import { useEffect, useState } from "react";
import { subscribeFace, type Emotion } from "@/lib/ashley-voice";

/**
 * Ashley's animated talking face — two eyes, one mouth with a tongue,
 * cat ears and human-like emotions. Lip-syncs to her voice.
 */
export function AshleyFace({ className = "h-24 w-24" }: { className?: string }) {
  const [{ speaking, emotion, level }, setState] = useState({
    speaking: false,
    emotion: "neutral" as Emotion,
    level: 0,
  });
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const off = subscribeFace((s) => setState(s));
    return () => {
      off();
    };
  }, []);

  useEffect(() => {
    let t: number;
    const loop = () => {
      setBlink(true);
      window.setTimeout(() => setBlink(false), 130);
      t = window.setTimeout(loop, 2200 + Math.random() * 3000);
    };
    t = window.setTimeout(loop, 1500);
    return () => window.clearTimeout(t);
  }, []);

  const open = speaking ? 3 + level * 17 : 3;
  const wide = speaking ? 20 + level * 8 : 20;

  // Emotion drives eye shape, brows and blush.
  const e = emotion;
  const squint = e === "happy" || e === "shy" || e === "annoyed" || e === "jealous" || e === "tsundere";
  const eyeRy = blink
    ? 1
    : squint
      ? 6
      : e === "surprised" || e === "scared"
        ? 11
        : e === "nonchalant"
          ? 5
          : 8.5;
  const eyeRx = e === "surprised" || e === "scared" ? 8.5 : 7;
  const browY =
    e === "angry" || e === "annoyed" || e === "jealous" || e === "tsundere"
      ? 4
      : e === "sad" || e === "cry" || e === "scared" || e === "awkward"
        ? -2
        : e === "surprised"
          ? -4
          : 0;
  const browTilt =
    e === "angry" || e === "annoyed" || e === "jealous" || e === "tsundere"
      ? 14
      : e === "sad" || e === "cry" || e === "scared" || e === "awkward"
        ? -12
        : 0;
  const blush =
    e === "shy" || e === "happy" || e === "excited" || e === "tsundere" || e === "awkward" || e === "jealous";
  const tears = e === "cry" || e === "sad";
  const sweat = e === "awkward" || e === "scared";
  const anger = e === "angry" || e === "annoyed" || e === "jealous" || e === "tsundere";
  const mouthCurve =
    e === "sad" || e === "angry" || e === "cry" || e === "annoyed" || e === "tsundere" || e === "jealous"
      ? -6
      : e === "nonchalant"
        ? 0
        : 6;

  return (
    <div className={"ashley-face " + className} data-emotion={e} data-speaking={speaking}>
      <svg viewBox="0 0 120 120" className="h-full w-full">
        <defs>
          <radialGradient id="af-skin" cx="50%" cy="40%">
            <stop offset="0%" stopColor="var(--ashley, #ff8ad4)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#12002a" stopOpacity="0.9" />
          </radialGradient>
          <linearGradient id="af-ear" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ff9ee0" />
            <stop offset="100%" stopColor="#7a5bff" />
          </linearGradient>
        </defs>

        {/* cat ears */}
        <g className="af-ears" fill="url(#af-ear)">
          <path d="M24 34 L30 6 L52 26 Z" />
          <path d="M96 34 L90 6 L68 26 Z" />
          <path d="M31 30 L34 15 L46 27 Z" fill="#ffd0ef" opacity=".8" />
          <path d="M89 30 L86 15 L74 27 Z" fill="#ffd0ef" opacity=".8" />
        </g>

        {/* head */}
        <circle cx="60" cy="66" r="42" fill="url(#af-skin)" stroke="var(--ashley, #ff8ad4)" strokeWidth="1.5" />

        {/* brows */}
        <g stroke="#ffc4ec" strokeWidth="3" strokeLinecap="round" className="af-brows">
          <line x1="32" y1={48 + browY} x2="48" y2={48 + browY - browTilt / 2} transform={`rotate(${-browTilt} 40 48)`} />
          <line x1="72" y1={48 + browY - browTilt / 2} x2="88" y2={48 + browY} transform={`rotate(${browTilt} 80 48)`} />
        </g>

        {/* eyes */}
        <g className="af-eyes">
          <ellipse cx="42" cy="62" rx={eyeRx} ry={eyeRy} fill="#0a0018" stroke="#8ef0ff" strokeWidth="1.5" />
          <ellipse cx="78" cy="62" rx={eyeRx} ry={eyeRy} fill="#0a0018" stroke="#8ef0ff" strokeWidth="1.5" />
          {!blink && (
            <>
              <circle cx="42" cy="62" r="3.4" fill="#7de8ff" className="af-pupil" />
              <circle cx="78" cy="62" r="3.4" fill="#7de8ff" className="af-pupil" />
              <circle cx="44" cy="59" r="1.4" fill="#fff" />
              <circle cx="80" cy="59" r="1.4" fill="#fff" />
            </>
          )}
        </g>

        {/* blush */}
        {blush && (
          <g opacity=".55" fill="#ff6fb5">
            <ellipse cx="32" cy="76" rx="8" ry="4" />
            <ellipse cx="88" cy="76" rx="8" ry="4" />
          </g>
        )}

        {/* tears */}
        {tears && (
          <g className="af-tears" fill="#8ef0ff" opacity=".9">
            <ellipse cx="42" cy="72" rx="2.4" ry="4" />
            <ellipse cx="78" cy="72" rx="2.4" ry="4" />
          </g>
        )}

        {/* sweat drop */}
        {sweat && (
          <ellipse className="af-sweat" cx="96" cy="48" rx="3" ry="5" fill="#9fe8ff" opacity=".85" />
        )}

        {/* anger mark */}
        {anger && (
          <g className="af-anger" stroke="#ff4d6d" strokeWidth="2.4" strokeLinecap="round" fill="none">
            <path d="M92 34 L100 42 M100 34 L92 42" />
          </g>
        )}

        {/* mouth + tongue */}
        <g className="af-mouth">
          <ellipse cx="60" cy="88" rx={wide / 2} ry={open / 2} fill="#2a0016" stroke="#ff8ad4" strokeWidth="1.5" />
          {open > 8 && (
            <ellipse cx="60" cy={88 + open / 5} rx={wide / 3.4} ry={open / 4} fill="#ff6f9e" className="af-tongue" />
          )}
          {open <= 8 && (
            <path
              d={`M${60 - wide / 2} 88 Q60 ${88 + mouthCurve} ${60 + wide / 2} 88`}
              fill="none"
              stroke="#ff8ad4"
              strokeWidth="2"
              strokeLinecap="round"
            />
          )}
        </g>
      </svg>
    </div>
  );
}
