import { useState } from "react";
import { Coins, X, Wallet, Copy, Check, Plus } from "lucide-react";
import logoAsset from "@/assets/ashley-logo-v2.png.asset.json";
import { CREDIT_PACKS, PAY_METHODS, WALLETS, useCredits, type PackId } from "@/lib/credits";
import { sfx } from "@/lib/sound";

export function AshleyAvatar({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <img
      src={logoAsset.url}
      alt="AshleyAI logo"
      className={"rounded-2xl bg-black/40 object-cover ring-1 ring-primary/40 " + className}
    />
  );
}

export function CreditsBar() {
  const { credits, add } = useCredits();
  const [open, setOpen] = useState<null | "store" | "wallet">(null);

  return (
    <>
      <button
        onClick={() => { sfx.click(); setOpen("store"); }}
        onMouseEnter={() => sfx.hover()}
        className="ashley-badge inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-foreground"
      >
        <Coins className="h-3.5 w-3.5" />
        {credits.toLocaleString()}
        <Plus className="h-3 w-3 opacity-70" />
      </button>
      <button
        onClick={() => { sfx.click(); setOpen("wallet"); }}
        onMouseEnter={() => sfx.hover()}
        aria-label="Crypto wallet"
        className="glass flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
      >
        <Wallet className="h-4 w-4" />
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-4 backdrop-blur sm:items-center"
          onClick={() => setOpen(null)}
        >
          <div
            className="glass max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-3xl p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center gap-3">
              <AshleyAvatar className="h-12 w-12" />
              <div className="flex-1">
                <h2 className="text-base font-bold">
                  {open === "store" ? "Add Credits" : "AshleyAI Wallet"}
                </h2>
                <p className="text-[11px] text-muted-foreground">
                  Balance: {credits.toLocaleString()} credits
                </p>
              </div>
              <button onClick={() => { sfx.click(); setOpen(null); }} className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>

            {open === "store" ? <Store onBuy={(p) => add(p)} /> : <WalletList />}
          </div>
        </div>
      )}
    </>
  );
}

function Store({ onBuy }: { onBuy: (credits: number) => void }) {
  const [pack, setPack] = useState<PackId>("plus");
  const [method, setMethod] = useState(PAY_METHODS[0].id);
  const [done, setDone] = useState(false);
  const selected = CREDIT_PACKS.find((p) => p.id === pack)!;
  const pay = PAY_METHODS.find((m) => m.id === method)!;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        {CREDIT_PACKS.map((p) => (
          <button
            key={p.id}
            onClick={() => { sfx.click(); setPack(p.id); setDone(false); }}
            className={
              "rounded-2xl border p-3 text-left transition " +
              (pack === p.id ? "border-primary bg-primary/10" : "border-border hover:bg-secondary")
            }
          >
            <div className="text-sm font-semibold">{p.label}</div>
            <div className="ashley-text text-lg font-bold">{p.credits.toLocaleString()}</div>
            <div className="text-[11px] text-muted-foreground">
              ₱{p.php} · ${p.usd} · {p.btc} BTC
            </div>
          </button>
        ))}
      </div>

      <div>
        <p className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Payment method</p>
        <div className="flex flex-wrap gap-2">
          {PAY_METHODS.map((m) => (
            <button
              key={m.id}
              onClick={() => { sfx.click(); setMethod(m.id); setDone(false); }}
              className={
                "rounded-full border px-3 py-1.5 text-xs transition " +
                (method === m.id ? "border-primary bg-primary/15 text-foreground" : "border-border text-muted-foreground hover:text-foreground")
              }
            >
              {m.name}
            </button>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2 rounded-xl border border-border bg-input px-3 py-2 text-xs">
          <span className="truncate font-mono">{pay.detail}</span>
          <CopyBtn value={pay.detail} />
        </div>
      </div>

      <button
        onClick={() => { sfx.success(); onBuy(selected.credits); setDone(true); }}
        className="ashley-gradient w-full rounded-2xl py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30"
      >
        Pay with {pay.name} · +{selected.credits.toLocaleString()} credits
      </button>
      {done && (
        <p className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-center text-xs text-emerald-300">
          {selected.credits.toLocaleString()} credits added ✓
        </p>
      )}
      <p className="text-center text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        Demo checkout · credits stored on this device
      </p>
    </div>
  );
}

function WalletList() {
  return (
    <div className="space-y-2">
      {WALLETS.map((w) => (
        <div key={w.symbol} className="rounded-2xl border border-border p-3">
          <div className="mb-1 flex items-center justify-between">
            <span className="text-sm font-semibold">
              {w.coin} <span className="text-muted-foreground">({w.symbol})</span>
            </span>
            <CopyBtn value={w.address} />
          </div>
          <p className="break-all font-mono text-[11px] text-muted-foreground">{w.address}</p>
        </div>
      ))}
      <p className="text-center text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        Send crypto to top up · demo addresses
      </p>
    </div>
  );
}

function CopyBtn({ value }: { value: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      onClick={() => {
        sfx.click();
        navigator.clipboard?.writeText(value);
        setOk(true);
        setTimeout(() => setOk(false), 1200);
      }}
      className="shrink-0 text-muted-foreground hover:text-foreground"
      aria-label="Copy"
    >
      {ok ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
    </button>
  );
}
