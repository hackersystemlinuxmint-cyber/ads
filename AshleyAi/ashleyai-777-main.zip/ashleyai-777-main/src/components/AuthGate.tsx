import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import bgAsset from "@/assets/ashley-login-bg.png.asset.json";
import { sfx } from "@/lib/sound";
import { ProfileChip, ProfileSetup } from "@/components/ProfileSetup";
import { loadProfile, saveProfile, type AshleyProfile } from "@/lib/profile";
import { accountLogin, accountRedeem, accountSignup } from "@/lib/accounts";

type User = { email: string; token?: string } | null;

export const ADMIN_EMAIL = "tokemekiai.company@gmail.com";
export const isAdminEmail = (e: string) => e.trim().toLowerCase() === ADMIN_EMAIL;

type Mode = "login" | "signup" | "recover";

const STORAGE_USERS = "ashley.demo.users";
const STORAGE_SESSION = "ashley.demo.session";

type StoredUser = { email: string; password: string };

function loadUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_USERS) || "[]");
  } catch {
    return [];
  }
}
function saveUsers(users: StoredUser[]) {
  localStorage.setItem(STORAGE_USERS, JSON.stringify(users));
}

export function AuthGate({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null);
  const [profile, setProfile] = useState<AshleyProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const s = localStorage.getItem(STORAGE_SESSION);
      if (s) setUser(JSON.parse(s));
    } catch {
      /* ignore */
    }
    setProfile(loadProfile());
    setLoading(false);
  }, []);

  // Main admin account: one live session only — newest login wins.
  useEffect(() => {
    if (!user || !isAdminEmail(user.email) || !user.token) return;
    const check = async () => {
      try {
        const res = await fetch("/api/admin-session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: user.email, token: user.token, action: "check" }),
        });
        const json = (await res.json()) as { valid?: boolean };
        if (json.valid === false) {
          localStorage.removeItem(STORAGE_SESSION);
          setUser(null);
        }
      } catch {
        /* offline — keep the session */
      }
    };
    void check();
    const id = window.setInterval(check, 20000);
    return () => window.clearInterval(id);
  }, [user]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  if (!user) return <JarvisLogin onAuthed={setUser} />;
  if (!profile) return <ProfileSetup onDone={setProfile} />;

  return (
    <div>
      <ProfileChip
        profile={profile}
        admin={isAdminEmail(user.email)}
        onLogout={() => {
          localStorage.removeItem(STORAGE_SESSION);
          saveProfile(null);
          setProfile(null);
          setUser(null);
        }}
      />
      {children}
    </div>
  );
}


async function claimSession(email: string): Promise<NonNullable<User>> {
  const token = crypto.randomUUID();
  if (isAdminEmail(email)) {
    try {
      await fetch("/api/admin-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, token }),
      });
    } catch {
      /* offline — allow local session */
    }
  }
  return { email, token };
}

function JarvisLogin({ onAuthed }: { onAuthed: (u: NonNullable<User>) => void }) {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const finish = async (e: string) => {
    const session = await claimSession(e);
    localStorage.setItem(STORAGE_SESSION, JSON.stringify(session));
    onAuthed(session);
  };

  const submit = async () => {
    setErr(null);
    setInfo(null);
    const e = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
      setErr("Please enter a valid email.");
      return;
    }
    if (password.length < 4) {
      setErr("Password must be at least 4 characters.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "recover") {
        if (code.replace(/\D/g, "").length < 4) {
          setErr("Enter the recovery code the admin gave you.");
          return;
        }
        const r = await accountRedeem(e, code, password);
        if (r.error) {
          setErr(r.error);
          return;
        }
        setInfo("New password saved ✓");
        setTimeout(() => void finish(e), 300);
        return;
      }

      const users = loadUsers();
      if (mode === "signup") {
        const r = await accountSignup(e, password);
        if (r.error) {
          setErr(r.error);
          return;
        }
        if (!users.some((u) => u.email === e)) {
          users.push({ email: e, password });
          saveUsers(users);
        }
        setInfo("Account created ✓");
        setTimeout(() => void finish(e), 200);
      } else {
        const r = await accountLogin(e, password);
        if (r.error) {
          setErr(r.error);
          return;
        }
        await finish(e);
      }
    } catch {
      setErr("Could not reach the account server. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="jarvis-root relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-10"
      style={{ backgroundImage: `url(${bgAsset.url})` }}
    >
      <div className="jarvis-veil" />
      <div className="jarvis-scanlines" />
      <div className="jarvis-sweep" />
      <div className="jarvis-panel jarvis-in relative z-10 w-full max-w-md rounded-[28px] p-7">
        <div className="mb-6 text-center">
          <div className="jarvis-ring mx-auto mb-4 flex h-24 w-24 items-center justify-center">
            <div className="jarvis-core flex h-16 w-16 items-center justify-center rounded-full px-1 text-center text-[8px] font-bold leading-[1.1] tracking-[0.12em]">
              TOKEMEKIAI
            </div>
          </div>
          <h1 className="font-display text-2xl font-bold uppercase tracking-[0.35em] text-[color:var(--jarvis)]">
            AshleyAI
          </h1>
          <p className="mt-1 text-[10px] uppercase tracking-[0.4em] text-[color:var(--jarvis-dim)]">
            Secure Access · TokemekiAi
          </p>
          <p className="mt-1 font-mono text-[10px] tracking-widest text-[color:var(--jarvis-dim)]">v9.4.5.2</p>
        </div>

        <div className="mb-5 flex rounded-full border border-[color:var(--jarvis-line)] p-1 text-xs">
          <TabPill active={mode === "login"} onClick={() => { sfx.click(); setMode("login"); }}>Log in</TabPill>
          <TabPill active={mode === "signup"} onClick={() => { sfx.click(); setMode("signup"); }}>Sign up</TabPill>
          <TabPill active={mode === "recover"} onClick={() => { sfx.click(); setMode("recover"); }}>Recover</TabPill>
        </div>

        <JarvisField label="Email" value={email} onChange={setEmail} placeholder="you@example.com" type="email" />
        {mode === "recover" && (
          <JarvisField label="Recovery code" value={code} onChange={setCode} placeholder="00000" type="text" />
        )}
        <JarvisField
          label={mode === "recover" ? "New password" : "Password"}
          value={password}
          onChange={setPassword}
          placeholder="••••••••"
          type="password"
        />

        {err && (
          <div className="mt-3 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs text-red-200">
            {err}
          </div>
        )}
        {info && (
          <div className="mt-3 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200">
            {info}
          </div>
        )}

        <button
          onClick={() => { if (!busy) sfx.click(); submit(); }}
          disabled={busy}
          className="jarvis-btn mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold uppercase tracking-[0.25em] disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {mode === "login" ? "Authenticate" : mode === "signup" ? "Create account" : "Reset password"}
        </button>

        <p className="mt-4 text-center text-[10px] uppercase tracking-[0.3em] text-[color:var(--jarvis-dim)]">
          Passwords are encrypted · lost account? ask the admin for a code
        </p>
      </div>

      <style>{jarvisCss}</style>
    </div>
  );
}

function TabPill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={
        "flex-1 rounded-full py-2 text-[11px] uppercase tracking-[0.25em] transition " +
        (active ? "jarvis-tab-active" : "text-[color:var(--jarvis-dim)] hover:text-[color:var(--jarvis)]")
      }
    >
      {children}
    </button>
  );
}

function JarvisField({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="mb-3 block">
      <div className="mb-1 text-[10px] uppercase tracking-[0.3em] text-[color:var(--jarvis-dim)]">{label}</div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        type={type}
        className="w-full rounded-lg border border-[color:var(--jarvis-line)] bg-black/50 px-3 py-2.5 text-sm text-[color:var(--jarvis)] placeholder:text-[color:var(--jarvis-dim)]/60 outline-none focus:border-[color:var(--jarvis)] focus:shadow-[0_0_18px_rgba(93,214,255,0.35)]"
      />
    </label>
  );
}

const jarvisCss = `
.jarvis-root { --jarvis: #7de8ff; --jarvis-dim: #9fb9cc; --jarvis-line: rgba(125,232,255,0.3); background-size: cover; background-position: center; background-repeat: no-repeat; }
.jarvis-veil { position: absolute; inset: 0; background:
  radial-gradient(1000px 700px at 50% 55%, rgba(2,12,24,0.35), rgba(0,0,0,0.75) 75%),
  linear-gradient(180deg, rgba(0,0,0,0.35), rgba(0,0,0,0.55));
  backdrop-filter: blur(2px);
}
.jarvis-panel {
  background: linear-gradient(180deg, rgba(6,26,44,0.72), rgba(1,12,22,0.78));
  border: 1px solid var(--jarvis-line);
  box-shadow: 0 0 0 1px rgba(125,232,255,0.08) inset, 0 30px 80px -30px rgba(93,214,255,0.5);
  backdrop-filter: blur(14px) saturate(1.1);
}
.jarvis-ring {
  border-radius: 999px;
  border: 1px solid var(--jarvis-line);
  box-shadow: 0 0 40px rgba(93,214,255,0.45), inset 0 0 20px rgba(93,214,255,0.3);
  position: relative;
}
.jarvis-ring::before, .jarvis-ring::after {
  content: ""; position: absolute; inset: -6px; border-radius: 999px;
  border: 1px dashed rgba(125,232,255,0.45);
  animation: jspin 20s linear infinite;
}
.jarvis-ring::after { inset: -14px; animation-duration: 40s; animation-direction: reverse; opacity: .6; }
@keyframes jspin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.jarvis-core {
  background: radial-gradient(circle, #5dd6ff 0%, #0a4a68 70%, #001827 100%);
  color: #001827;
  box-shadow: 0 0 24px rgba(93,214,255,0.7);
}
.jarvis-btn {
  background: linear-gradient(180deg, rgba(93,214,255,0.3), rgba(93,214,255,0.1));
  border: 1px solid var(--jarvis);
  color: var(--jarvis);
  text-shadow: 0 0 10px rgba(125,232,255,0.6);
  box-shadow: 0 0 24px rgba(93,214,255,0.35), inset 0 0 12px rgba(93,214,255,0.15);
  transition: all .15s ease;
}
.jarvis-panel::before {
  content: ""; position: absolute; inset: -1px; border-radius: inherit; pointer-events: none;
  background: linear-gradient(120deg, transparent 30%, rgba(125,232,255,0.25) 50%, transparent 70%);
  background-size: 250% 100%;
  animation: jsheen 5s linear infinite;
  mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor; mask-composite: exclude; padding: 1px;
}
@keyframes jsheen { from { background-position: 200% 0; } to { background-position: -100% 0; } }
.jarvis-in { animation: jin .6s cubic-bezier(.16,1,.3,1) both; }
@keyframes jin { from { opacity: 0; transform: translateY(24px) scale(.96); filter: blur(6px); } to { opacity: 1; transform: none; filter: none; } }
.jarvis-scanlines { position: absolute; inset: 0; pointer-events: none; opacity: .18;
  background: repeating-linear-gradient(180deg, rgba(125,232,255,.35) 0 1px, transparent 1px 4px); }
.jarvis-sweep { position: absolute; left: 0; right: 0; height: 140px; pointer-events: none;
  background: linear-gradient(180deg, transparent, rgba(125,232,255,.12), transparent);
  animation: jsweep 6s ease-in-out infinite; }
@keyframes jsweep { 0% { top: -20%; } 100% { top: 110%; } }
.jarvis-btn { position: relative; overflow: hidden; }
.jarvis-btn::after { content: ""; position: absolute; inset: 0; transform: translateX(-120%);
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.35), transparent); }
.jarvis-btn:hover:not(:disabled)::after { animation: jshine .8s ease; }
@keyframes jshine { to { transform: translateX(120%); } }
.jarvis-btn:active:not(:disabled) { transform: scale(.98); }
.jarvis-btn:hover:not(:disabled) { background: linear-gradient(180deg, rgba(93,214,255,0.45), rgba(93,214,255,0.18)); box-shadow: 0 0 32px rgba(93,214,255,0.55); }
.jarvis-tab-active {
  background: linear-gradient(180deg, rgba(93,214,255,0.3), rgba(93,214,255,0.08));
  color: var(--jarvis);
  box-shadow: inset 0 0 10px rgba(93,214,255,0.3);
}
`;
