import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, Mail, RefreshCw, Send } from "lucide-react";
import { sfx } from "@/lib/sound";

export const SUPPORT_EMAIL = "tokemekiai.company@gmail.com";

type MailMsg = {
  id: string;
  direction: "in" | "out";
  from_email: string;
  body: string;
  created_at: string;
};

function sessionEmail(): string {
  try {
    const raw = localStorage.getItem("ashley.demo.session");
    return raw ? (JSON.parse(raw).email as string) : "";
  } catch {
    return "";
  }
}

export function MailPanel() {
  const [email, setEmail] = useState("");
  const [msgs, setMsgs] = useState<MailMsg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => setEmail(sessionEmail()), []);

  const load = useCallback(async (addr: string) => {
    if (!addr) return;
    const res = await fetch(`/api/mail?email=${encodeURIComponent(addr)}`);
    const json = (await res.json()) as { messages: MailMsg[] };
    setMsgs(json.messages ?? []);
  }, []);

  useEffect(() => {
    if (!email) return;
    void load(email);
    const id = window.setInterval(() => void load(email), 15000);
    return () => window.clearInterval(id);
  }, [email, load]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  const send = async () => {
    if (busy || !text.trim()) return;
    setBusy(true);
    setNote(null);
    sfx.send?.();
    try {
      const res = await fetch("/api/mail", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, body: text }),
      });
      const json = (await res.json()) as { error?: string; note?: string };
      if (json.error) setNote(json.error);
      else {
        setText("");
        if (json.note) setNote(json.note);
        await load(email);
      }
    } catch {
      setNote("Could not reach the mail service.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <Mail className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold">Mail TokemekiAi</h2>
        <span className="text-[11px] text-muted-foreground">{SUPPORT_EMAIL}</span>
        <button
          onClick={() => { sfx.click(); void load(email); }}
          className="glass ml-auto flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
          aria-label="Refresh mail"
        >
          <RefreshCw className="h-3.5 w-3.5" />
        </button>
      </div>

      <label className="block">
        <div className="mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Your email</div>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full rounded-xl border border-border bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
        />
      </label>

      <div className="max-h-[46vh] min-h-[180px] space-y-2 overflow-y-auto rounded-2xl border border-border bg-background/40 p-3">
        {msgs.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">
            No mail yet. Write below — replies from TokemekiAi show up here.
          </p>
        )}
        {msgs.map((m) => (
          <div
            key={m.id}
            className={
              "max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm " +
              (m.direction === "out"
                ? "ml-auto bg-primary/20 text-foreground"
                : "mr-auto border border-border bg-card/70")
            }
          >
            <div className="mb-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
              {m.direction === "out" ? "You" : "TokemekiAi"}
            </div>
            {m.body}
          </div>
        ))}
        <div ref={endRef} />
      </div>

      {note && <p className="text-xs text-amber-300">{note}</p>}

      <div className="flex items-end gap-2">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={2}
          placeholder="Write your message to TokemekiAi…"
          className="flex-1 resize-none rounded-2xl border border-border bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
        />
        <button
          onClick={send}
          disabled={busy}
          className="ashley-gradient flex h-11 w-11 items-center justify-center rounded-2xl text-primary-foreground disabled:opacity-50"
          aria-label="Send mail"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}
