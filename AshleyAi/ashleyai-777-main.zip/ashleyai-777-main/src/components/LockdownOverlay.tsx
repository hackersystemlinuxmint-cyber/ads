import { useEffect, useState } from "react";
import { AlertTriangle, Mail } from "lucide-react";
import { AshleyFace } from "@/components/AshleyFace";
import { setFaceEmotion, speakAshley, type Emotion } from "@/lib/ashley-voice";
import { LOCKDOWN_SCRIPT, remainingLabel, GMAIL_URL, CONTACT_MAIL } from "@/lib/lockdown";

/** Full-screen shutdown scene: Ashley's animated face reads the warning. */
export function LockdownOverlay({ open, onDismiss }: { open: boolean; onDismiss: () => void }) {
  const [line, setLine] = useState(0);
  const [left, setLeft] = useState(remainingLabel());

  useEffect(() => {
    if (!open) return;
    setLine(0);
    let i = 0;
    const say = () => {
      const step = LOCKDOWN_SCRIPT[i];
      if (!step) return;
      setLine(i);
      setFaceEmotion(step.emotion as Emotion);
      speakAshley(step.text);
    };
    say();
    const id = window.setInterval(() => {
      i += 1;
      if (i >= LOCKDOWN_SCRIPT.length) {
        window.clearInterval(id);
        return;
      }
      say();
    }, 4200);
    return () => window.clearInterval(id);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const id = window.setInterval(() => setLeft(remainingLabel()), 30_000);
    return () => window.clearInterval(id);
  }, [open]);

  if (!open) return null;

  return (
    <div className="lockdown-backdrop fixed inset-0 z-[100] flex items-center justify-center bg-background/90 p-4 backdrop-blur-xl">
      <div className="lockdown-card glass relative w-full max-w-[min(92vw,640px)] rounded-3xl p-5 text-center sm:p-8">
        <div className="hud-corners" />
        <div className="lockdown-hazard top" />
        <div className="lockdown-hazard bottom" />
        <div className="lockdown-scanline" />
        <div className="mx-auto mb-3 mt-2 flex items-center justify-center gap-2 text-destructive">
          <AlertTriangle className="h-6 w-6 lockdown-warn" />
          <span className="lockdown-glitch text-sm font-bold uppercase tracking-[0.3em]">Sorry access denied</span>
          <AlertTriangle className="h-6 w-6 lockdown-warn" />
        </div>

        <div className="relative mx-auto w-fit">
          <div className="lockdown-ring" />
          <div className="lockdown-ring inner" />
          <AshleyFace className="h-32 w-32 sm:h-44 sm:w-44" />
        </div>

        <div className="mt-4 min-h-[72px] space-y-2">
          {LOCKDOWN_SCRIPT.map((s, i) => (
            <p
              key={i}
              className={
                "text-sm transition-all duration-500 sm:text-base " +
                (i === line
                  ? "lockdown-line text-foreground opacity-100"
                  : i < line
                    ? "text-muted-foreground opacity-50"
                    : "opacity-0 h-0 overflow-hidden")
              }
            >
              {s.text}
            </p>
          ))}
        </div>

        <p className="mt-4 text-xs uppercase tracking-[0.25em] text-muted-foreground">
          Servers offline · unlocks in {left}
        </p>

        <div className="mt-5 flex flex-col items-center justify-center gap-2 sm:flex-row">
          <a
            href={GMAIL_URL}
            target="_blank"
            rel="noreferrer"
            className="ashley-gradient ashley-cta inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold text-primary-foreground"
          >
            <Mail className="h-4 w-4" /> Contact {CONTACT_MAIL}
          </a>
          <button
            onClick={onDismiss}
            className="glass rounded-2xl px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
