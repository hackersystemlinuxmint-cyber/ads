export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_session: {
        Row: {
          claimed_at: string
          email: string
          token: string
        }
        Insert: {
          claimed_at?: string
          email: string
          token: string
        }
        Update: {
          claimed_at?: string
          email?: string
          token?: string
        }
        Relationships: []
      }
      app_users: {
        Row: {
          created_at: string
          email_for_code: string
          id: string
          identifier: string
          identifier_type: string
          password_hash: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email_for_code: string
          id?: string
          identifier: string
          identifier_type: string
          password_hash: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email_for_code?: string
          id?: string
          identifier?: string
          identifier_type?: string
          password_hash?: string
          updated_at?: string
        }
        Relationships: []
      }
      ashley_accounts: {
        Row: {
          created_at: string
          email: string
          id: string
          password_hash: string
          reset_code_hash: string | null
          reset_expires_at: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          password_hash: string
          reset_code_hash?: string | null
          reset_expires_at?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          password_hash?: string
          reset_code_hash?: string | null
          reset_expires_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      blox_players: {
        Row: {
          created_at: string
          id: string
          is_admin: boolean
          kills: number
          name: string
          name_key: string
          owner_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_admin?: boolean
          kills?: number
          name: string
          name_key: string
          owner_key: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_admin?: boolean
          kills?: number
          name?: string
          name_key?: string
          owner_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      blox_servers: {
        Row: {
          code: string
          created_at: string
          id: string
          max_players: number
          name: string
          owner_key: string
          owner_name: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          max_players?: number
          name: string
          owner_key: string
          owner_name: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          max_players?: number
          name?: string
          owner_key?: string
          owner_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      mail_messages: {
        Row: {
          body: string
          created_at: string
          direction: string
          from_email: string
          id: string
          subject: string
          thread_email: string
          to_email: string
        }
        Insert: {
          body: string
          created_at?: string
          direction: string
          from_email: string
          id?: string
          subject?: string
          thread_email: string
          to_email: string
        }
        Update: {
          body?: string
          created_at?: string
          direction?: string
          from_email?: string
          id?: string
          subject?: string
          thread_email?: string
          to_email?: string
        }
        Relationships: []
      }
      pending_verifications: {
        Row: {
          attempts: number
          code_hash: string
          created_at: string
          email_for_code: string
          expires_at: string
          id: string
          identifier: string
          identifier_type: string
          password_hash: string
        }
        Insert: {
          attempts?: number
          code_hash: string
          created_at?: string
          email_for_code: string
          expires_at?: string
          id?: string
          identifier: string
          identifier_type: string
          password_hash: string
        }
        Update: {
          attempts?: number
          code_hash?: string
          created_at?: string
          email_for_code?: string
          expires_at?: string
          id?: string
          identifier?: string
          identifier_type?: string
          password_hash?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      blox_add_kills: {
        Args: { _amount: number; _name: string; _owner_key: string }
        Returns: number
      }
      blox_claim_name: {
        Args: { _admin_pass?: string; _name: string; _owner_key: string }
        Returns: {
          is_admin: boolean
          kills: number
          ok: boolean
          reason: string
        }[]
      }
      blox_create_server: {
        Args: { _name: string; _owner_key: string; _owner_name: string }
        Returns: {
          code: string
          name: string
          ok: boolean
          reason: string
        }[]
      }
      blox_join_server: {
        Args: { _code: string }
        Returns: {
          code: string
          max_players: number
          name: string
          ok: boolean
          owner_name: string
          reason: string
        }[]
      }
      blox_my_servers: {
        Args: { _owner_key: string }
        Returns: {
          code: string
          created_at: string
          name: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
