// Server-only auth helpers for AshleyAI.
import bcrypt from "bcryptjs";

const RESEND_URL = "https://connector-gateway.lovable.dev/resend/emails";

export const SESSION_CONFIG = {
  password: process.env.SESSION_SECRET || "",
  name: "ashley-session",
  maxAge: 60 * 60 * 24 * 30, // 30 days
  cookie: {
    httpOnly: true,
    secure: true,
    sameSite: "lax" as const,
    path: "/",
  },
};

export type SessionData = { userId?: string; identifier?: string };

export function generate20DigitCode(): string {
  // Cryptographically strong 20-digit numeric code, formatted in 4x5 groups.
  const bytes = new Uint8Array(20);
  crypto.getRandomValues(bytes);
  const raw = Array.from(bytes, (b) => (b % 10).toString()).join("");
  return raw.replace(/(.{5})/g, "$1-").replace(/-$/, "");
}

export function normalizeCode(input: string): string {
  return input.replace(/\D/g, "");
}

export function isEmail(v: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

export function isPhone(v: string): boolean {
  const digits = v.replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15;
}

export function normalizePhone(v: string): string {
  const digits = v.replace(/\D/g, "");
  return "+" + digits;
}

export async function hashPassword(pw: string): Promise<string> {
  return bcrypt.hash(pw, 10);
}
export async function verifyPassword(pw: string, hash: string): Promise<boolean> {
  return bcrypt.compare(pw, hash);
}
export async function hashCode(code: string): Promise<string> {
  return bcrypt.hash(code, 8);
}
export async function verifyCode(code: string, hash: string): Promise<boolean> {
  return bcrypt.compare(code, hash);
}

export async function sendVerificationEmail(to: string, code: string): Promise<void> {
  const lovableKey = process.env.LOVABLE_API_KEY;
  const resendKey = process.env.RESEND_API_KEY;
  if (!lovableKey || !resendKey) {
    throw new Error("Email service is not configured.");
  }

  const pretty = code; // already grouped as 5-5-5-5
  const html = `
    <div style="font-family:Inter,system-ui,sans-serif;background:#0b0f1a;padding:32px;color:#e6f2ff">
      <div style="max-width:520px;margin:0 auto;background:linear-gradient(180deg,#0f1a2e,#0b0f1a);border:1px solid #1f3a5f;border-radius:20px;padding:28px">
        <div style="font-family:'Space Grotesk',sans-serif;font-size:22px;font-weight:700;background:linear-gradient(120deg,#ff5db1,#4dd0ff);-webkit-background-clip:text;background-clip:text;color:transparent;letter-spacing:.02em">
          AshleyAI · ASH_AI
        </div>
        <h1 style="margin:14px 0 4px 0;font-size:20px;color:#e6f2ff">Your verification code</h1>
        <p style="margin:0 0 20px 0;color:#8aa4c7;font-size:13px">Enter this 20-digit code in AshleyAI to finish creating your account. It expires in 20 minutes.</p>
        <div style="font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:22px;letter-spacing:.15em;text-align:center;background:#0a1424;border:1px solid #1f3a5f;border-radius:14px;padding:18px;color:#4dd0ff">
          ${pretty}
        </div>
        <p style="margin-top:20px;color:#546b8a;font-size:11px">If you didn't request this, you can safely ignore this email.</p>
      </div>
    </div>`;

  const res = await fetch(RESEND_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": resendKey,
    },
    body: JSON.stringify({
      from: "AshleyAI <onboarding@resend.dev>",
      to: [to],
      subject: "Your AshleyAI verification code",
      html,
    }),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Email send failed [${res.status}]: ${body.slice(0, 200)}`);
  }
}
