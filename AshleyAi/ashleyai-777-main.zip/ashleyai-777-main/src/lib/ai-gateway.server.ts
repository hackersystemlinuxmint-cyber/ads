import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

export const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";

export function getApiKey(): string {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return key;
}

export function createProvider() {
  const key = getApiKey();
  return createOpenAICompatible({
    name: "lovable",
    baseURL: GATEWAY_URL,
    headers: {
      "Lovable-API-Key": key,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
  });
}

export async function gatewayFetch(path: string, init: RequestInit) {
  const key = getApiKey();
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${key}`);
  return fetch(`${GATEWAY_URL}${path}`, { ...init, headers });
}
