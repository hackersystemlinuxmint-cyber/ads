// AshleyBlox account + admin identity (device-stored, name uniqueness enforced online).
import { supabase } from "@/integrations/supabase/client";

export const ADMIN_PASSWORD = "ElijahAtienzaCeoOfTokemekiAi";
export const ADMIN_EMAIL = "tokemekiai@gmail.com";
export const ADMIN_NAME = "TokemekiAi";

const KEY = "ashleyblox.identity.v1";
const OWNER = "ashleyblox.ownerkey.v1";

export type BloxIdentity = {
  email: string;
  name: string;
  isAdmin: boolean;
  kills: number;
};

export function ownerKey(): string {
  let k = localStorage.getItem(OWNER);
  if (!k) {
    k = crypto.randomUUID() + crypto.randomUUID().slice(0, 8);
    localStorage.setItem(OWNER, k);
  }
  return k;
}

export function loadIdentity(): BloxIdentity | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as BloxIdentity) : null;
  } catch {
    return null;
  }
}

export function saveIdentity(id: BloxIdentity | null) {
  if (!id) localStorage.removeItem(KEY);
  else localStorage.setItem(KEY, JSON.stringify(id));
}

/** Display name used in game — admins get the red owner tag + check mark. */
export function displayName(id: BloxIdentity): string {
  return id.isAdmin ? `[ADMIN OWNER] ${id.name} ✓` : id.name;
}

export type ClaimResult = { ok: boolean; reason: string; isAdmin: boolean; kills: number };

/** Claim a globally unique player name. Returns ok=false if someone else owns it. */
export async function claimName(name: string, adminPass?: string): Promise<ClaimResult> {
  const { data, error } = await supabase.rpc("blox_claim_name", {
    _name: name,
    _owner_key: ownerKey(),
    _admin_pass: adminPass ?? undefined,
  });
  if (error) return { ok: false, reason: "Server unreachable — try again.", isAdmin: false, kills: 0 };
  const row = (Array.isArray(data) ? data[0] : data) as
    | { ok: boolean; reason: string; is_admin: boolean; kills: number }
    | undefined;
  if (!row) return { ok: false, reason: "Could not claim that name.", isAdmin: false, kills: 0 };
  return { ok: row.ok, reason: row.reason, isAdmin: row.is_admin, kills: row.kills ?? 0 };
}

export async function reportKills(name: string, amount: number): Promise<number | null> {
  if (amount <= 0) return null;
  const { data } = await supabase.rpc("blox_add_kills", {
    _name: name,
    _owner_key: ownerKey(),
    _amount: amount,
  });
  return typeof data === "number" ? data : null;
}

export type RankRow = { name: string; kills: number; is_admin: boolean };

export async function fetchRanking(limit = 20): Promise<RankRow[]> {
  const { data } = await supabase
    .from("blox_players")
    .select("name, kills, is_admin")
    .order("kills", { ascending: false })
    .limit(limit);
  return (data as RankRow[] | null) ?? [];
}

/** Global rank (1 = most take-downs) for a player name, plus the total player count. */
export async function fetchMyRank(name: string): Promise<{ rank: number; total: number; kills: number } | null> {
  const rows = await fetchRanking(500);
  const total = rows.length;
  const i = rows.findIndex((r) => r.name.toLowerCase() === name.trim().toLowerCase());
  if (i < 0) return { rank: total + 1, total: total + 1, kills: 0 };
  return { rank: i + 1, total, kills: rows[i].kills };
}

