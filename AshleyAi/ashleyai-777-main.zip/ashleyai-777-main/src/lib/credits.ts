import { useCallback, useEffect, useState } from "react";

const KEY = "ashley.credits";
const START = 1000;
const EVT = "ashley-credits-change";

export function getCredits(): number {
  if (typeof window === "undefined") return START;
  const raw = localStorage.getItem(KEY);
  if (raw === null) {
    localStorage.setItem(KEY, String(START));
    return START;
  }
  const n = Number(raw);
  return Number.isFinite(n) ? n : START;
}

export function setCredits(n: number) {
  localStorage.setItem(KEY, String(Math.max(0, Math.round(n))));
  window.dispatchEvent(new Event(EVT));
}

export function addCredits(n: number) {
  setCredits(getCredits() + n);
}

export function spendCredits(n: number): boolean {
  const cur = getCredits();
  if (cur < n) return false;
  setCredits(cur - n);
  return true;
}

export function useCredits() {
  const [credits, setC] = useState<number>(START);

  useEffect(() => {
    setC(getCredits());
    const sync = () => setC(getCredits());
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const add = useCallback((n: number) => addCredits(n), []);
  return { credits, add };
}

export type PackId = "starter" | "plus" | "pro" | "whale";

export const CREDIT_PACKS: {
  id: PackId;
  credits: number;
  php: number;
  usd: number;
  btc: string;
  label: string;
}[] = [
  { id: "starter", credits: 500, php: 99, usd: 1.99, btc: "0.00002", label: "Starter" },
  { id: "plus", credits: 1500, php: 249, usd: 4.99, btc: "0.00005", label: "Plus" },
  { id: "pro", credits: 5000, php: 749, usd: 14.99, btc: "0.00015", label: "Pro" },
  { id: "whale", credits: 20000, php: 2499, usd: 49.99, btc: "0.0005", label: "Whale" },
];

export const WALLETS = [
  { coin: "Bitcoin", symbol: "BTC", address: "bc1qashleyai0xlex175demoaddressbtc0000" },
  { coin: "Ethereum", symbol: "ETH", address: "0xA5H1EyA1DemoWa11etAddre55Eth00000000" },
  { coin: "Tether", symbol: "USDT", address: "TAshleyAIDemoUsdtTronWalletAddr00000" },
  { coin: "Solana", symbol: "SOL", address: "AshLeyAiDemoSo1anaWa11etAddress00000" },
];

export const PAY_METHODS = [
  { id: "gcash", name: "GCash", detail: "09XX XXX XXXX · AshleyAI (Elijah A.)" },
  { id: "paypal", name: "PayPal", detail: "pay@ashleyai.app" },
  { id: "dito", name: "DITO Money", detail: "09XX XXX XXXX · AshleyAI" },
  { id: "btc", name: "Bitcoin / Crypto", detail: WALLETS[0].address },
];
