// Private AshleyBlox servers — created and joined through secure invite codes.
import { supabase } from "@/integrations/supabase/client";
import { ownerKey } from "@/lib/blox-auth";

export type PrivateServer = { code: string; name: string; ownerName?: string; maxPlayers?: number };

export async function createPrivateServer(name: string, ownerName: string) {
  const { data, error } = await supabase.rpc("blox_create_server", {
    _name: name,
    _owner_key: ownerKey(),
    _owner_name: ownerName,
  });
  if (error) return { ok: false as const, reason: "Server unreachable — try again." };
  const row = (Array.isArray(data) ? data[0] : data) as
    | { ok: boolean; reason: string; code: string | null; name: string | null }
    | undefined;
  if (!row?.ok || !row.code) return { ok: false as const, reason: row?.reason ?? "Could not create the server." };
  return { ok: true as const, server: { code: row.code, name: row.name ?? name } as PrivateServer };
}

export async function joinPrivateServer(code: string) {
  const { data, error } = await supabase.rpc("blox_join_server", { _code: code.trim().toUpperCase() });
  if (error) return { ok: false as const, reason: "Server unreachable — try again." };
  const row = (Array.isArray(data) ? data[0] : data) as
    | { ok: boolean; reason: string; code: string | null; name: string | null; owner_name: string | null; max_players: number | null }
    | undefined;
  if (!row?.ok || !row.code) return { ok: false as const, reason: row?.reason ?? "No private server with that invite code." };
  return {
    ok: true as const,
    server: {
      code: row.code,
      name: row.name ?? "Private Server",
      ownerName: row.owner_name ?? "Player",
      maxPlayers: row.max_players ?? 8,
    } as PrivateServer,
  };
}

export async function myPrivateServers(): Promise<PrivateServer[]> {
  const { data } = await supabase.rpc("blox_my_servers", { _owner_key: ownerKey() });
  const rows = (data as { code: string; name: string }[] | null) ?? [];
  return rows.map((r) => ({ code: r.code, name: r.name }));
}
