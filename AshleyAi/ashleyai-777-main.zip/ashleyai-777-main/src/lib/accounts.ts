// Client helpers for the central AshleyAI account server.
export type AccountRow = { email: string; created_at: string; reset_expires_at: string | null };

async function post<T>(body: Record<string, unknown>): Promise<T & { error?: string }> {
  const res = await fetch("/api/accounts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return (await res.json()) as T & { error?: string };
}

export const accountSignup = (email: string, password: string) =>
  post<{ ok?: boolean }>({ action: "signup", email, password });

export const accountLogin = (email: string, password: string) =>
  post<{ ok?: boolean }>({ action: "login", email, password });

export const accountRedeem = (email: string, code: string, password: string) =>
  post<{ ok?: boolean }>({ action: "redeem", email, code, password });

export const accountList = (adminEmail: string) =>
  post<{ ok?: boolean; accounts?: AccountRow[] }>({ action: "list", adminEmail });

export const accountReset = (adminEmail: string, target: string) =>
  post<{ ok?: boolean; target?: string; code?: string; expiresInMinutes?: number }>({
    action: "reset",
    adminEmail,
    target,
  });
