// AshleyBlox — procedural game SFX (WebAudio) + haptics.
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;
let volume = 0.9;
let hapticsOn = true;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume().catch(() => {});
  return ctx;
}

export function setGameVolume(v: number) {
  volume = Math.max(0, Math.min(1, v));
  if (master && ctx) master.gain.setTargetAtTime(volume, ctx.currentTime, 0.05);
}
export function setHaptics(on: boolean) {
  hapticsOn = on;
}
export function buzz(ms: number | number[]) {
  if (!hapticsOn) return;
  try {
    navigator.vibrate?.(ms as number);
  } catch {
    /* noop */
  }
}

function noise(c: AudioContext) {
  if (!noiseBuf) {
    const len = c.sampleRate * 1.2;
    noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }
  const src = c.createBufferSource();
  src.buffer = noiseBuf;
  src.loop = true;
  return src;
}

type NoiseOpts = { dur: number; gain: number; type?: BiquadFilterType; freq?: number; q?: number; sweepTo?: number; delay?: number };
function burst({ dur, gain, type = "lowpass", freq = 1200, q = 1, sweepTo, delay = 0 }: NoiseOpts) {
  const c = ac();
  if (!c || !master) return;
  const t0 = c.currentTime + delay;
  const src = noise(c);
  const f = c.createBiquadFilter();
  f.type = type;
  f.frequency.setValueAtTime(freq, t0);
  f.Q.value = q;
  if (sweepTo !== undefined) f.frequency.exponentialRampToValueAtTime(Math.max(40, sweepTo), t0 + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f).connect(g).connect(master);
  src.start(t0);
  src.stop(t0 + dur + 0.05);
}

type ToneOpts = { f: number; to?: number; dur: number; gain: number; type?: OscillatorType; delay?: number };
function tone({ f, to, dur, gain, type = "sine", delay = 0 }: ToneOpts) {
  const c = ac();
  if (!c || !master) return;
  const t0 = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f, t0);
  if (to) o.frequency.exponentialRampToValueAtTime(Math.max(20, to), t0 + dur);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(master);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}

export const gsfx = {
  shoot(kind: "pistol" | "smg" | "rifle" = "pistol") {
    const p = { pistol: { d: 0.16, g: 0.5, f: 2600 }, smg: { d: 0.1, g: 0.38, f: 3400 }, rifle: { d: 0.26, g: 0.6, f: 1800 } }[kind];
    burst({ dur: p.d, gain: p.g, type: "bandpass", freq: p.f, q: 0.8, sweepTo: 220 });
    tone({ f: 160, to: 48, dur: p.d * 1.4, gain: 0.28, type: "square" });
    buzz(kind === "rifle" ? 26 : 14);
  },
  dryFire() {
    tone({ f: 900, dur: 0.05, gain: 0.12, type: "square" });
  },
  swing() {
    burst({ dur: 0.22, gain: 0.3, type: "bandpass", freq: 900, q: 1.4, sweepTo: 260 });
  },
  punch() {
    tone({ f: 220, to: 70, dur: 0.14, gain: 0.32, type: "triangle" });
    burst({ dur: 0.1, gain: 0.22, freq: 900, sweepTo: 200 });
    buzz(18);
  },
  kick() {
    tone({ f: 150, to: 46, dur: 0.24, gain: 0.4, type: "triangle" });
    burst({ dur: 0.16, gain: 0.28, freq: 700, sweepTo: 140 });
    buzz([12, 24, 30]);
  },
  impact() {
    burst({ dur: 0.09, gain: 0.24, type: "highpass", freq: 2200 });
  },
  hitmark() {
    tone({ f: 1500, dur: 0.05, gain: 0.2, type: "square" });
    tone({ f: 2100, dur: 0.05, gain: 0.16, type: "square", delay: 0.04 });
    buzz(12);
  },
  kill() {
    tone({ f: 780, dur: 0.09, gain: 0.24, type: "triangle" });
    tone({ f: 1180, dur: 0.09, gain: 0.24, type: "triangle", delay: 0.08 });
    tone({ f: 1560, dur: 0.18, gain: 0.24, type: "triangle", delay: 0.16 });
    buzz([20, 40, 60]);
  },
  hurt() {
    tone({ f: 180, to: 90, dur: 0.2, gain: 0.3, type: "sawtooth" });
    burst({ dur: 0.14, gain: 0.2, freq: 600 });
    buzz(40);
  },
  reloadOut() {
    tone({ f: 520, dur: 0.06, gain: 0.16, type: "square" });
    burst({ dur: 0.07, gain: 0.12, type: "highpass", freq: 3000, delay: 0.05 });
  },
  reloadIn() {
    tone({ f: 340, dur: 0.07, gain: 0.2, type: "square", delay: 0.02 });
    tone({ f: 760, dur: 0.05, gain: 0.16, type: "square", delay: 0.14 });
    buzz(16);
  },
  jump() {
    tone({ f: 420, to: 720, dur: 0.12, gain: 0.16, type: "sine" });
  },
  land() {
    tone({ f: 140, to: 60, dur: 0.14, gain: 0.22, type: "triangle" });
    burst({ dur: 0.12, gain: 0.16, freq: 500, sweepTo: 120 });
    buzz(20);
  },
  step(run: boolean) {
    burst({ dur: run ? 0.07 : 0.05, gain: run ? 0.11 : 0.07, freq: run ? 900 : 620, sweepTo: 180 });
  },
  dash() {
    burst({ dur: 0.34, gain: 0.3, type: "bandpass", freq: 400, q: 0.7, sweepTo: 1800 });
    tone({ f: 300, to: 900, dur: 0.28, gain: 0.16, type: "sawtooth" });
    buzz([10, 10, 24]);
  },
  slide() {
    burst({ dur: 0.55, gain: 0.26, type: "bandpass", freq: 1500, q: 0.9, sweepTo: 220 });
    buzz(30);
  },
  crouch() {
    tone({ f: 300, to: 190, dur: 0.09, gain: 0.12, type: "triangle" });
  },
  throwGrenade() {
    burst({ dur: 0.2, gain: 0.2, type: "bandpass", freq: 1100, q: 1.2, sweepTo: 400 });
    tone({ f: 620, to: 320, dur: 0.16, gain: 0.12, type: "sine" });
  },
  explode() {
    burst({ dur: 0.9, gain: 0.75, type: "lowpass", freq: 1800, sweepTo: 60 });
    tone({ f: 90, to: 28, dur: 1.0, gain: 0.5, type: "sawtooth" });
    tone({ f: 220, to: 40, dur: 0.5, gain: 0.28, type: "square" });
    buzz([40, 30, 80]);
  },
  shield() {
    tone({ f: 500, to: 1200, dur: 0.35, gain: 0.2, type: "sine" });
    tone({ f: 750, to: 1500, dur: 0.35, gain: 0.14, type: "triangle", delay: 0.05 });
  },
  heal() {
    tone({ f: 620, dur: 0.12, gain: 0.18, type: "sine" });
    tone({ f: 880, dur: 0.14, gain: 0.18, type: "sine", delay: 0.1 });
    tone({ f: 1240, dur: 0.2, gain: 0.16, type: "sine", delay: 0.2 });
  },
  rage() {
    tone({ f: 120, to: 420, dur: 0.6, gain: 0.34, type: "sawtooth" });
    burst({ dur: 0.6, gain: 0.24, type: "bandpass", freq: 300, q: 0.6, sweepTo: 1400 });
    buzz([50, 30, 90]);
  },
  shock() {
    burst({ dur: 0.5, gain: 0.5, type: "lowpass", freq: 1200, sweepTo: 80 });
    tone({ f: 180, to: 44, dur: 0.6, gain: 0.32, type: "square" });
    buzz([30, 20, 60]);
  },
  ads(on: boolean) {
    tone({ f: on ? 900 : 700, to: on ? 1250 : 520, dur: 0.09, gain: 0.1, type: "sine" });
  },
  ui() {
    tone({ f: 1100, dur: 0.04, gain: 0.08, type: "triangle" });
  },
  swap() {
    tone({ f: 700, dur: 0.05, gain: 0.12, type: "square" });
    tone({ f: 1050, dur: 0.05, gain: 0.1, type: "square", delay: 0.05 });
  },
};
