import { createServerFn } from "@tanstack/react-start";
import { useSession } from "@tanstack/react-start/server";
import { z } from "zod";

const signupSchema = z.object({
  identifier: z.string().trim().min(3).max(120),
  identifierType: z.enum(["phone", "email"]),
  emailForCode: z.string().trim().email().max(200),
  password: z.string().min(8).max(200),
});
const verifySchema = z.object({
  identifier: z.string().trim().min(3).max(120),
  code: z.string().min(15).max(40),
});
const loginSchema = z.object({
  identifier: z.string().trim().min(3).max(120),
  password: z.string().min(1).max(200),
});

/** Start signup: create pending verification and email the 20-digit code. */
export const startSignup = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => signupSchema.parse(data))
  .handler(async ({ data }) => {
    const auth = await import("./auth.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const identifier =
      data.identifierType === "phone"
        ? auth.normalizePhone(data.identifier)
        : data.identifier.toLowerCase();

    if (data.identifierType === "phone" && !auth.isPhone(data.identifier)) {
      throw new Error("Please enter a valid phone number.");
    }
    if (data.identifierType === "email" && !auth.isEmail(data.identifier)) {
      throw new Error("Please enter a valid email address.");
    }

    const existing = await supabaseAdmin
      .from("app_users")
      .select("id")
      .eq("identifier", identifier)
      .maybeSingle();
    if (existing.data) throw new Error("An account with that identifier already exists.");

    const code = auth.generate20DigitCode();
    const codeHash = await auth.hashCode(auth.normalizeCode(code));
    const passwordHash = await auth.hashPassword(data.password);

    // Clear any prior pending records for this identifier.
    await supabaseAdmin.from("pending_verifications").delete().eq("identifier", identifier);

    const { error } = await supabaseAdmin.from("pending_verifications").insert({
      identifier,
      identifier_type: data.identifierType,
      email_for_code: data.emailForCode,
      password_hash: passwordHash,
      code_hash: codeHash,
    });
    if (error) throw new Error(error.message);

    await auth.sendVerificationEmail(data.emailForCode, code);
    return { ok: true, sentTo: data.emailForCode };
  });

/** Verify code: promote pending -> app_users and start session. */
export const verifySignup = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => verifySchema.parse(data))
  .handler(async ({ data }) => {
    const auth = await import("./auth.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const identifierRaw = data.identifier.trim();
    const identifier = /^\+?\d[\d\s\-().]*$/.test(identifierRaw)
      ? auth.normalizePhone(identifierRaw)
      : identifierRaw.toLowerCase();

    const { data: pending, error } = await supabaseAdmin
      .from("pending_verifications")
      .select("*")
      .eq("identifier", identifier)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!pending) throw new Error("No pending signup found. Start over.");
    if (new Date(pending.expires_at).getTime() < Date.now()) {
      await supabaseAdmin.from("pending_verifications").delete().eq("id", pending.id);
      throw new Error("Code expired. Please start signup again.");
    }
    if (pending.attempts >= 5) {
      await supabaseAdmin.from("pending_verifications").delete().eq("id", pending.id);
      throw new Error("Too many attempts. Please start signup again.");
    }

    const normalized = auth.normalizeCode(data.code);
    const ok = await auth.verifyCode(normalized, pending.code_hash);
    if (!ok) {
      await supabaseAdmin
        .from("pending_verifications")
        .update({ attempts: pending.attempts + 1 })
        .eq("id", pending.id);
      throw new Error("Incorrect code.");
    }

    const inserted = await supabaseAdmin
      .from("app_users")
      .insert({
        identifier,
        identifier_type: pending.identifier_type,
        email_for_code: pending.email_for_code,
        password_hash: pending.password_hash,
      })
      .select("id, identifier")
      .single();
    if (inserted.error) throw new Error(inserted.error.message);

    await supabaseAdmin.from("pending_verifications").delete().eq("id", pending.id);

    const session = await useSession<{ userId?: string; identifier?: string }>(auth.SESSION_CONFIG);
    await session.update({ userId: inserted.data.id, identifier: inserted.data.identifier });

    return { ok: true, identifier: inserted.data.identifier };
  });

/** Login with identifier + password. */
export const login = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => loginSchema.parse(data))
  .handler(async ({ data }) => {
    const auth = await import("./auth.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const identifierRaw = data.identifier.trim();
    const identifier = /^\+?\d[\d\s\-().]*$/.test(identifierRaw)
      ? auth.normalizePhone(identifierRaw)
      : identifierRaw.toLowerCase();

    const { data: user, error } = await supabaseAdmin
      .from("app_users")
      .select("id, identifier, password_hash")
      .eq("identifier", identifier)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!user) throw new Error("Invalid credentials.");

    const ok = await auth.verifyPassword(data.password, user.password_hash);
    if (!ok) throw new Error("Invalid credentials.");

    const session = await useSession<{ userId?: string; identifier?: string }>(auth.SESSION_CONFIG);
    await session.update({ userId: user.id, identifier: user.identifier });
    return { ok: true, identifier: user.identifier };
  });

export const logout = createServerFn({ method: "POST" }).handler(async () => {
  const auth = await import("./auth.server");
  const session = await useSession<{ userId?: string }>(auth.SESSION_CONFIG);
  await session.clear();
  return { ok: true };
});

export const me = createServerFn({ method: "GET" }).handler(async () => {
  const auth = await import("./auth.server");
  const session = await useSession<{ userId?: string; identifier?: string }>(auth.SESSION_CONFIG);
  if (!session.data.userId) return { user: null };
  return { user: { id: session.data.userId, identifier: session.data.identifier ?? "" } };
});
