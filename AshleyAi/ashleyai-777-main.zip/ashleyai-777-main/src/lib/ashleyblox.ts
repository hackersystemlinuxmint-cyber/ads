// AshleyBlox — local (on-device) account, avatar and game data store.
export type AgeTier = "KIDS" | "SELECTED" | "OPEN";

export type BloxAccount = {
  first: string;
  middle?: string;
  last: string;
  birthday: string; // yyyy-mm-dd
  age: number;
  tier: AgeTier;
  email: string;
  faceVerified: boolean;
  createdAt: string;
};

export type BloxAvatar = {
  charName: string;
  skin: string;
  shirt: string;
  pants: string;
  hair: string;
  face: "smile" | "cool" | "wink" | "serious";
};

export type BloxSave = {
  account: BloxAccount | null;
  avatar: BloxAvatar | null;
  loggedIn: boolean;
  ownedWeapons: string[];
  ownedStyles: string[];
  ownedSkills: string[];
  style: string;
  privateServers: { id: string; name: string; createdAt: string }[];
};

const KEY = "ashleyblox.save.v1";

export const DEFAULT_AVATAR: BloxAvatar = {
  charName: "NewBloxian",
  skin: "#f2c9a0",
  shirt: "#ff4fa3",
  pants: "#2b2350",
  hair: "#1b1430",
  face: "smile",
};

const EMPTY: BloxSave = {
  account: null,
  avatar: null,
  loggedIn: false,
  ownedWeapons: ["fists"],
  ownedStyles: ["brawler"],
  ownedSkills: ["dash"],
  style: "brawler",
  privateServers: [],
};


export function loadBlox(): BloxSave {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return EMPTY;
    return { ...EMPTY, ...(JSON.parse(raw) as BloxSave) };
  } catch {
    return EMPTY;
  }
}

export function saveBlox(next: BloxSave) {
  localStorage.setItem(KEY, JSON.stringify(next));
}

export function ageFromBirthday(birthday: string): number {
  const b = new Date(birthday);
  if (Number.isNaN(b.getTime())) return 0;
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age -= 1;
  return Math.max(0, age);
}

export function tierForAge(age: number): AgeTier {
  if (age < 10) return "KIDS";
  if (age <= 18) return "SELECTED";
  return "OPEN";
}

export function tierLabel(tier: AgeTier): string {
  return tier === "OPEN" ? "" : tier;
}

// ---- Ro-shooter content ----
export type Weapon = {
  id: string;
  name: string;
  kind: "gun" | "melee" | "throwable";
  price: number;
  rbx: number; // Robux price in the in-game shop
  dmg: number;
  rate: number; // ms between shots
  range: number;
  clip: number; // shots before a reload (0 = no reload)
  reload: number; // ms
};

export const WEAPONS: Weapon[] = [
  { id: "fists", name: "Fists", kind: "melee", price: 0, rbx: 0, dmg: 8, rate: 420, range: 42, clip: 0, reload: 0 },
  { id: "pistol", name: "Blox Pistol", kind: "gun", price: 150, rbx: 15, dmg: 18, rate: 320, range: 520, clip: 12, reload: 1100 },
  { id: "smg", name: "Neon SMG", kind: "gun", price: 420, rbx: 45, dmg: 12, rate: 110, range: 460, clip: 30, reload: 1500 },
  { id: "rifle", name: "Aurora Rifle", kind: "gun", price: 780, rbx: 80, dmg: 34, rate: 520, range: 700, clip: 8, reload: 1800 },
  { id: "knife", name: "Kawaii Knife", kind: "melee", price: 120, rbx: 12, dmg: 26, rate: 300, range: 56, clip: 0, reload: 0 },
  { id: "sword", name: "Tokemeki Sword", kind: "melee", price: 340, rbx: 35, dmg: 45, rate: 480, range: 78, clip: 0, reload: 0 },
  { id: "grenade", name: "Heart Grenade", kind: "throwable", price: 260, rbx: 28, dmg: 60, rate: 1400, range: 340, clip: 3, reload: 2200 },
];

/** Melee fighting styles — change punch damage, speed and reach. */
export type FightStyle = {
  id: string;
  name: string;
  desc: string;
  rbx: number;
  dmg: number;
  rate: number;
  reach: number;
};

export const FIGHT_STYLES: FightStyle[] = [
  { id: "brawler", name: "Blox Brawler", desc: "Balanced fists", rbx: 0, dmg: 12, rate: 380, reach: 2.6 },
  { id: "kawaii", name: "Kawaii Boxing", desc: "Fast light jabs", rbx: 20, dmg: 9, rate: 190, reach: 2.4 },
  { id: "ironfang", name: "Iron Fang Karate", desc: "Heavy strikes", rbx: 40, dmg: 26, rate: 620, reach: 2.9 },
  { id: "shadow", name: "Shadow Muay Thai", desc: "Knees & elbows", rbx: 60, dmg: 19, rate: 300, reach: 2.7 },
  { id: "voidkick", name: "Void Kick", desc: "Long reach kicks", rbx: 90, dmg: 22, rate: 440, reach: 3.6 },
];

/** Hotbar skills bound to buttons / keys 1-4. */
export type Skill = {
  id: string;
  name: string;
  key: string;
  desc: string;
  cooldown: number; // ms
  rbx: number;
};

export const SKILLS: Skill[] = [
  { id: "dash", name: "Dash", key: "Shift", desc: "Burst forward", cooldown: 2500, rbx: 0 },
  { id: "heal", name: "Med Kit", key: "3", desc: "+45 HP", cooldown: 18000, rbx: 25 },
  { id: "shock", name: "Shockwave", key: "4", desc: "40 dmg around you", cooldown: 12000, rbx: 50 },
  { id: "rage", name: "Rage", key: "5", desc: "2x damage, 8s", cooldown: 25000, rbx: 75 },
];

export type BloxMap = {
  id: string;
  name: string;
  desc: string;
  a: string;
  b: string;
};

export const MAPS: BloxMap[] = [
  { id: "neon-city", name: "Neon City", desc: "Rooftop alleys", a: "#2a1150", b: "#ff4fa3" },
  { id: "sakura-yard", name: "Sakura Yard", desc: "Petal courtyard", a: "#3a1030", b: "#ffa6d5" },
  { id: "cyber-dome", name: "Cyber Dome", desc: "Closed arena", a: "#0f2447", b: "#49d8ff" },
  { id: "lava-blocks", name: "Lava Blocks", desc: "Hot platforms", a: "#40140a", b: "#ff7a2f" },
  { id: "frost-base", name: "Frost Base", desc: "Ice bunkers", a: "#0d2b3a", b: "#8ef0ff" },
  { id: "void-lab", name: "Void Lab", desc: "Low gravity", a: "#160b2e", b: "#a97bff" },
];

export const PRIVATE_SERVER_COST = 10000;

