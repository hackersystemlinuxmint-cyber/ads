// Ashley's voice — kawaii girl voice in English / Tagalog / Japanese.
let current: HTMLAudioElement | null = null;
const KEY = "ashley.voice.on";
const LANG_KEY = "ashley.voice.lang";

export type VoiceLang = "en" | "tl" | "ja";
export type Emotion =
  | "neutral"
  | "happy"
  | "excited"
  | "sad"
  | "angry"
  | "shy"
  | "surprised"
  | "jealous"
  | "annoyed"
  | "awkward"
  | "scared"
  | "cry"
  | "nonchalant"
  | "tsundere";

export const VOICE_LANGS: { id: VoiceLang; label: string; hint: string }[] = [
  { id: "en", label: "English", hint: "Fluent English girl voice" },
  { id: "tl", label: "Tagalog", hint: "Real Filipina voice" },
  { id: "ja", label: "Japanese", hint: "Kawaii teen anime girl" },
];

export function isVoiceOn(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(KEY) !== "0";
}

export function setVoiceOn(on: boolean) {
  localStorage.setItem(KEY, on ? "1" : "0");
  if (!on) stopAshleyVoice();
}

export function getVoiceLang(): VoiceLang {
  if (typeof window === "undefined") return "en";
  const v = localStorage.getItem(LANG_KEY);
  return v === "tl" || v === "ja" ? v : "en";
}

export function setVoiceLang(l: VoiceLang) {
  localStorage.setItem(LANG_KEY, l);
}

/* ---- talking state (drives the animated face) ---- */
type FaceState = { speaking: boolean; emotion: Emotion; level: number };
const listeners = new Set<(s: FaceState) => void>();
let state: FaceState = { speaking: false, emotion: "neutral", level: 0 };

export function subscribeFace(fn: (s: FaceState) => void) {
  listeners.add(fn);
  fn(state);
  return () => listeners.delete(fn);
}
function emit(next: Partial<FaceState>) {
  state = { ...state, ...next };
  listeners.forEach((l) => l(state));
}
export function getFaceState() {
  return state;
}

/** Force Ashley's face into an emotion (used by the lockdown scene). */
export function setFaceEmotion(emotion: Emotion) {
  emit({ emotion });
}

/** Very small heuristic emotion read of Ashley's own text. */
export function detectEmotion(text: string): Emotion {
  const t = text.toLowerCase();
  if (/(hmp|hmph|tsundere|yandere|b-baka|it's not like)/.test(t)) return "tsundere";
  if (/(jealous|mine|don't look at her|😒💢)/.test(t)) return "jealous";
  if (/(annoying|annoyed|ugh|seriously|tsk|💢)/.test(t)) return "annoyed";
  if (/(awkward|umm|uh\.\.\.|eheh|😅)/.test(t)) return "awkward";
  if (/(scared|afraid|scary|please don't|😨|😱)/.test(t)) return "scared";
  if (/(crying|i'm crying|sob|waaah|😭)/.test(t)) return "cry";
  if (/(whatever|meh|fine\.|as you wish|😐)/.test(t)) return "nonchalant";
  if (/(sorry|sad|unfortunately|can't|couldn't|failed|😢)/.test(t)) return "sad";
  if (/(wow|amazing|awesome|yay|let's go|🎉|✨|😆)/.test(t)) return "excited";
  if (/(\?|really|huh|whoa|😮)/.test(t)) return "surprised";
  if (/(angry|stop it|no!|grr|😠)/.test(t)) return "angry";
  if (/(hehe|blush|cute|uwu|>\/\/<|😳)/.test(t)) return "shy";
  if (/(thanks|glad|happy|great|sure|😊|💖)/.test(t)) return "happy";
  return "neutral";
}

export function stopAshleyVoice() {
  if (current) {
    current.pause();
    current.src = "";
    current = null;
  }
  emit({ speaking: false, level: 0 });
}

/** Strips markdown so Ashley doesn't read symbols out loud. */
function clean(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " code block ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/[*_`#>|~]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 900);
}

export async function speakAshley(text: string) {
  const body = clean(text);
  const emotion = detectEmotion(body);
  if (!body || !isVoiceOn()) {
    emit({ emotion });
    return;
  }
  stopAshleyVoice();
  const lang = getVoiceLang();
  try {
    const res = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: body, lang, kawaii: true, emotion }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const audio = new Audio(URL.createObjectURL(blob));
    current = audio;
    emit({ speaking: true, emotion, level: 0.5 });

    // Drive the mouth from the real audio amplitude when possible.
    let raf = 0;
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      const src = ctx.createMediaElementSource(audio);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      src.connect(an);
      an.connect(ctx.destination);
      const data = new Uint8Array(an.frequencyBinCount);
      const tick = () => {
        an.getByteTimeDomainData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) {
          const v = (data[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / data.length);
        emit({ level: Math.min(1, rms * 5) });
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    } catch {
      /* analyser unsupported — fall back to a synthetic flap */
      const id = window.setInterval(() => emit({ level: 0.3 + Math.random() * 0.6 }), 110);
      audio.addEventListener("ended", () => window.clearInterval(id));
      audio.addEventListener("pause", () => window.clearInterval(id));
    }

    const done = () => {
      if (raf) cancelAnimationFrame(raf);
      emit({ speaking: false, level: 0 });
    };
    audio.addEventListener("ended", done);
    audio.addEventListener("pause", done);
    await audio.play().catch(done);
  } catch {
    emit({ speaking: false, level: 0 });
  }
}
