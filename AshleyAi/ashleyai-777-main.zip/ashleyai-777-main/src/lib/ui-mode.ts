// Two display modes: a wide, larger "desktop" UI and a compact "phone" UI
// that always fits the screen. Persisted on the device.
export type UiMode = "desktop" | "phone";

const KEY = "ashley.ui.mode";

export function detectUiMode(): UiMode {
  if (typeof window === "undefined") return "desktop";
  return window.innerWidth < 900 ? "phone" : "desktop";
}

export function getUiMode(): UiMode {
  if (typeof window === "undefined") return "desktop";
  const v = localStorage.getItem(KEY);
  return v === "desktop" || v === "phone" ? v : detectUiMode();
}

export function setUiMode(mode: UiMode) {
  localStorage.setItem(KEY, mode);
  applyUiMode(mode);
}

export function applyUiMode(mode: UiMode) {
  if (typeof document === "undefined") return;
  document.documentElement.dataset["uiMode"] = mode;
}
