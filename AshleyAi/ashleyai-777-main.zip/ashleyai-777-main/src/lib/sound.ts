// Lightweight WebAudio sound effects for AshleyAI UI
let ctx: AudioContext | null = null;
let muted = false;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

function tone(freq: number, dur: number, type: OscillatorType = "sine", gain = 0.05, delay = 0) {
  if (muted) return;
  const c = getCtx();
  if (!c) return;
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g).connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

export const sfx = {
  click: () => tone(880, 0.06, "triangle", 0.03),
  send: () => { tone(660, 0.09, "sine", 0.05); tone(990, 0.09, "sine", 0.04, 0.05); },
  receive: () => { tone(520, 0.10, "sine", 0.05); tone(780, 0.12, "sine", 0.04, 0.06); },
  success: () => { tone(660, 0.08, "triangle", 0.05); tone(880, 0.08, "triangle", 0.05, 0.07); tone(1320, 0.14, "triangle", 0.05, 0.14); },
  error: () => { tone(220, 0.15, "sawtooth", 0.05); tone(180, 0.2, "sawtooth", 0.05, 0.08); },
  hover: () => tone(1200, 0.03, "sine", 0.015),
  startup: () => { tone(440, 0.12, "sine", 0.05); tone(660, 0.12, "sine", 0.05, 0.1); tone(880, 0.2, "sine", 0.05, 0.22); },
};

export function setMuted(v: boolean) { muted = v; }
export function isMuted() { return muted; }

// ---- Background music: original calm blocky-game ambient loop ----
// NOTE: not a copyrighted game soundtrack — an original C-minor ambient
// composition in a similar dreamy, sparse, minor-key mood.
let bgmTimer: number | null = null;
let bgmGain: GainNode | null = null;
let bgmOn = false;

// Sparse C-minor arpeggio (Cm - Ab - Eb - Bb), airy and slow
const BGM_NOTES = [
  523.25, 622.25, 783.99, 622.25, 415.3, 523.25, 622.25, 523.25,
  466.16, 622.25, 783.99, 932.33, 783.99, 622.25, 466.16, 415.3,
];
// Long sustained pad roots under it
const BGM_BASS = [130.81, 103.83, 155.56, 116.54];
const STEP = 0.72; // slow, spacious pacing

function scheduleBgm() {
  const c = getCtx();
  if (!c || !bgmGain) return;
  const start = c.currentTime + 0.05;
  BGM_NOTES.forEach((f, i) => {
    const t0 = start + i * STEP;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(0.07, t0 + 0.12);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + STEP * 2.4);
    osc.connect(g).connect(bgmGain!);
    osc.start(t0);
    osc.stop(t0 + STEP * 2.5);
  });
  BGM_BASS.forEach((f, i) => {
    const t0 = start + i * STEP * 4;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(0.055, t0 + 0.5);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + STEP * 4.2);
    osc.connect(g).connect(bgmGain!);
    osc.start(t0);
    osc.stop(t0 + STEP * 4.4);
  });
}


export function startBgm() {
  const c = getCtx();
  if (!c || bgmOn) return;
  bgmOn = true;
  bgmGain = c.createGain();
  bgmGain.gain.setValueAtTime(0, c.currentTime);
  bgmGain.gain.linearRampToValueAtTime(0.5, c.currentTime + 1.2);
  bgmGain.connect(c.destination);
  scheduleBgm();
  bgmTimer = window.setInterval(scheduleBgm, BGM_NOTES.length * STEP * 1000);
}

export function stopBgm() {
  if (!bgmOn) return;
  bgmOn = false;
  if (bgmTimer !== null) { clearInterval(bgmTimer); bgmTimer = null; }
  const c = getCtx();
  if (c && bgmGain) {
    const g = bgmGain;
    g.gain.cancelScheduledValues(c.currentTime);
    g.gain.setValueAtTime(g.gain.value, c.currentTime);
    g.gain.linearRampToValueAtTime(0, c.currentTime + 0.6);
    setTimeout(() => { try { g.disconnect(); } catch { /* noop */ } }, 900);
  }
  bgmGain = null;
}

export function toggleBgm(on?: boolean) {
  const next = on ?? !bgmOn;
  if (next) startBgm(); else stopBgm();
  return next;
}

export function isBgmOn() { return bgmOn; }
