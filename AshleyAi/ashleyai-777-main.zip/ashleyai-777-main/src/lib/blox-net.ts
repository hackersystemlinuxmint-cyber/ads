// Realtime multiplayer transport for Ro-shooter (presence + broadcast).
import { supabase } from "@/integrations/supabase/client";
import type { RealtimeChannel } from "@supabase/supabase-js";

export type NetPlayerState = {
  id: string;
  name: string;
  admin: boolean;
  x: number;
  y: number;
  z: number;
  ry: number;
  hp: number;
  kills: number;
  shirt: string;
  skin: string;
};

export type ChatMsg = { id: string; from: string; admin: boolean; text: string; system?: boolean; at: number };

type Handlers = {
  onState?: (s: NetPlayerState) => void;
  onLeave?: (id: string) => void;
  onChat?: (m: ChatMsg) => void;
  onHit?: (p: { target: string; by: string; byName: string; dmg: number }) => void;
  onCount?: (n: number) => void;
};

export class BloxNet {
  readonly id = crypto.randomUUID();
  private ch: RealtimeChannel | null = null;
  private h: Handlers = {};
  connected = false;

  constructor(private room: string) {}

  async join(me: NetPlayerState, handlers: Handlers) {
    this.h = handlers;
    const ch = supabase.channel(`roshooter:${this.room}`, {
      config: { presence: { key: this.id }, broadcast: { self: false } },
    });
    this.ch = ch;

    ch.on("broadcast", { event: "state" }, ({ payload }) => this.h.onState?.(payload as NetPlayerState));
    ch.on("broadcast", { event: "chat" }, ({ payload }) => this.h.onChat?.(payload as ChatMsg));
    ch.on("broadcast", { event: "hit" }, ({ payload }) =>
      this.h.onHit?.(payload as { target: string; by: string; byName: string; dmg: number }),
    );
    ch.on("presence", { event: "sync" }, () => {
      const st = ch.presenceState();
      this.h.onCount?.(Object.keys(st).length);
    });
    ch.on("presence", { event: "leave" }, ({ key }) => this.h.onLeave?.(key));

    await new Promise<void>((resolve) => {
      ch.subscribe((status) => {
        if (status === "SUBSCRIBED") {
          this.connected = true;
          void ch.track({ id: this.id, name: me.name, admin: me.admin });
          resolve();
        }
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") resolve();
      });
      window.setTimeout(resolve, 6000);
    });
  }

  sendState(s: NetPlayerState) {
    void this.ch?.send({ type: "broadcast", event: "state", payload: { ...s, id: this.id } });
  }

  sendChat(m: Omit<ChatMsg, "id" | "at">) {
    const msg: ChatMsg = { ...m, id: crypto.randomUUID(), at: Date.now() };
    void this.ch?.send({ type: "broadcast", event: "chat", payload: msg });
    return msg;
  }

  sendHit(target: string, byName: string, dmg: number) {
    void this.ch?.send({
      type: "broadcast",
      event: "hit",
      payload: { target, by: this.id, byName, dmg },
    });
  }

  leave() {
    if (this.ch) void supabase.removeChannel(this.ch);
    this.ch = null;
    this.connected = false;
  }
}
