// AshleyBlox Robux — the in-game currency. Bought with AshleyAI points.
import { useCallback, useEffect, useState } from "react";
import { spendCredits } from "@/lib/credits";

const KEY = "ashleyblox.robux.v1";
const GEMS = "ashleyblox.gems.v1";
const EVT = "ashleyblox-robux-change";

/** How many AshleyAI points 1 Robux costs. */
export const POINTS_PER_ROBUX = 25;
export const PRIVATE_SERVER_ROBUX = 20;

export const ROBUX_PACKS = [
  { id: "r20", robux: 20, points: 20 * POINTS_PER_ROBUX, label: "Starter" },
  { id: "r100", robux: 100, points: 100 * POINTS_PER_ROBUX - 250, label: "Builder" },
  { id: "r500", robux: 500, points: 500 * POINTS_PER_ROBUX - 2000, label: "Pro" },
  { id: "r2000", robux: 2000, points: 2000 * POINTS_PER_ROBUX - 12000, label: "Whale" },
] as const;

/** Gems are an Android-only currency (mobile store exclusive). */
export const GEM_PACKS = [
  { id: "g50", gems: 50, robux: 40 },
  { id: "g250", gems: 250, robux: 180 },
  { id: "g1200", gems: 1200, robux: 800 },
] as const;

export function isAndroid(): boolean {
  if (typeof navigator === "undefined") return false;
  return /android/i.test(navigator.userAgent);
}

function read(key: string, fallback: number): number {
  if (typeof window === "undefined") return fallback;
  const raw = localStorage.getItem(key);
  if (raw === null) return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

export function getRobux(): number {
  return read(KEY, 0);
}

export function getGems(): number {
  return read(GEMS, 0);
}

function write(key: string, n: number) {
  localStorage.setItem(key, String(Math.max(0, Math.round(n))));
  window.dispatchEvent(new Event(EVT));
}

export function addRobux(n: number) {
  write(KEY, getRobux() + n);
}

export function spendRobux(n: number): boolean {
  if (getRobux() < n) return false;
  write(KEY, getRobux() - n);
  return true;
}

export function addGems(n: number) {
  write(GEMS, getGems() + n);
}

/** Convert AshleyAI points into Robux. Returns false when points are short. */
export function buyRobuxWithPoints(robux: number, points: number): boolean {
  if (!spendCredits(points)) return false;
  addRobux(robux);
  return true;
}

export function useRobux() {
  const [robux, setR] = useState(0);
  const [gems, setG] = useState(0);

  useEffect(() => {
    const sync = () => {
      setR(getRobux());
      setG(getGems());
    };
    sync();
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const buy = useCallback((r: number, p: number) => buyRobuxWithPoints(r, p), []);
  return { robux, gems, buy };
}
