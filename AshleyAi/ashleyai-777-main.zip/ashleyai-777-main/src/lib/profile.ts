// AshleyAI user profile — stored on this device.
export type AshleyProfile = {
  first: string;
  middle?: string;
  last: string;
  photo?: string; // data URL
  birthday: string; // yyyy-mm-dd
  age: number;
  faceVerified: boolean; // passed the face scan
};

const KEY = "ashley.profile.v1";

export function parseBirthday(birthday: string): Date | null {
  const cleaned = birthday.trim();
  const m = cleaned.match(/^(\d{1,2})\/(\d{1,2})\/(\d{1,4})$/);
  if (!m) return null;
  let [_, mm, dd, yy] = m;
  let year = Number(yy);
  if (year < 100) year += year < 30 ? 2000 : 1900;
  const month = Number(mm) - 1;
  const day = Number(dd);
  const date = new Date(year, month, day);
  if (
    date.getMonth() !== month ||
    date.getDate() !== day ||
    date.getFullYear() !== year
  ) {
    return null;
  }
  return date;
}

export function ageFromBirthday(birthday: string): number {
  const b = parseBirthday(birthday);
  if (!b) return 0;
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age -= 1;
  return Math.max(0, age);
}

export function buildBirthday(mm: string, dd: string, yy: string): string {
  return `${mm}/${dd}/${yy}`;
}

export function loadProfile(): AshleyProfile | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as AshleyProfile) : null;
  } catch {
    return null;
  }
}

export function saveProfile(p: AshleyProfile | null) {
  if (!p) localStorage.removeItem(KEY);
  else localStorage.setItem(KEY, JSON.stringify(p));
}

/** Full name, middle name optional. */
export function profileName(p: AshleyProfile): string {
  return [p.first, p.middle, p.last].filter(Boolean).join(" ").trim();
}

/** Verified = 18+ AND passed the face scan. */
export function isVerified(p: AshleyProfile | null): boolean {
  return !!p && p.faceVerified && p.age >= 18;
}
