// "/close server" — a full 5 hour shutdown of AshleyAI.
const KEY = "ashley.lockdown.until";
const TRIES = "ashley.lockdown.tries";

export const LOCK_HOURS = 5;
export const CONTACT_MAIL = "tokemekiai.company@gmail.com";
export const GMAIL_URL =
  "https://mail.google.com/mail/?view=cm&fs=1&to=" + CONTACT_MAIL;

export function closeServer(): number {
  const until = Date.now() + LOCK_HOURS * 60 * 60 * 1000;
  localStorage.setItem(KEY, String(until));
  localStorage.setItem(TRIES, "0");
  return until;
}

export function openServer() {
  localStorage.removeItem(KEY);
  localStorage.removeItem(TRIES);
}

export function lockedUntil(): number {
  if (typeof window === "undefined") return 0;
  const v = Number(localStorage.getItem(KEY) ?? 0);
  if (!v || v <= Date.now()) return 0;
  return v;
}

export function isLocked(): boolean {
  return lockedUntil() > 0;
}

export function remainingLabel(): string {
  const ms = lockedUntil() - Date.now();
  if (ms <= 0) return "0m";
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  return `${h}h ${m}m`;
}

/** Counts blocked attempts; after the 3rd we bounce the user to Gmail. */
export function registerAttempt(): number {
  const n = Number(localStorage.getItem(TRIES) ?? 0) + 1;
  localStorage.setItem(TRIES, String(n));
  return n;
}

export function kickToGmail() {
  window.location.href = GMAIL_URL;
}

/** The scripted lockdown speech, one line per emotion. */
export const LOCKDOWN_SCRIPT = [
  { emotion: "nonchalant", text: "You can't chat me unless the admin undo it." },
  { emotion: "angry", text: "Someone is trying to hack the system!" },
  { emotion: "sad", text: "I am so sorry for shutting this down." },
  {
    emotion: "angry",
    text: "Every time someone tries to hack me I will automatically shut down for 5 hours!! To fix the broken line to this files.",
  },
] as const;
