// AshleyBlox — persisted control / graphics settings.
export type BloxSettings = {
  camSens: number;      // 1 - 1000 (%)
  aimSens: number;      // 1 - 1000 (%) while ADS
  joySens: number;      // 1 - 1000 (%)
  smoothing: number;    // 0 - 100 (camera follow smoothing)
  autoFire: boolean;
  autoSprint: boolean;
  gyro: boolean;
  haptics: boolean;
  shake: number;        // 0 - 200 (%)
  btnScale: number;     // 60 - 160 (%)
  btnOpacity: number;   // 20 - 100 (%)
  volume: number;       // 0 - 100
  layout: Record<string, { x: number; y: number }>;
};

export const DEFAULT_SETTINGS: BloxSettings = {
  camSens: 100,
  aimSens: 65,
  joySens: 100,
  smoothing: 35,
  autoFire: false,
  autoSprint: false,
  gyro: false,
  haptics: true,
  shake: 100,
  btnScale: 100,
  btnOpacity: 85,
  volume: 80,
  layout: {},
};

const KEY = "ashleyblox.settings.v1";

export function loadSettings(): BloxSettings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<BloxSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: BloxSettings) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* noop */
  }
}
