CREATE OR REPLACE FUNCTION public.blox_claim_name(_name text, _owner_key text, _admin_pass text DEFAULT NULL)
RETURNS TABLE (ok boolean, reason text, is_admin boolean, kills integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  k text := lower(btrim(_name));
  rec public.blox_players%ROWTYPE;
  wants_admin boolean := (_admin_pass = 'ElijahAtienzaCeoOfTokemekiAi');
BEGIN
  IF length(k) < 3 OR length(k) > 20 THEN
    RETURN QUERY SELECT false, 'Name must be 3-20 characters.', false, 0; RETURN;
  END IF;
  IF _owner_key IS NULL OR length(_owner_key) < 8 THEN
    RETURN QUERY SELECT false, 'Invalid device key.', false, 0; RETURN;
  END IF;

  SELECT * INTO rec FROM public.blox_players WHERE name_key = k;
  IF FOUND THEN
    IF rec.owner_key = _owner_key THEN
      RETURN QUERY SELECT true, 'welcome back', rec.is_admin, rec.kills; RETURN;
    END IF;
    -- the owner can reclaim an admin name from any device with the admin password
    IF wants_admin AND rec.is_admin THEN
      UPDATE public.blox_players SET owner_key = _owner_key, updated_at = now()
        WHERE id = rec.id RETURNING * INTO rec;
      RETURN QUERY SELECT true, 'admin restored', true, rec.kills; RETURN;
    END IF;
    RETURN QUERY SELECT false, 'That name is already taken.', false, 0; RETURN;
  END IF;

  INSERT INTO public.blox_players (name, name_key, owner_key, is_admin)
  VALUES (btrim(_name), k, _owner_key, wants_admin)
  RETURNING * INTO rec;
  RETURN QUERY SELECT true, 'created', rec.is_admin, rec.kills;
END;
$$;