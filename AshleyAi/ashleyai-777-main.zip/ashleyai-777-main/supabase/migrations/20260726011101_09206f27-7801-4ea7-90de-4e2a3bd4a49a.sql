
CREATE TABLE public.app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier_type text NOT NULL CHECK (identifier_type IN ('phone','email')),
  identifier text NOT NULL UNIQUE,
  email_for_code text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_users TO service_role;
ALTER TABLE public.app_users ENABLE ROW LEVEL SECURITY;
-- No policies: table is accessed only by server-side service role.

CREATE TABLE public.pending_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier_type text NOT NULL CHECK (identifier_type IN ('phone','email')),
  identifier text NOT NULL,
  email_for_code text NOT NULL,
  password_hash text NOT NULL,
  code_hash text NOT NULL,
  attempts int NOT NULL DEFAULT 0,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '20 minutes'),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX pending_verifications_identifier_idx ON public.pending_verifications(identifier);
GRANT ALL ON public.pending_verifications TO service_role;
ALTER TABLE public.pending_verifications ENABLE ROW LEVEL SECURITY;
