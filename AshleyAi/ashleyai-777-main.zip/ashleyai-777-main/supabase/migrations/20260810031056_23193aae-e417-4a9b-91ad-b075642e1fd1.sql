CREATE TABLE public.blox_servers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  owner_key text NOT NULL,
  owner_name text NOT NULL,
  max_players integer NOT NULL DEFAULT 8,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT ALL ON public.blox_servers TO service_role;

ALTER TABLE public.blox_servers ENABLE ROW LEVEL SECURITY;

-- No policies for anon/authenticated: all access goes through the security-definer
-- functions below so invite codes can never be enumerated from the client.

CREATE OR REPLACE FUNCTION public.blox_touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER blox_servers_updated_at
BEFORE UPDATE ON public.blox_servers
FOR EACH ROW EXECUTE FUNCTION public.blox_touch_updated_at();

CREATE OR REPLACE FUNCTION public.blox_create_server(_name text, _owner_key text, _owner_name text)
RETURNS TABLE(ok boolean, reason text, code text, name text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  c text;
  n text := btrim(coalesce(_name, ''));
  tries integer := 0;
BEGIN
  IF _owner_key IS NULL OR length(_owner_key) < 8 THEN
    RETURN QUERY SELECT false, 'Invalid device key.', NULL::text, NULL::text; RETURN;
  END IF;
  IF length(n) < 3 THEN n := 'Private Server'; END IF;
  n := left(n, 40);

  IF (SELECT count(*) FROM public.blox_servers s WHERE s.owner_key = _owner_key) >= 10 THEN
    RETURN QUERY SELECT false, 'You already own 10 private servers.', NULL::text, NULL::text; RETURN;
  END IF;

  LOOP
    tries := tries + 1;
    c := upper(substr(replace(encode(gen_random_bytes(8), 'base64'), '/', 'A'), 1, 6));
    c := translate(c, '+=', 'XY');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.blox_servers s WHERE s.code = c) OR tries > 12;
  END LOOP;

  INSERT INTO public.blox_servers (code, name, owner_key, owner_name)
  VALUES (c, n, _owner_key, left(coalesce(_owner_name, 'Player'), 20));

  RETURN QUERY SELECT true, 'created', c, n;
END;
$$;

CREATE OR REPLACE FUNCTION public.blox_join_server(_code text)
RETURNS TABLE(ok boolean, reason text, code text, name text, owner_name text, max_players integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  k text := upper(btrim(coalesce(_code, '')));
  rec public.blox_servers%ROWTYPE;
BEGIN
  IF length(k) <> 6 THEN
    RETURN QUERY SELECT false, 'Invite codes are 6 characters.', NULL::text, NULL::text, NULL::text, NULL::integer; RETURN;
  END IF;
  SELECT * INTO rec FROM public.blox_servers s WHERE s.code = k;
  IF NOT FOUND THEN
    RETURN QUERY SELECT false, 'No private server with that invite code.', NULL::text, NULL::text, NULL::text, NULL::integer; RETURN;
  END IF;
  RETURN QUERY SELECT true, 'ok', rec.code, rec.name, rec.owner_name, rec.max_players;
END;
$$;

CREATE OR REPLACE FUNCTION public.blox_my_servers(_owner_key text)
RETURNS TABLE(code text, name text, created_at timestamp with time zone)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT s.code, s.name, s.created_at
  FROM public.blox_servers s
  WHERE s.owner_key = _owner_key
  ORDER BY s.created_at DESC
  LIMIT 20;
$$;