CREATE TABLE public.blox_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_key text NOT NULL UNIQUE,
  owner_key text NOT NULL,
  is_admin boolean NOT NULL DEFAULT false,
  kills integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.blox_players TO anon, authenticated;
GRANT ALL ON public.blox_players TO service_role;
ALTER TABLE public.blox_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view players" ON public.blox_players FOR SELECT TO anon, authenticated USING (true);

CREATE OR REPLACE FUNCTION public.blox_claim_name(_name text, _owner_key text, _admin_pass text DEFAULT NULL)
RETURNS TABLE (ok boolean, reason text, is_admin boolean, kills integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  k text := lower(btrim(_name));
  rec public.blox_players%ROWTYPE;
  wants_admin boolean := (_admin_pass = 'ElijahAtienzaCeoOfTokemekiAi');
BEGIN
  IF length(k) < 3 OR length(k) > 20 THEN
    RETURN QUERY SELECT false, 'Name must be 3-20 characters.', false, 0; RETURN;
  END IF;
  IF _owner_key IS NULL OR length(_owner_key) < 8 THEN
    RETURN QUERY SELECT false, 'Invalid device key.', false, 0; RETURN;
  END IF;

  SELECT * INTO rec FROM public.blox_players WHERE name_key = k;
  IF FOUND THEN
    IF rec.owner_key = _owner_key THEN
      RETURN QUERY SELECT true, 'welcome back', rec.is_admin, rec.kills; RETURN;
    END IF;
    RETURN QUERY SELECT false, 'That name is already taken.', false, 0; RETURN;
  END IF;

  INSERT INTO public.blox_players (name, name_key, owner_key, is_admin)
  VALUES (btrim(_name), k, _owner_key, wants_admin)
  RETURNING * INTO rec;
  RETURN QUERY SELECT true, 'created', rec.is_admin, rec.kills;
END;
$$;

CREATE OR REPLACE FUNCTION public.blox_add_kills(_name text, _owner_key text, _amount integer)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  total integer;
BEGIN
  IF _amount IS NULL OR _amount < 0 OR _amount > 100 THEN
    RETURN NULL;
  END IF;
  UPDATE public.blox_players
    SET kills = kills + _amount, updated_at = now()
    WHERE name_key = lower(btrim(_name)) AND owner_key = _owner_key
    RETURNING kills INTO total;
  RETURN total;
END;
$$;

GRANT EXECUTE ON FUNCTION public.blox_claim_name(text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.blox_add_kills(text, text, integer) TO anon, authenticated;